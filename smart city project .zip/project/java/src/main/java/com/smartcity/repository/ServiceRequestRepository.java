package com.smartcity.repository;

import com.smartcity.entity.ServiceRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    Optional<ServiceRequest> findByRequestId(String requestId);
    List<ServiceRequest> findByStatus(String status);
    List<ServiceRequest> findByResidentId(Long residentId);
    List<ServiceRequest> findByOrderByCreatedAtDesc();
}
