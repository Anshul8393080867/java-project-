package com.smartcity.service;

import com.smartcity.entity.EmergencyReport;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.EmergencyReportRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmergencyService {

    private final EmergencyReportRepository repository;

    public EmergencyService(EmergencyReportRepository repository) {
        this.repository = repository;
    }

    public List<EmergencyReport> findAll() {
        return repository.findByOrderByReportedTimeDesc();
    }

    public List<EmergencyReport> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    public EmergencyReport findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency report not found: " + id));
    }

    public EmergencyReport save(EmergencyReport report) {
        return repository.save(report);
    }

    public EmergencyReport dispatch(Long id, String responseUnit) {
        EmergencyReport report = findById(id);
        report.setStatus("dispatched");
        report.setResponseUnit(responseUnit);
        return repository.save(report);
    }

    public EmergencyReport resolve(Long id) {
        EmergencyReport report = findById(id);
        report.setStatus("resolved");
        return repository.save(report);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
