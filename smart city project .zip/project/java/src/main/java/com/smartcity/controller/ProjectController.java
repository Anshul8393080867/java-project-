package com.smartcity.controller;

import com.smartcity.entity.InfrastructureProject;
import com.smartcity.service.ProjectService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectService service;

    public ProjectController(ProjectService service) {
        this.service = service;
    }

    @GetMapping
    public List<InfrastructureProject> getAll(@RequestParam(required = false) String status,
                                              @RequestParam(required = false) String search) {
        if (search != null && !search.isEmpty()) return service.search(search);
        if (status != null && !status.isEmpty()) return service.findByStatus(status);
        return service.findAll();
    }

    @GetMapping("/{id}")
    public InfrastructureProject getById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public InfrastructureProject create(@RequestBody InfrastructureProject project) {
        return service.save(project);
    }

    @PutMapping("/{id}")
    public InfrastructureProject update(@PathVariable Long id, @RequestBody InfrastructureProject project) {
        return service.update(id, project);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
