package com.smartcity.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "emergency_reports")
public class EmergencyReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String location;

    @Column(name = "incident_type", nullable = false)
    private String incidentType; // fire, medical, police, natural, hazmat, rescue, traffic_accident

    @Column(nullable = false)
    private String priority; // low, moderate, high, critical

    @Column(nullable = false)
    private String status; // active, contained, resolved, dispatched

    @Column(name = "reported_time", updatable = false)
    private LocalDateTime reportedTime;

    @Column(name = "response_unit")
    private String responseUnit;

    private String description;

    private String zone;

    @PrePersist
    protected void onCreate() {
        this.reportedTime = LocalDateTime.now();
    }

    public EmergencyReport() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getIncidentType() { return incidentType; }
    public void setIncidentType(String incidentType) { this.incidentType = incidentType; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getReportedTime() { return reportedTime; }
    public void setReportedTime(LocalDateTime reportedTime) { this.reportedTime = reportedTime; }
    public String getResponseUnit() { return responseUnit; }
    public void setResponseUnit(String responseUnit) { this.responseUnit = responseUnit; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getZone() { return zone; }
    public void setZone(String zone) { this.zone = zone; }
}
