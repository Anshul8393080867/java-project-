package com.smartcity.service;

import com.smartcity.entity.Feedback;
import com.smartcity.repository.FeedbackRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackService {

    private final FeedbackRepository repository;

    public FeedbackService(FeedbackRepository repository) {
        this.repository = repository;
    }

    public List<Feedback> findAll() {
        return repository.findByOrderByCreatedAtDesc();
    }

    public List<Feedback> findByService(String service) {
        return repository.findByService(service);
    }

    public Feedback save(Feedback feedback) {
        return repository.save(feedback);
    }

    public double getAverageRating() {
        List<Feedback> all = repository.findAll();
        if (all.isEmpty()) return 0;
        return all.stream().mapToInt(Feedback::getRating).average().orElse(0);
    }
}
