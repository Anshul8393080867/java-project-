package com.smartcity.repository;

import com.smartcity.entity.Alert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AlertRepository extends JpaRepository<Alert, Long> {
    List<Alert> findByStatus(String status);
    List<Alert> findByAlertType(String alertType);
    List<Alert> findByOrderByCreatedAtDesc();
}
