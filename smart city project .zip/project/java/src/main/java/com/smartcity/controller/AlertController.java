package com.smartcity.controller;

import com.smartcity.entity.Alert;
import com.smartcity.service.AlertService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alerts")
public class AlertController {

    private final AlertService service;

    public AlertController(AlertService service) {
        this.service = service;
    }

    @GetMapping
    public List<Alert> getAll(@RequestParam(required = false) String status,
                              @RequestParam(required = false) String type) {
        if (status != null && !status.isEmpty()) return service.findByStatus(status);
        if (type != null && !type.isEmpty()) return service.findByType(type);
        return service.findAll();
    }

    @PostMapping
    public Alert create(@RequestBody Alert alert) {
        return service.save(alert);
    }

    @PutMapping("/{id}/status")
    public Alert updateStatus(@PathVariable Long id, @RequestParam String status) {
        return service.updateStatus(id, status);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
