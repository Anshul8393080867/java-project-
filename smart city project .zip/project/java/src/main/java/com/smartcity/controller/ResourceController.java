package com.smartcity.controller;

import com.smartcity.entity.Resource;
import com.smartcity.service.ResourceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/resources")
public class ResourceController {

    private final ResourceService service;

    public ResourceController(ResourceService service) {
        this.service = service;
    }

    @GetMapping
    public List<Resource> getAll(@RequestParam(required = false) String type,
                                 @RequestParam(required = false) String zone) {
        if (type != null && !type.isEmpty()) return service.findByType(type);
        if (zone != null && !zone.isEmpty()) return service.findByZone(zone);
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Resource getById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public Resource create(@RequestBody Resource resource) {
        return service.save(resource);
    }

    @PutMapping("/{id}")
    public Resource update(@PathVariable Long id, @RequestBody Resource resource) {
        return service.update(id, resource);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/recommendation")
    public Map<String, String> getRecommendation() {
        List<Resource> all = service.findAll();
        String rec = all.stream().findFirst()
                .map(service::getAIRecommendation)
                .orElse("All resources operating within optimal parameters.");
        Map<String, String> result = new HashMap<>();
        result.put("recommendation", rec);
        return result;
    }
}
