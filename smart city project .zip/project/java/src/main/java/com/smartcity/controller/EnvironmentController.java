package com.smartcity.controller;

import com.smartcity.entity.EnvironmentData;
import com.smartcity.service.EnvironmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/environment")
public class EnvironmentController {

    private final EnvironmentService service;

    public EnvironmentController(EnvironmentService service) {
        this.service = service;
    }

    @GetMapping
    public List<EnvironmentData> getAll(@RequestParam(required = false) String zone) {
        if (zone != null && !zone.isEmpty()) return service.findByZone(zone);
        return service.findAll();
    }

    @PostMapping
    public EnvironmentData create(@RequestBody EnvironmentData data) {
        return service.save(data);
    }

    @GetMapping("/recommendation")
    public Map<String, String> getRecommendation() {
        Map<String, String> result = new HashMap<>();
        result.put("recommendation", service.getAIRecommendation(service.findAll()));
        return result;
    }

    @GetMapping("/status/{aqi}")
    public Map<String, String> getStatus(@PathVariable int aqi) {
        Map<String, String> result = new HashMap<>();
        result.put("status", service.getStatusLabel(aqi));
        return result;
    }
}
