package com.smartcity.service;

import com.smartcity.entity.EnvironmentData;
import com.smartcity.repository.EnvironmentDataRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnvironmentService {

    private final EnvironmentDataRepository repository;

    public EnvironmentService(EnvironmentDataRepository repository) {
        this.repository = repository;
    }

    public List<EnvironmentData> findAll() {
        return repository.findTop12ByOrderByRecordedAtDesc();
    }

    public List<EnvironmentData> findByZone(String zone) {
        return repository.findByZone(zone);
    }

    public EnvironmentData save(EnvironmentData data) {
        return repository.save(data);
    }

    public String getStatusLabel(int aqi) {
        if (aqi <= 50) return "Good";
        if (aqi <= 100) return "Moderate";
        if (aqi <= 150) return "Poor";
        return "Critical";
    }

    public String getAIRecommendation(List<EnvironmentData> data) {
        EnvironmentData worst = data.stream()
                .max((a, b) -> Integer.compare(a.getAqi(), b.getAqi()))
                .orElse(null);
        if (worst != null && worst.getAqi() > 80) {
            return "Pollution levels in " + worst.getZone() + " have increased during peak traffic hours (AQI " + worst.getAqi() +
                    "). Increasing public transport frequency may help reduce traffic-related pollution.";
        }
        return "Air quality is within acceptable ranges across all zones. No immediate action required.";
    }
}
