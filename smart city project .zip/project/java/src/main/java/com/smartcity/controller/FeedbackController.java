package com.smartcity.controller;

import com.smartcity.entity.Feedback;
import com.smartcity.service.FeedbackService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {

    private final FeedbackService service;

    public FeedbackController(FeedbackService service) {
        this.service = service;
    }

    @GetMapping
    public List<Feedback> getAll() {
        return service.findAll();
    }

    @PostMapping
    public Map<String, Object> create(@RequestBody Feedback feedback) {
        Feedback saved = service.save(feedback);
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "Your feedback has been successfully submitted.");
        result.put("id", saved.getId());
        return result;
    }

    @GetMapping("/average")
    public Map<String, Object> getAverage() {
        Map<String, Object> result = new HashMap<>();
        result.put("averageRating", String.format("%.2f", service.getAverageRating()));
        return result;
    }
}
