package com.smartcity.repository;

import com.smartcity.entity.CityEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CityEventRepository extends JpaRepository<CityEvent, Long> {
    List<CityEvent> findByCategory(String category);
    List<CityEvent> findByOrderByStartTimeDesc();
}
