package com.smartcity.service;

import com.smartcity.entity.InfrastructureProject;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.InfrastructureProjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    private final InfrastructureProjectRepository repository;

    public ProjectService(InfrastructureProjectRepository repository) {
        this.repository = repository;
    }

    public List<InfrastructureProject> findAll() {
        return repository.findAll();
    }

    public List<InfrastructureProject> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    public List<InfrastructureProject> search(String name) {
        return repository.findByProjectNameContainingIgnoreCase(name);
    }

    public InfrastructureProject findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found: " + id));
    }

    public InfrastructureProject save(InfrastructureProject project) {
        return repository.save(project);
    }

    public InfrastructureProject update(Long id, InfrastructureProject updated) {
        InfrastructureProject existing = findById(id);
        existing.setProjectName(updated.getProjectName());
        existing.setLocation(updated.getLocation());
        existing.setBudget(updated.getBudget());
        existing.setProgress(updated.getProgress());
        existing.setStartDate(updated.getStartDate());
        existing.setCompletionDate(updated.getCompletionDate());
        existing.setStatus(updated.getStatus());
        existing.setContractor(updated.getContractor());
        existing.setDescription(updated.getDescription());
        return repository.save(existing);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
