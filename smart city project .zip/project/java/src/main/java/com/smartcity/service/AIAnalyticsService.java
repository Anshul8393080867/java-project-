package com.smartcity.service;

import com.smartcity.dto.AIInsight;
import com.smartcity.entity.*;
import com.smartcity.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class AIAnalyticsService {

    private final TrafficDataRepository trafficRepo;
    private final ResourceRepository resourceRepo;
    private final AlertRepository alertRepo;
    private final EnvironmentDataRepository envRepo;
    private final IoTDeviceRepository iotRepo;

    public AIAnalyticsService(TrafficDataRepository trafficRepo, ResourceRepository resourceRepo,
                              AlertRepository alertRepo, EnvironmentDataRepository envRepo,
                              IoTDeviceRepository iotRepo) {
        this.trafficRepo = trafficRepo;
        this.resourceRepo = resourceRepo;
        this.alertRepo = alertRepo;
        this.envRepo = envRepo;
        this.iotRepo = iotRepo;
    }

    public List<AIInsight> generateInsights() {
        List<AIInsight> insights = new ArrayList<>();
        String now = LocalDateTime.now().toString();

        List<TrafficData> traffic = trafficRepo.findAll();
        List<Resource> resources = resourceRepo.findByOrderByDateDesc();
        List<Alert> alerts = alertRepo.findByStatus("active");
        List<EnvironmentData> envData = envRepo.findTop12ByOrderByRecordedAtDesc();
        List<IoTDevice> devices = iotRepo.findAll();

        // Traffic Prediction
        long severeCount = traffic.stream().filter(t -> "severe".equals(t.getCongestionLevel()) || "high".equals(t.getCongestionLevel())).count();
        if (severeCount > 0) {
            int pct = 15 + (int)(Math.random() * 10);
            insights.add(new AIInsight("ai-1", "traffic",
                    "Traffic congestion may increase by " + pct + "% between 5 PM and 7 PM. Peak volume expected on major corridors.",
                    87, "Traffic Sensor Network", now,
                    "Consider adjusting traffic signal timings and promoting public transport during peak hours."));
        }

        // Energy Forecast
        double totalLoad = resources.stream()
                .filter(r -> "electricity".equals(r.getResourceName()))
                .mapToDouble(r -> r.getUsedAmount().doubleValue())
                .sum();
        if (totalLoad > 0) {
            double peak = totalLoad * 1.15 / 1000;
            insights.add(new AIInsight("ai-2", "energy",
                    "Energy demand may reach " + String.format("%.1f", peak) + " MW during evening peak hours (6-9 PM).",
                    92, "Energy Grid Monitoring System", now,
                    "Initiate demand response protocols and increase renewable energy contribution."));
        }

        // Waste Prediction
        long lowBattery = devices.stream().filter(d -> d.getBatteryLevel() != null && d.getBatteryLevel() < 30).count();
        if (lowBattery > 0) {
            int hours = 6 + (int)(Math.random() * 12);
            insights.add(new AIInsight("ai-3", "waste",
                    "Multiple waste bin sensors may reach capacity within " + hours + " hours. " + lowBattery + " devices need battery maintenance.",
                    81, "Waste Bin IoT Sensors", now,
                    "Prioritize collection routes for high-fill bins and schedule maintenance for low-battery devices."));
        }

        // Environmental Analysis
        if (!envData.isEmpty()) {
            EnvironmentData worst = envData.stream().max((a, b) -> Integer.compare(a.getAqi(), b.getAqi())).orElse(null);
            if (worst != null && worst.getAqi() > 80) {
                insights.add(new AIInsight("ai-4", "environment",
                        worst.getZone() + " has experienced increased pollution (AQI " + worst.getAqi() + ") during peak traffic hours. PM2.5 at " + worst.getPm25() + " ug/m3.",
                        85, "Air Quality Monitoring Network", now,
                        "Increasing public transport frequency and implementing congestion pricing may help reduce pollution."));
            }
        }

        // Public Safety
        long critical = alerts.stream().filter(a -> "critical".equals(a.getAlertType())).count();
        if (critical > 0) {
            int responseTime = 4 + (int)(Math.random() * 6);
            insights.add(new AIInsight("ai-5", "public_safety",
                    critical + " critical alerts active. Predicted response time: " + responseTime + " minutes based on current responder availability.",
                    78, "Emergency Response System", now,
                    "Ensure all response units are deployed and maintain communication with affected zones."));
        }

        // Resource Efficiency
        List<Resource> lowEff = resources.stream().filter(r -> r.getEfficiency().doubleValue() < 80).toList();
        if (!lowEff.isEmpty()) {
            Resource r = lowEff.get(0);
            int reduction = (100 - r.getEfficiency().intValue()) / 2;
            insights.add(new AIInsight("ai-6", "energy",
                    "Based on current consumption patterns, " + r.getZone() + " may reduce " + r.getResourceName() + " usage by approximately " + reduction + "% during peak hours.",
                    83, "Resource Management Database", now,
                    "Implement smart scheduling for " + r.getResourceName() + " consumption in " + r.getZone() + "."));
        }

        return insights;
    }
}
