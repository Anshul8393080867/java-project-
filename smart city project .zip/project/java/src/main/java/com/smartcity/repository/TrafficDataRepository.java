package com.smartcity.repository;

import com.smartcity.entity.TrafficData;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TrafficDataRepository extends JpaRepository<TrafficData, Long> {
    List<TrafficData> findByCongestionLevel(String congestionLevel);
    List<TrafficData> findByZone(String zone);
    List<TrafficData> findTop10ByOrderByTimestampDesc();
}
