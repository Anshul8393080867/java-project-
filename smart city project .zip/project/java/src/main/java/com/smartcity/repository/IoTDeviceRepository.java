package com.smartcity.repository;

import com.smartcity.entity.IoTDevice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IoTDeviceRepository extends JpaRepository<IoTDevice, Long> {
    List<IoTDevice> findByStatus(String status);
    List<IoTDevice> findByDeviceType(String deviceType);
    List<IoTDevice> findByDeviceIdContainingIgnoreCase(String deviceId);
    List<IoTDevice> findByLocationContainingIgnoreCase(String location);
}
