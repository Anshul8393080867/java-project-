package com.smartcity.service;

import com.smartcity.dto.LoginRequest;
import com.smartcity.dto.LoginResponse;
import com.smartcity.entity.User;
import com.smartcity.exception.InvalidCredentialsException;
import com.smartcity.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final Map<String, Long> sessionStore = new HashMap<>();

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByEmailAndPassword(request.getEmail(), request.getPassword())
                .orElseThrow(() -> new InvalidCredentialsException("Invalid email or password"));

        if (!user.getRole().equalsIgnoreCase(request.getRole())) {
            throw new InvalidCredentialsException("Invalid role for this user");
        }

        sessionStore.put(user.getEmail(), user.getId());

        LoginResponse response = new LoginResponse(true, "Login successful");
        response.setUserId(user.getId());
        response.setFullName(user.getFullName());
        response.setRole(user.getRole());
        response.setRedirectUrl(getRedirectUrl(user.getRole()));
        return response;
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new InvalidCredentialsException("User not found"));
    }

    public String getRedirectUrl(String role) {
        return switch (role.toLowerCase()) {
            case "admin" -> "/admin/dashboard";
            case "planner" -> "/planner/dashboard";
            case "resident" -> "/resident/dashboard";
            default -> "/login";
        };
    }

    public void logout(String email) {
        sessionStore.remove(email);
    }
}
