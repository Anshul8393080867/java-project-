package com.smartcity.controller;

import com.smartcity.dto.ServiceRequestDTO;
import com.smartcity.entity.ServiceRequest;
import com.smartcity.service.ServiceRequestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/service-requests")
public class ServiceRequestController {

    private final ServiceRequestService service;

    public ServiceRequestController(ServiceRequestService service) {
        this.service = service;
    }

    @GetMapping
    public List<ServiceRequest> getAll(@RequestParam(required = false) String status,
                                       @RequestParam(required = false) Long residentId) {
        if (residentId != null) return service.findByResident(residentId);
        if (status != null && !status.isEmpty()) return service.findByStatus(status);
        return service.findAll();
    }

    @GetMapping("/track/{requestId}")
    public ServiceRequest track(@PathVariable String requestId) {
        return service.findByRequestId(requestId);
    }

    @PostMapping
    public ServiceRequest create(@RequestBody ServiceRequestDTO dto) {
        ServiceRequest created = service.create(dto);
        return created;
    }

    @PutMapping("/{id}/status")
    public ServiceRequest updateStatus(@PathVariable Long id, @RequestParam String status) {
        return service.updateStatus(id, status);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
