package com.smartcity.controller;

import com.smartcity.entity.IoTDevice;
import com.smartcity.service.IoTDeviceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/iot")
public class IoTDeviceController {

    private final IoTDeviceService service;

    public IoTDeviceController(IoTDeviceService service) {
        this.service = service;
    }

    @GetMapping
    public List<IoTDevice> getAll(@RequestParam(required = false) String status,
                                  @RequestParam(required = false) String type,
                                  @RequestParam(required = false) String search) {
        if (search != null && !search.isEmpty()) return service.search(search);
        if (status != null && !status.isEmpty()) return service.findByStatus(status);
        if (type != null && !type.isEmpty()) return service.findByType(type);
        return service.findAll();
    }

    @GetMapping("/{id}")
    public IoTDevice getById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public IoTDevice create(@RequestBody IoTDevice device) {
        return service.save(device);
    }

    @PutMapping("/{id}")
    public IoTDevice update(@PathVariable Long id, @RequestBody IoTDevice device) {
        return service.update(id, device);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
