package com.smartcity.repository;

import com.smartcity.entity.EmergencyReport;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmergencyReportRepository extends JpaRepository<EmergencyReport, Long> {
    List<EmergencyReport> findByStatus(String status);
    List<EmergencyReport> findByPriority(String priority);
    List<EmergencyReport> findByOrderByReportedTimeDesc();
}
