package com.smartcity.service;

import com.smartcity.entity.Resource;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.ResourceRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class ResourceService {

    private final ResourceRepository repository;

    public ResourceService(ResourceRepository repository) {
        this.repository = repository;
    }

    public List<Resource> findAll() {
        return repository.findByOrderByDateDesc();
    }

    public List<Resource> findByType(String type) {
        return repository.findByResourceName(type);
    }

    public List<Resource> findByZone(String zone) {
        return repository.findByZone(zone);
    }

    public Resource findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Resource not found with id: " + id));
    }

    public Resource save(Resource resource) {
        if (resource.getStatus() == null) {
            resource.setStatus(determineStatus(resource));
        }
        if (resource.getEfficiency() == null) {
            resource.setEfficiency(calculateEfficiency(resource));
        }
        return repository.save(resource);
    }

    public Resource update(Long id, Resource updated) {
        Resource existing = findById(id);
        existing.setResourceName(updated.getResourceName());
        existing.setAllocatedAmount(updated.getAllocatedAmount());
        existing.setUsedAmount(updated.getUsedAmount());
        existing.setUnit(updated.getUnit());
        existing.setZone(updated.getZone());
        existing.setDate(updated.getDate());
        existing.setEfficiency(updated.getEfficiency());
        existing.setStatus(updated.getStatus());
        return repository.save(existing);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public String getAIRecommendation(Resource resource) {
        BigDecimal eff = resource.getEfficiency();
        BigDecimal pct = resource.getAllocatedAmount().compareTo(BigDecimal.ZERO) > 0
                ? resource.getUsedAmount().multiply(BigDecimal.valueOf(100)).divide(resource.getAllocatedAmount(), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        if (eff.compareTo(BigDecimal.valueOf(70)) < 0) {
            int reduction = (100 - eff.intValue()) / 2;
            return "Based on current consumption patterns, " + resource.getZone() +
                    " may reduce " + resource.getResourceName() + " usage by approximately " + reduction +
                    "% during peak hours by implementing smart scheduling.";
        }
        if (pct.compareTo(BigDecimal.valueOf(85)) > 0) {
            return resource.getZone() + " is using " + pct + "% of allocated " + resource.getResourceName() +
                    ". Consider increasing allocation or implementing conservation measures.";
        }
        return resource.getZone() + " " + resource.getResourceName() + " consumption is within optimal range. Current efficiency at " +
                eff + "% is healthy. Continue current usage patterns.";
    }

    private String determineStatus(Resource resource) {
        BigDecimal pct = resource.getAllocatedAmount().compareTo(BigDecimal.ZERO) > 0
                ? resource.getUsedAmount().multiply(BigDecimal.valueOf(100)).divide(resource.getAllocatedAmount(), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;
        if (pct.compareTo(BigDecimal.valueOf(90)) > 0) return "critical";
        if (pct.compareTo(BigDecimal.valueOf(75)) > 0) return "warning";
        return "optimal";
    }

    private BigDecimal calculateEfficiency(Resource resource) {
        if (resource.getAllocatedAmount().compareTo(BigDecimal.ZERO) == 0) return BigDecimal.valueOf(100);
        BigDecimal eff = resource.getUsedAmount().multiply(BigDecimal.valueOf(100))
                .divide(resource.getAllocatedAmount(), 2, RoundingMode.HALF_UP);
        return eff;
    }
}
