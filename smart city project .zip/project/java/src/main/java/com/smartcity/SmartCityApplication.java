package com.smartcity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SmartCity AI - Intelligent Urban Management System
 * "Smarter Cities. Better Living."
 *
 * Entry point for the Spring Boot application.
 */
@SpringBootApplication
public class SmartCityApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCityApplication.class, args);
    }
}
