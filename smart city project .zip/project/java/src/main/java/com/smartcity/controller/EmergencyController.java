package com.smartcity.controller;

import com.smartcity.entity.EmergencyReport;
import com.smartcity.service.EmergencyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emergencies")
public class EmergencyController {

    private final EmergencyService service;

    public EmergencyController(EmergencyService service) {
        this.service = service;
    }

    @GetMapping
    public List<EmergencyReport> getAll(@RequestParam(required = false) String status) {
        if (status != null && !status.isEmpty()) return service.findByStatus(status);
        return service.findAll();
    }

    @GetMapping("/{id}")
    public EmergencyReport getById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public EmergencyReport create(@RequestBody EmergencyReport report) {
        return service.save(report);
    }

    @PutMapping("/{id}/dispatch")
    public EmergencyReport dispatch(@PathVariable Long id, @RequestParam String responseUnit) {
        return service.dispatch(id, responseUnit);
    }

    @PutMapping("/{id}/resolve")
    public EmergencyReport resolve(@PathVariable Long id) {
        return service.resolve(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
