package com.smartcity.repository;

import com.smartcity.entity.EnvironmentData;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EnvironmentDataRepository extends JpaRepository<EnvironmentData, Long> {
    List<EnvironmentData> findByZone(String zone);
    List<EnvironmentData> findTop12ByOrderByRecordedAtDesc();
}
