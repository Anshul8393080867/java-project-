package com.smartcity.repository;

import com.smartcity.entity.InfrastructureProject;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InfrastructureProjectRepository extends JpaRepository<InfrastructureProject, Long> {
    List<InfrastructureProject> findByStatus(String status);
    List<InfrastructureProject> findByProjectNameContainingIgnoreCase(String name);
}
