package com.smartcity.controller;

import com.smartcity.entity.CityEvent;
import com.smartcity.service.CityEventService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
public class CityEventController {

    private final CityEventService service;

    public CityEventController(CityEventService service) {
        this.service = service;
    }

    @GetMapping
    public List<CityEvent> getAll(@RequestParam(required = false) String category) {
        if (category != null && !category.isEmpty()) return service.findByCategory(category);
        return service.findAll();
    }

    @PostMapping
    public CityEvent create(@RequestBody CityEvent event) {
        return service.save(event);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
