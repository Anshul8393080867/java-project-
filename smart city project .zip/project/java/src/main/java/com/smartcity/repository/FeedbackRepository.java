package com.smartcity.repository;

import com.smartcity.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByOrderByCreatedAtDesc();
    List<Feedback> findByService(String service);
}
