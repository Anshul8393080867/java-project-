package com.smartcity.dto;

public class DashboardStats {
    private long totalDevices;
    private long onlineDevices;
    private double energyConsumption;
    private double waterUsage;
    private long activeAlerts;
    private String trafficStatus;
    private double wasteCollectionPct;
    private double avgAqi;

    public DashboardStats() {}

    public long getTotalDevices() { return totalDevices; }
    public void setTotalDevices(long totalDevices) { this.totalDevices = totalDevices; }
    public long getOnlineDevices() { return onlineDevices; }
    public void setOnlineDevices(long onlineDevices) { this.onlineDevices = onlineDevices; }
    public double getEnergyConsumption() { return energyConsumption; }
    public void setEnergyConsumption(double energyConsumption) { this.energyConsumption = energyConsumption; }
    public double getWaterUsage() { return waterUsage; }
    public void setWaterUsage(double waterUsage) { this.waterUsage = waterUsage; }
    public long getActiveAlerts() { return activeAlerts; }
    public void setActiveAlerts(long activeAlerts) { this.activeAlerts = activeAlerts; }
    public String getTrafficStatus() { return trafficStatus; }
    public void setTrafficStatus(String trafficStatus) { this.trafficStatus = trafficStatus; }
    public double getWasteCollectionPct() { return wasteCollectionPct; }
    public void setWasteCollectionPct(double wasteCollectionPct) { this.wasteCollectionPct = wasteCollectionPct; }
    public double getAvgAqi() { return avgAqi; }
    public void setAvgAqi(double avgAqi) { this.avgAqi = avgAqi; }
}
