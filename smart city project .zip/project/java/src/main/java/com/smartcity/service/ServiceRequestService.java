package com.smartcity.service;

import com.smartcity.dto.ServiceRequestDTO;
import com.smartcity.entity.ServiceRequest;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.ServiceRequestRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServiceRequestService {

    private final ServiceRequestRepository repository;

    public ServiceRequestService(ServiceRequestRepository repository) {
        this.repository = repository;
    }

    public List<ServiceRequest> findAll() {
        return repository.findByOrderByCreatedAtDesc();
    }

    public List<ServiceRequest> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    public List<ServiceRequest> findByResident(Long residentId) {
        return repository.findByResidentId(residentId);
    }

    public ServiceRequest findByRequestId(String requestId) {
        return repository.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));
    }

    public ServiceRequest create(ServiceRequestDTO dto) {
        ServiceRequest req = new ServiceRequest();
        req.setRequestId(generateRequestId());
        req.setServiceType(dto.getServiceType());
        req.setLocation(dto.getLocation());
        req.setDescription(dto.getDescription());
        req.setPriority(dto.getPriority());
        req.setResidentName(dto.getResidentName() != null ? dto.getResidentName() : "Anonymous");
        req.setStatus("submitted");
        return repository.save(req);
    }

    public ServiceRequest updateStatus(Long id, String status) {
        ServiceRequest req = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + id));
        req.setStatus(status);
        if ("resolved".equals(status)) {
            req.setResolvedAt(LocalDateTime.now());
        }
        return repository.save(req);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    private String generateRequestId() {
        int num = 10000 + (int)(Math.random() * 9999);
        return "SC-2026-" + num;
    }
}
