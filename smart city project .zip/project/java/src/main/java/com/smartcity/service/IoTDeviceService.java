package com.smartcity.service;

import com.smartcity.entity.IoTDevice;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.IoTDeviceRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class IoTDeviceService {

    private final IoTDeviceRepository repository;

    public IoTDeviceService(IoTDeviceRepository repository) {
        this.repository = repository;
    }

    public List<IoTDevice> findAll() {
        return repository.findAll();
    }

    public List<IoTDevice> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    public List<IoTDevice> findByType(String type) {
        return repository.findByDeviceType(type);
    }

    public List<IoTDevice> search(String query) {
        List<IoTDevice> byId = repository.findByDeviceIdContainingIgnoreCase(query);
        byId.addAll(repository.findByLocationContainingIgnoreCase(query));
        return byId;
    }

    public IoTDevice findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("IoT device not found with id: " + id));
    }

    public IoTDevice save(IoTDevice device) {
        device.setLastUpdated(LocalDateTime.now());
        return repository.save(device);
    }

    public IoTDevice update(Long id, IoTDevice updated) {
        IoTDevice existing = findById(id);
        existing.setDeviceType(updated.getDeviceType());
        existing.setLocation(updated.getLocation());
        existing.setStatus(updated.getStatus());
        existing.setBatteryLevel(updated.getBatteryLevel());
        existing.setLastReading(updated.getLastReading());
        existing.setLastUpdated(LocalDateTime.now());
        return repository.save(existing);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public long count() {
        return repository.count();
    }

    public long countByStatus(String status) {
        return repository.findByStatus(status).size();
    }
}
