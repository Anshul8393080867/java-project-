package com.smartcity.repository;

import com.smartcity.entity.Resource;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Long> {
    List<Resource> findByResourceName(String resourceName);
    List<Resource> findByZone(String zone);
    List<Resource> findByStatus(String status);
    List<Resource> findByOrderByDateDesc();
}
