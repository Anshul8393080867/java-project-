package com.smartcity.controller;

import com.smartcity.entity.TrafficData;
import com.smartcity.service.TrafficService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/traffic")
public class TrafficController {

    private final TrafficService service;

    public TrafficController(TrafficService service) {
        this.service = service;
    }

    @GetMapping
    public List<TrafficData> getAll() {
        return service.findAll();
    }

    @GetMapping("/recent")
    public List<TrafficData> getRecent() {
        return service.findRecent();
    }

    @GetMapping("/congestion/{level}")
    public List<TrafficData> getByCongestion(@PathVariable String level) {
        return service.findByCongestion(level);
    }

    @PostMapping
    public TrafficData create(@RequestBody TrafficData data) {
        return service.save(data);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/recommendation")
    public Map<String, String> getRecommendation() {
        Map<String, String> result = new HashMap<>();
        result.put("recommendation", service.getAIRecommendation(service.findAll()));
        return result;
    }
}
