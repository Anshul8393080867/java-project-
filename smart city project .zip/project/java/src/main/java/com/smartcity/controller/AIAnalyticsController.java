package com.smartcity.controller;

import com.smartcity.dto.AIInsight;
import com.smartcity.service.AIAnalyticsService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ai-analytics")
public class AIAnalyticsController {

    private final AIAnalyticsService service;

    public AIAnalyticsController(AIAnalyticsService service) {
        this.service = service;
    }

    @GetMapping("/insights")
    public List<AIInsight> getInsights() {
        return service.generateInsights();
    }
}
