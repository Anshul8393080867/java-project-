package com.smartcity.dto;

public class AIInsight {
    private String id;
    private String category;
    private String prediction;
    private int confidence;
    private String dataSource;
    private String timestamp;
    private String recommendation;

    public AIInsight() {}

    public AIInsight(String id, String category, String prediction, int confidence, String dataSource, String timestamp, String recommendation) {
        this.id = id;
        this.category = category;
        this.prediction = prediction;
        this.confidence = confidence;
        this.dataSource = dataSource;
        this.timestamp = timestamp;
        this.recommendation = recommendation;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getPrediction() { return prediction; }
    public void setPrediction(String prediction) { this.prediction = prediction; }
    public int getConfidence() { return confidence; }
    public void setConfidence(int confidence) { this.confidence = confidence; }
    public String getDataSource() { return dataSource; }
    public void setDataSource(String dataSource) { this.dataSource = dataSource; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
}
