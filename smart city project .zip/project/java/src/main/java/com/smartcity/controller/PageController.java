package com.smartcity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Page controllers for Thymeleaf views.
 * Each role gets its own dashboard, and shared module pages are accessible from all dashboards.
 */
@Controller
public class PageController {

    // ===== Admin =====
    @GetMapping("/admin/dashboard")
    public String adminDashboard() { return "admin/dashboard"; }

    @GetMapping("/admin/iot")
    public String adminIot() { return "admin/iot"; }

    @GetMapping("/admin/resources")
    public String adminResources() { return "admin/resources"; }

    @GetMapping("/admin/alerts")
    public String adminAlerts() { return "admin/alerts"; }

    @GetMapping("/admin/traffic")
    public String adminTraffic() { return "admin/traffic"; }

    @GetMapping("/admin/emergency")
    public String adminEmergency() { return "admin/emergency"; }

    @GetMapping("/admin/environment")
    public String adminEnvironment() { return "admin/environment"; }

    @GetMapping("/admin/ai-analytics")
    public String adminAiAnalytics() { return "admin/ai-analytics"; }

    @GetMapping("/admin/reports")
    public String adminReports() { return "admin/reports"; }

    @GetMapping("/admin/realtime")
    public String adminRealtime() { return "admin/realtime"; }

    // ===== Planner =====
    @GetMapping("/planner/dashboard")
    public String plannerDashboard() { return "planner/dashboard"; }

    @GetMapping("/planner/projects")
    public String plannerProjects() { return "planner/projects"; }

    @GetMapping("/planner/environment")
    public String plannerEnvironment() { return "planner/environment"; }

    // ===== Resident =====
    @GetMapping("/resident/dashboard")
    public String residentDashboard() { return "resident/dashboard"; }

    @GetMapping("/resident/service-request")
    public String residentServiceRequest() { return "resident/service-request"; }

    @GetMapping("/resident/feedback")
    public String residentFeedback() { return "resident/feedback"; }

    @GetMapping("/resident/track")
    public String residentTrack() { return "resident/track"; }
}
