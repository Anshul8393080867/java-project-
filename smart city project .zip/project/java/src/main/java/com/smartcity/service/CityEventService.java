package com.smartcity.service;

import com.smartcity.entity.CityEvent;
import com.smartcity.repository.CityEventRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityEventService {

    private final CityEventRepository repository;

    public CityEventService(CityEventRepository repository) {
        this.repository = repository;
    }

    public List<CityEvent> findAll() {
        return repository.findByOrderByStartTimeDesc();
    }

    public List<CityEvent> findByCategory(String category) {
        return repository.findByCategory(category);
    }

    public CityEvent save(CityEvent event) {
        return repository.save(event);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
