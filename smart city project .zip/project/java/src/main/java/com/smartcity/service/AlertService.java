package com.smartcity.service;

import com.smartcity.entity.Alert;
import com.smartcity.exception.ResourceNotFoundException;
import com.smartcity.repository.AlertRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertService {

    private final AlertRepository repository;

    public AlertService(AlertRepository repository) {
        this.repository = repository;
    }

    public List<Alert> findAll() {
        return repository.findByOrderByCreatedAtDesc();
    }

    public List<Alert> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    public List<Alert> findByType(String type) {
        return repository.findByAlertType(type);
    }

    public Alert save(Alert alert) {
        return repository.save(alert);
    }

    public Alert updateStatus(Long id, String status) {
        Alert alert = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Alert not found: " + id));
        alert.setStatus(status);
        return repository.save(alert);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public long countActive() {
        return repository.findByStatus("active").size();
    }

    public long countByType(String type) {
        return repository.findByAlertType(type).size();
    }
}
