package com.smartcity.service;

import com.smartcity.entity.TrafficData;
import com.smartcity.repository.TrafficDataRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrafficService {

    private final TrafficDataRepository repository;

    public TrafficService(TrafficDataRepository repository) {
        this.repository = repository;
    }

    public List<TrafficData> findAll() {
        return repository.findAll();
    }

    public List<TrafficData> findRecent() {
        return repository.findTop10ByOrderByTimestampDesc();
    }

    public List<TrafficData> findByCongestion(String level) {
        return repository.findByCongestionLevel(level);
    }

    public TrafficData save(TrafficData data) {
        return repository.save(data);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public String getAIRecommendation(List<TrafficData> data) {
        long highCount = data.stream().filter(t -> "high".equals(t.getCongestionLevel()) || "severe".equals(t.getCongestionLevel())).count();
        if (highCount > 0) {
            int pctIncrease = 15 + (int)(Math.random() * 10);
            return "Traffic congestion is expected to increase by " + pctIncrease + "% between 5 PM and 7 PM. Consider adjusting traffic signal timings on major corridors.";
        }
        return "Traffic flow is currently stable across all monitored zones. No immediate action required.";
    }
}
