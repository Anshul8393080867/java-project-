package com.smartcity.controller;

import com.smartcity.entity.*;
import com.smartcity.repository.*;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ResourceRepository resourceRepo;
    private final TrafficDataRepository trafficRepo;
    private final EmergencyReportRepository emergencyRepo;
    private final EnvironmentDataRepository envRepo;
    private final InfrastructureProjectRepository projectRepo;
    private final AlertRepository alertRepo;
    private final IoTDeviceRepository iotRepo;

    public ReportController(ResourceRepository resourceRepo, TrafficDataRepository trafficRepo,
                            EmergencyReportRepository emergencyRepo, EnvironmentDataRepository envRepo,
                            InfrastructureProjectRepository projectRepo, AlertRepository alertRepo,
                            IoTDeviceRepository iotRepo) {
        this.resourceRepo = resourceRepo;
        this.trafficRepo = trafficRepo;
        this.emergencyRepo = emergencyRepo;
        this.envRepo = envRepo;
        this.projectRepo = projectRepo;
        this.alertRepo = alertRepo;
        this.iotRepo = iotRepo;
    }

    @GetMapping
    public Map<String, Object> getReportData(@RequestParam(required = false) String category,
                                             @RequestParam(required = false) String zone) {
        Map<String, Object> report = new HashMap<>();
        report.put("category", category != null ? category : "all");
        report.put("zone", zone != null ? zone : "all");

        switch (category != null ? category : "all") {
            case "traffic" -> report.put("data", trafficRepo.findAll());
            case "energy" -> report.put("data", resourceRepo.findByResourceName("electricity"));
            case "water" -> report.put("data", resourceRepo.findByResourceName("water"));
            case "waste" -> report.put("data", resourceRepo.findByResourceName("waste"));
            case "safety" -> report.put("data", emergencyRepo.findAll());
            case "environment" -> report.put("data", envRepo.findAll());
            case "infrastructure" -> report.put("data", projectRepo.findAll());
            default -> {
                report.put("traffic", trafficRepo.findAll());
                report.put("energy", resourceRepo.findByResourceName("electricity"));
                report.put("water", resourceRepo.findByResourceName("water"));
                report.put("waste", resourceRepo.findByResourceName("waste"));
                report.put("emergencies", emergencyRepo.findAll());
                report.put("environment", envRepo.findAll());
                report.put("projects", projectRepo.findAll());
                report.put("alerts", alertRepo.findAll());
                report.put("devices", iotRepo.findAll());
            }
        }
        return report;
    }

    @GetMapping("/export")
    public Map<String, String> exportCSV(@RequestParam(required = false) String category) {
        Map<String, String> result = new HashMap<>();
        StringBuilder csv = new StringBuilder();

        switch (category != null ? category : "all") {
            case "traffic" -> {
                csv.append("ID,Location,Vehicle Count,Congestion Level,Average Speed,Zone,Timestamp\n");
                for (TrafficData t : trafficRepo.findAll()) {
                    csv.append(t.getId()).append(",").append(t.getLocation()).append(",")
                            .append(t.getVehicleCount()).append(",").append(t.getCongestionLevel()).append(",")
                            .append(t.getAverageSpeed()).append(",").append(t.getZone()).append(",")
                            .append(t.getTimestamp()).append("\n");
                }
            }
            case "energy" -> {
                csv.append("ID,Zone,Allocated,Used,Efficiency,Status,Date\n");
                for (Resource r : resourceRepo.findByResourceName("electricity")) {
                    csv.append(r.getId()).append(",").append(r.getZone()).append(",")
                            .append(r.getAllocatedAmount()).append(",").append(r.getUsedAmount()).append(",")
                            .append(r.getEfficiency()).append(",").append(r.getStatus()).append(",")
                            .append(r.getDate()).append("\n");
                }
            }
            case "safety" -> {
                csv.append("ID,Location,Incident Type,Priority,Status,Response Unit,Reported Time\n");
                for (EmergencyReport e : emergencyRepo.findAll()) {
                    csv.append(e.getId()).append(",").append(e.getLocation()).append(",")
                            .append(e.getIncidentType()).append(",").append(e.getPriority()).append(",")
                            .append(e.getStatus()).append(",").append(e.getResponseUnit()).append(",")
                            .append(e.getReportedTime()).append("\n");
                }
            }
            default -> {
                csv.append("Category,Count\n");
                csv.append("Traffic Records,").append(trafficRepo.count()).append("\n");
                csv.append("Energy Records,").append(resourceRepo.findByResourceName("electricity").size()).append("\n");
                csv.append("Water Records,").append(resourceRepo.findByResourceName("water").size()).append("\n");
                csv.append("Waste Records,").append(resourceRepo.findByResourceName("waste").size()).append("\n");
                csv.append("Emergencies,").append(emergencyRepo.count()).append("\n");
                csv.append("Environment Records,").append(envRepo.count()).append("\n");
                csv.append("Projects,").append(projectRepo.count()).append("\n");
                csv.append("Alerts,").append(alertRepo.count()).append("\n");
                csv.append("IoT Devices,").append(iotRepo.count()).append("\n");
            }
        }

        result.put("csv", csv.toString());
        result.put("filename", "smartcity_report_" + category + ".csv");
        return result;
    }
}
