-- SmartCity AI - Seed Data
-- Demo accounts: password is "smartcity" for all users

-- Users
INSERT INTO users (email, password, full_name, role, zone) VALUES
('admin@smartcity.ai', 'smartcity', 'Sarah Chen', 'admin', 'Downtown'),
('planner@smartcity.ai', 'smartcity', 'Marcus Rivera', 'planner', 'Northgate'),
('resident@smartcity.ai', 'smartcity', 'Emily Johnson', 'resident', 'Westview'),
('admin2@smartcity.ai', 'smartcity', 'David Park', 'admin', 'Industrial Park'),
('resident2@smartcity.ai', 'smartcity', 'Liam OBrien', 'resident', 'Downtown')
ON DUPLICATE KEY UPDATE email=email;

-- IoT Devices
INSERT INTO iot_devices (device_id, device_type, location, status, battery_level, last_reading) VALUES
('IOT-1001', 'traffic_sensor', 'Main St & 5th Ave', 'online', 86, '320 vehicles/h'),
('IOT-1002', 'air_quality_sensor', 'City Hall Rooftop', 'online', 72, 'AQI 62, PM2.5 18.5'),
('IOT-1003', 'smart_street_light', 'Broadway Ave 100-200', 'online', 91, 'On, 80% brightness'),
('IOT-1004', 'energy_meter', 'Downtown Grid Alpha', 'online', 100, '41.5 MW load'),
('IOT-1005', 'waste_bin_sensor', 'Main St Plaza Bin', 'alert', 45, '85% full'),
('IOT-1006', 'traffic_sensor', 'Broadway & 42nd', 'online', 78, '510 vehicles/h'),
('IOT-1007', 'water_sensor', 'Downtown Water Main', 'online', 95, '4.2 bar pressure'),
('IOT-1008', 'air_quality_sensor', 'Central Park East', 'online', 88, 'AQI 48, PM2.5 14.2'),
('IOT-1009', 'traffic_sensor', 'River Road Bridge', 'online', 82, '95 vehicles/h'),
('IOT-1010', 'waste_bin_sensor', 'River Walk Entrance', 'online', 67, '60% full'),
('IOT-1011', 'energy_meter', 'Riverside Solar Network', 'online', 100, '19.2 MW, 68.5% renewable'),
('IOT-1014', 'traffic_sensor', 'Northgate Blvd', 'online', 74, '75 vehicles/h'),
('IOT-1015', 'traffic_sensor', 'Highway 9 Interchange', 'alert', 38, '480 vehicles/h, severe'),
('IOT-1016', 'air_quality_sensor', 'Northgate Tower', 'online', 81, 'AQI 56, PM2.5 16.8'),
('IOT-1017', 'smart_street_light', 'Oakwood Ave 1-50', 'offline', 12, 'Offline - battery low'),
('IOT-1018', 'waste_bin_sensor', 'Highway 9 Rest Stop', 'alert', 23, '100% full - overflow'),
('IOT-1019', 'energy_meter', 'Northgate Power Hub', 'online', 100, '28.7 MW load'),
('IOT-1020', 'energy_meter', 'Industrial Main Feed', 'online', 100, '72.5 MW load'),
('IOT-1021', 'air_quality_sensor', 'Industrial Park Center', 'alert', 65, 'AQI 98, PM2.5 35.5'),
('IOT-1024', 'traffic_sensor', 'Cargo Terminal Rd', 'online', 88, '195 vehicles/h'),
('IOT-1026', 'air_quality_sensor', 'Westview Hills', 'online', 94, 'AQI 38, PM2.5 10.5'),
('IOT-1027', 'traffic_sensor', 'Sunset Blvd', 'online', 76, '240 vehicles/h'),
('IOT-1029', 'smart_street_light', 'Harbor Marina Walk', 'online', 89, 'On, 50% brightness'),
('IOT-1030', 'water_sensor', 'Harbor District Main', 'alert', 55, '2.1 bar - low pressure')
ON DUPLICATE KEY UPDATE device_id=device_id;

-- Resources (last 7 days for Downtown)
INSERT INTO resources (resource_name, allocated_amount, used_amount, unit, zone, date, efficiency, status) VALUES
('electricity', 50000, 41500, 'kWh', 'Downtown', CURDATE(), 83.0, 'warning'),
('electricity', 50000, 38200, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 76.4, 'optimal'),
('electricity', 50000, 39800, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 2 DAY), 79.6, 'optimal'),
('electricity', 50000, 42500, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 3 DAY), 85.0, 'warning'),
('electricity', 50000, 44200, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 4 DAY), 88.4, 'warning'),
('electricity', 50000, 41000, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 5 DAY), 82.0, 'optimal'),
('electricity', 50000, 39500, 'kWh', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 6 DAY), 79.0, 'optimal'),
('water', 800000, 640000, 'L', 'Downtown', CURDATE(), 80.0, 'optimal'),
('water', 800000, 680000, 'L', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 85.0, 'optimal'),
('water', 800000, 720000, 'L', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 2 DAY), 90.0, 'warning'),
('water', 800000, 610000, 'L', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 3 DAY), 76.3, 'optimal'),
('waste', 12000, 10440, 'kg', 'Downtown', CURDATE(), 87.0, 'optimal'),
('waste', 12000, 9800, 'kg', 'Downtown', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 81.7, 'optimal'),
('electricity', 80000, 72500, 'kWh', 'Industrial Park', CURDATE(), 90.6, 'critical'),
('electricity', 80000, 68000, 'kWh', 'Industrial Park', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 85.0, 'warning'),
('water', 1000000, 850000, 'L', 'Industrial Park', CURDATE(), 85.0, 'warning'),
('waste', 15000, 13800, 'kg', 'Industrial Park', CURDATE(), 92.0, 'warning'),
('electricity', 28000, 19200, 'kWh', 'Riverside', CURDATE(), 68.6, 'optimal'),
('water', 600000, 450000, 'L', 'Riverside', CURDATE(), 75.0, 'optimal'),
('electricity', 38000, 24300, 'kWh', 'Westview', CURDATE(), 63.9, 'optimal'),
('water', 500000, 380000, 'L', 'Westview', CURDATE(), 76.0, 'optimal')
ON DUPLICATE KEY UPDATE id=id;

-- Traffic Data
INSERT INTO traffic_data (location, vehicle_count, congestion_level, average_speed, zone) VALUES
('Main St & 5th Ave', 320, 'moderate', 35.5, 'Downtown'),
('Broadway & 42nd', 510, 'high', 22.0, 'Downtown'),
('River Road Bridge', 95, 'low', 55.0, 'Riverside'),
('Northgate Blvd', 75, 'low', 60.0, 'Northgate'),
('Highway 9 Interchange', 480, 'severe', 12.0, 'Northgate'),
('Cargo Terminal Rd', 195, 'moderate', 40.0, 'Industrial Park'),
('Sunset Blvd', 240, 'moderate', 38.0, 'Westview'),
('Oakwood Ave', 110, 'low', 50.0, 'Northgate'),
('Canal St Extension', 180, 'moderate', 42.0, 'Riverside'),
('Harbor Marina Dr', 85, 'low', 58.0, 'Harbor District')
ON DUPLICATE KEY UPDATE id=id;

-- Emergency Reports
INSERT INTO emergency_reports (location, incident_type, priority, status, response_unit, description, zone) VALUES
('Sector 18', 'traffic_accident', 'high', 'dispatched', 'Unit 12 - Ambulance & Fire', 'Multi-vehicle collision at Sector 18 intersection', 'Downtown'),
('Industrial Park', 'fire', 'critical', 'active', 'Fire Unit 3', 'Industrial warehouse fire reported', 'Industrial Park'),
('Pier 9 Underpass', 'natural', 'critical', 'active', 'Water Rescue Team', 'Flash flooding at Pier 9 underpass', 'Harbor District'),
('Northgate Blvd', 'medical', 'moderate', 'contained', 'Ambulance 7', 'Medical emergency at bus terminal', 'Northgate'),
('Canal St', 'hazmat', 'high', 'resolved', 'Hazmat Unit 1', 'Chemical spill containment completed', 'Riverside'),
('Broadway & 42nd', 'police', 'low', 'resolved', 'Patrol Unit 5', 'Public disturbance resolved', 'Downtown'),
('Cargo Terminal Rd', 'rescue', 'moderate', 'active', 'Rescue Team 2', 'Vehicle extrication in progress', 'Industrial Park')
ON DUPLICATE KEY UPDATE id=id;

-- Infrastructure Projects
INSERT INTO infrastructure_projects (project_name, location, budget, progress, start_date, completion_date, status, contractor, description) VALUES
('Smart Road Expansion', 'Highway 9 Corridor', 12500000, 45, '2026-01-15', '2027-06-30', 'in_progress', 'Urban Infra Corp', 'Expanding Highway 9 from 4 to 6 lanes with smart traffic sensors'),
('Solar Energy Park', 'Industrial Park East', 8500000, 72, '2025-09-01', '2026-08-15', 'in_progress', 'GreenTech Solutions', '50MW solar farm to power industrial zone with renewable energy'),
('Smart Waste Facility', 'Riverside District', 5200000, 38, '2026-03-01', '2027-12-01', 'in_progress', 'EcoWaste Systems', 'Automated waste sorting and recycling facility with IoT monitoring'),
('Public Transport Upgrade', 'Citywide', 15000000, 20, '2026-06-01', '2028-06-01', 'in_progress', 'TransitTech Inc', 'Electric bus fleet and smart charging stations across all zones'),
('Green Park Development', 'Westview Hills', 3200000, 15, '2026-07-01', '2027-12-15', 'planning', 'LandscapePro', '25-acre urban park with native vegetation and walking trails'),
('Northgate Transit Hub', 'Northgate Central', 6800000, 58, '2025-11-01', '2026-12-20', 'in_progress', 'MetroBuild Ltd', 'Modern transit hub with integrated bus and metro connections')
ON DUPLICATE KEY UPDATE id=id;

-- Environment Data
INSERT INTO environment_data (zone, aqi, pm25, pm10, co2, temperature, humidity, noise_level) VALUES
('Downtown', 62, 18.5, 35.2, 420, 24.5, 58, 65),
('Riverside', 45, 12.3, 22.1, 380, 23.8, 62, 48),
('Northgate', 56, 16.8, 30.5, 410, 24.0, 60, 72),
('Industrial Park', 98, 35.5, 58.2, 520, 25.1, 55, 85),
('Westview', 38, 10.5, 18.2, 360, 22.9, 65, 42),
('Harbor District', 52, 14.2, 25.8, 395, 23.5, 68, 55)
ON DUPLICATE KEY UPDATE id=id;

-- Service Requests
INSERT INTO service_requests (request_id, resident_name, service_type, location, description, priority, status) VALUES
('SC-2026-10482', 'Emily Johnson', 'street_light', 'Sunset Blvd & Oak St', 'Streetlight flickering for 3 days near bus stop', 'normal', 'in_progress'),
('SC-2026-10483', 'Emily Johnson', 'waste_collection', 'Sunset Blvd 500-600', 'Trash collection missed for 2 weeks', 'high', 'submitted'),
('SC-2026-10484', 'Anonymous', 'road_maintenance', 'Main St & 5th Ave', 'Large pothole damaging tires', 'high', 'in_progress'),
('SC-2026-10485', 'Anonymous', 'water_supply', 'River Road 100-200', 'Low water pressure in mornings', 'high', 'in_progress'),
('SC-2026-10486', 'Anonymous', 'electricity', 'Park Ave 30-40', 'Power flickering during evening hours', 'urgent', 'submitted'),
('SC-2026-10487', 'Robert Martinez', 'public_transport', 'Highway 9 Interchange', 'Buses 20+ min late consistently', 'normal', 'in_progress'),
('SC-2026-10488', 'Jennifer Lee', 'waste_collection', 'Sunset Blvd 500-600', 'Recycling bin not collected', 'low', 'resolved'),
('SC-2026-10489', 'Tom Brown', 'road_maintenance', 'Cargo Terminal Rd', 'Multiple potholes causing damage', 'normal', 'resolved')
ON DUPLICATE KEY UPDATE request_id=request_id;

-- Feedback
INSERT INTO feedback (resident_name, service, rating, comment) VALUES
('Emily Johnson', 'Waste Collection', 5, 'Collection crew was very responsive after my request. Great service!'),
('Anonymous', 'Street Light Repair', 4, 'Fixed within 2 days, but communication could be better.'),
('Robert Martinez', 'Public Transport', 2, 'Buses are consistently late. The schedule needs serious improvement.'),
('Jennifer Lee', 'Water Supply', 4, 'Water pressure improved after the repair. Thank you for quick response.'),
('Anonymous', 'Road Maintenance', 5, 'Pothole on Main St was fixed quickly. Very impressed!'),
('Tom Brown', 'Waste Collection', 3, 'Usually on time but recycling pickup was missed twice this month.')
ON DUPLICATE KEY UPDATE id=id;

-- Alerts
INSERT INTO alerts (title, description, alert_type, location, status) VALUES
('Traffic Sensor Overload', 'IOT-1015 at Highway 9 Interchange reporting severe congestion with 480+ vehicles/h', 'critical', 'Highway 9 Interchange', 'active'),
('Waste Bin Overflow', 'IOT-1018 at Highway 9 Rest Stop is 100% full and overflowing', 'critical', 'Highway 9 Rest Stop', 'active'),
('Air Quality Degraded', 'Industrial Park AQI at 98, approaching unhealthy threshold', 'warning', 'Industrial Park Center', 'active'),
('Low Water Pressure', 'Harbor District main line reporting 2.1 bar, below 3.0 threshold', 'warning', 'Harbor District Main', 'active'),
('Street Light Offline', 'IOT-1017 on Oakwood Ave offline due to low battery (12%)', 'warning', 'Oakwood Ave 1-50', 'active'),
('Energy Grid Overload', 'Industrial Main Feed at 90.6% capacity, approaching critical threshold', 'critical', 'Industrial Park', 'active'),
('Flooding at Pier 9', 'Flash flooding reported at Pier 9 underpass, avoid the area', 'critical', 'Pier 9 Underpass', 'active'),
('Water Main Repair', 'Canal St Extension closed for water main repair until 6 PM', 'information', 'Canal St Extension', 'read'),
('New Transit Hub Approved', 'Northgate Transit Hub modernization project has been approved', 'information', 'Northgate', 'read')
ON DUPLICATE KEY UPDATE id=id;

-- City Events
INSERT INTO city_events (title, description, category, location) VALUES
('Rush Hour Traffic Advisory', 'Expect heavy congestion on Highway 9 and Broadway between 5-7 PM. Consider alternate routes.', 'traffic', 'Highway 9'),
('Sunny, 22C', 'Clear skies expected throughout the day. Light wind from the northwest.', 'weather', 'Citywide'),
('Flash Flood Warning', 'Flash flooding at Pier 9 underpass. Water rescue team deployed. Avoid the area.', 'emergency', 'Pier 9 Underpass'),
('Downtown Street Festival', 'Annual Downtown Street Festival on Main St. Road closures from 10 AM to 8 PM.', 'event', 'Main St'),
('Bus Route 9 Detour', 'Route 9 buses detouring via Oakwood Ave due to Canal St water main repair.', 'transport', 'Canal St'),
('Water Main Repair Notice', 'Canal St Extension closed for emergency water main repair. Expected completion by 6 PM.', 'public_notice', 'Canal St Extension'),
('Air Quality Advisory', 'Industrial Park area experiencing elevated PM2.5 levels. Sensitive groups should limit outdoor activity.', 'public_notice', 'Industrial Park')
ON DUPLICATE KEY UPDATE id=id;
