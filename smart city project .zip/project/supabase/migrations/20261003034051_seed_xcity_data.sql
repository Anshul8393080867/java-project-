/*
# XCityManagement — Seed Data

Populates all tables with realistic sample data for the smart city dashboard.
Re-runnable: clears existing data first.

## Notes
- Emergency incident type 'accident' changed to 'police' (accident is not in the valid type set).
*/

DO $$ BEGIN
  DELETE FROM air_quality_stations;
  DELETE FROM emergency_incidents;
  DELETE FROM citizen_reports;
  DELETE FROM waste_routes;
  DELETE FROM waste_bins;
  DELETE FROM energy_grids;
  DELETE FROM traffic_incidents;
  DELETE FROM traffic_sensors;
  DELETE FROM city_zones;
END $$;

-- ============================================================
-- 1. CITY ZONES
-- ============================================================
INSERT INTO city_zones (name, district_code, area_km2, population) VALUES
  ('Downtown', 'DT', 12.50, 85000),
  ('Riverside', 'RV', 18.30, 62000),
  ('Northgate', 'NG', 22.10, 74000),
  ('Industrial Park', 'IP', 15.80, 12000),
  ('Westview', 'WV', 28.40, 95000),
  ('Harbor District', 'HD', 9.70, 38000);

-- ============================================================
-- 2+ : All dependent data inside DO block for zone ID refs
-- ============================================================
DO $$
DECLARE
  dt_id uuid; rv_id uuid; ng_id uuid; ip_id uuid; wv_id uuid; hd_id uuid;
BEGIN
  SELECT id INTO dt_id FROM city_zones WHERE district_code = 'DT';
  SELECT id INTO rv_id FROM city_zones WHERE district_code = 'RV';
  SELECT id INTO ng_id FROM city_zones WHERE district_code = 'NG';
  SELECT id INTO ip_id FROM city_zones WHERE district_code = 'IP';
  SELECT id INTO wv_id FROM city_zones WHERE district_code = 'WV';
  SELECT id INTO hd_id FROM city_zones WHERE district_code = 'HD';

  -- TRAFFIC SENSORS
  INSERT INTO traffic_sensors (zone_id, location_name, latitude, longitude, current_speed, avg_speed, congestion_level, vehicle_count, status) VALUES
    (dt_id, 'Main St & 5th Ave', 40.7589, -73.9851, 22.50, 45.00, 'high', 320, 'active'),
    (dt_id, 'Broadway & 42nd', 40.7549, -73.9840, 12.30, 40.00, 'severe', 510, 'active'),
    (dt_id, 'Park Ave & 38th', 40.7499, -73.9770, 35.00, 50.00, 'moderate', 180, 'active'),
    (rv_id, 'River Road Bridge', 40.7400, -74.0000, 48.00, 55.00, 'low', 95, 'active'),
    (rv_id, 'Canal St Extension', 40.7350, -73.9950, 28.00, 45.00, 'moderate', 210, 'active'),
    (ng_id, 'Northgate Blvd', 40.7800, -73.9600, 52.00, 58.00, 'low', 75, 'active'),
    (ng_id, 'Highway 9 Interchange', 40.7850, -73.9550, 15.00, 65.00, 'severe', 480, 'active'),
    (ng_id, 'Oakwood Ave', 40.7720, -73.9680, 42.00, 50.00, 'low', 110, 'maintenance'),
    (ip_id, 'Factory Row', 40.7100, -74.0200, 38.00, 48.00, 'low', 85, 'active'),
    (ip_id, 'Cargo Terminal Rd', 40.7050, -74.0250, 25.00, 42.00, 'moderate', 195, 'active'),
    (wv_id, 'Sunset Blvd', 40.7200, -74.0100, 30.00, 47.00, 'moderate', 240, 'active'),
    (hd_id, 'Pier 9 Access Rd', 40.6900, -74.0400, 18.00, 38.00, 'high', 290, 'active');

  -- TRAFFIC INCIDENTS
  INSERT INTO traffic_incidents (zone_id, type, location, severity, status, description, reported_at) VALUES
    (dt_id, 'accident', 'Broadway & 42nd', 'major', 'active', 'Two-vehicle collision blocking right lane', now() - interval '25 minutes'),
    (ng_id, 'congestion', 'Highway 9 Interchange', 'moderate', 'active', 'Heavy backup due to rush hour volume', now() - interval '1 hour'),
    (dt_id, 'hazard', 'Park Ave & 38th', 'minor', 'monitoring', 'Debris in roadway reported by driver', now() - interval '45 minutes'),
    (ip_id, 'roadwork', 'Cargo Terminal Rd', 'moderate', 'active', 'Scheduled road resurfacing, single lane open', now() - interval '2 hours'),
    (rv_id, 'closure', 'Canal St Extension', 'major', 'active', 'Water main repair, full closure until 6 PM', now() - interval '3 hours'),
    (wv_id, 'accident', 'Sunset Blvd & Oak', 'minor', 'resolved', 'Minor fender bender, vehicles moved to shoulder', now() - interval '5 hours'),
    (hd_id, 'hazard', 'Pier 9 Access Rd', 'moderate', 'active', 'Flooding at underpass, avoid area', now() - interval '40 minutes'),
    (dt_id, 'congestion', 'Main St & 5th Ave', 'minor', 'resolved', 'Temporary congestion from event exit', now() - interval '6 hours');

  -- ENERGY GRIDS
  INSERT INTO energy_grids (zone_id, name, capacity_kw, current_load_kw, renewable_pct, status) VALUES
    (dt_id, 'Downtown Grid Alpha', 50000, 41500, 22.5, 'operational'),
    (dt_id, 'Downtown Grid Beta', 35000, 31000, 18.0, 'degraded'),
    (rv_id, 'Riverside Solar Network', 28000, 19200, 68.5, 'operational'),
    (ng_id, 'Northgate Power Hub', 42000, 28700, 35.0, 'operational'),
    (ip_id, 'Industrial Main Feed', 80000, 72500, 12.0, 'operational'),
    (ip_id, 'Industrial Backup Grid', 30000, 0, 5.0, 'maintenance'),
    (wv_id, 'Westview Substation 7', 38000, 24300, 45.5, 'operational'),
    (hd_id, 'Harbor Wind Array', 22000, 17600, 82.0, 'operational');

  -- WASTE BINS
  INSERT INTO waste_bins (zone_id, location, fill_level, capacity_liters, type, status, last_collected_at, updated_at) VALUES
    (dt_id, 'Main St Plaza', 85, 240, 'general', 'full', now() - interval '2 days', now() - interval '1 hour'),
    (dt_id, 'Broadway Subway Exit', 95, 360, 'general', 'overflowing', now() - interval '3 days', now() - interval '30 minutes'),
    (dt_id, 'Central Park East', 40, 240, 'recycling', 'filling', now() - interval '1 day', now() - interval '2 hours'),
    (rv_id, 'River Walk Entrance', 60, 240, 'general', 'filling', now() - interval '1 day', now() - interval '3 hours'),
    (rv_id, 'Canal St Park', 30, 240, 'organic', 'filling', now() - interval '2 days', now() - interval '5 hours'),
    (ng_id, 'Northgate Mall Lot A', 70, 360, 'general', 'filling', now() - interval '1 day', now() - interval '1 hour'),
    (ng_id, 'Highway 9 Rest Stop', 100, 360, 'general', 'overflowing', now() - interval '4 days', now() - interval '20 minutes'),
    (ng_id, 'Oakwood Transit Hub', 15, 240, 'recycling', 'empty', now() - interval '12 hours', now() - interval '6 hours'),
    (ip_id, 'Factory Row Loading Dock', 55, 1100, 'hazardous', 'filling', now() - interval '2 days', now() - interval '4 hours'),
    (ip_id, 'Cargo Terminal Cafeteria', 45, 240, 'organic', 'filling', now() - interval '1 day', now() - interval '3 hours'),
    (wv_id, 'Sunset Blvd Bus Stop', 80, 240, 'general', 'full', now() - interval '2 days', now() - interval '90 minutes'),
    (wv_id, 'Westview Community Center', 25, 360, 'recycling', 'filling', now() - interval '1 day', now() - interval '4 hours'),
    (wv_id, 'Oakwood Park Playground', 10, 240, 'general', 'empty', now() - interval '10 hours', now() - interval '8 hours'),
    (hd_id, 'Pier 9 Boardwalk', 90, 240, 'general', 'full', now() - interval '3 days', now() - interval '45 minutes'),
    (hd_id, 'Harbor Fish Market', 65, 360, 'organic', 'filling', now() - interval '1 day', now() - interval '2 hours'),
    (hd_id, 'Marina Parking Lot', 35, 240, 'recycling', 'filling', now() - interval '1 day', now() - interval '5 hours'),
    (dt_id, 'City Hall Steps', 50, 240, 'general', 'filling', now() - interval '1 day', now() - interval '3 hours'),
    (rv_id, 'Riverside Amphitheater', 20, 360, 'general', 'filling', now() - interval '18 hours', now() - interval '7 hours'),
    (ng_id, 'Northgate Library', 5, 240, 'recycling', 'empty', now() - interval '6 hours', now() - interval '10 hours'),
    (wv_id, 'Sunset Hills Apartments', 75, 360, 'general', 'filling', now() - interval '2 days', now() - interval '1 hour');

  -- WASTE ROUTES
  INSERT INTO waste_routes (driver_name, vehicle_id, zone_id, status, scheduled_date, bins_collected, total_bins, created_at) VALUES
    ('Marcus Chen', 'TRK-014', dt_id, 'in_progress', CURRENT_DATE, 8, 15, now() - interval '4 hours'),
    ('Sarah Okafor', 'TRK-022', rv_id, 'in_progress', CURRENT_DATE, 3, 8, now() - interval '3 hours'),
    ('Diego Ramirez', 'TRK-031', ng_id, 'scheduled', CURRENT_DATE, 0, 12, now() - interval '2 hours'),
    ('Priya Patel', 'TRK-018', wv_id, 'completed', CURRENT_DATE, 14, 14, now() - interval '8 hours'),
    ('James Whitfield', 'TRK-007', hd_id, 'delayed', CURRENT_DATE, 2, 6, now() - interval '6 hours');

  -- CITIZEN REPORTS
  INSERT INTO citizen_reports (zone_id, category, description, location, status, priority, reporter_name, upvotes, created_at) VALUES
    (dt_id, 'pothole', 'Large pothole near the intersection, damaging tires', 'Main St & 5th Ave', 'in_progress', 'high', 'Michael R.', 24, now() - interval '2 days'),
    (dt_id, 'streetlight', 'Streetlight has been out for a week, very dark at night', 'Broadway & 42nd', 'submitted', 'normal', 'Anonymous', 8, now() - interval '1 day'),
    (rv_id, 'water', 'Water pressure very low in the mornings', 'River Road 100-200 block', 'reviewing', 'high', 'Lisa K.', 15, now() - interval '3 days'),
    (rv_id, 'graffiti', 'Extensive graffiti on the canal bridge walls', 'Canal St Bridge', 'submitted', 'low', 'Tom B.', 3, now() - interval '12 hours'),
    (ng_id, 'noise', 'Construction noise starting before 6 AM on weekends', 'Highway 9 residential area', 'in_progress', 'normal', 'Anonymous', 31, now() - interval '4 days'),
    (ng_id, 'traffic_signal', 'Traffic signal timing seems off, causing long waits', 'Highway 9 Interchange', 'reviewing', 'urgent', 'Robert M.', 47, now() - interval '2 days'),
    (ip_id, 'pothole', 'Multiple potholes on Cargo Terminal Rd', 'Cargo Terminal Rd', 'resolved', 'normal', 'Factory Manager', 12, now() - interval '10 days'),
    (wv_id, 'sanitation', 'Trash collection missed our street for 2 weeks', 'Sunset Blvd 500-600 block', 'resolved', 'high', 'Jennifer L.', 28, now() - interval '8 days'),
    (wv_id, 'parking', 'Illegal parking blocking fire hydrant', 'Oakwood Park entrance', 'submitted', 'urgent', 'Anonymous', 19, now() - interval '6 hours'),
    (hd_id, 'streetlight', 'Three streetlights flickering on Pier 9 Boardwalk', 'Pier 9 Boardwalk', 'in_progress', 'normal', 'Captain Ahab', 7, now() - interval '3 days'),
    (hd_id, 'water', 'Storm drain overflowing during rain', 'Harbor Fish Market area', 'reviewing', 'high', 'Fish Market Owner', 22, now() - interval '5 days'),
    (dt_id, 'noise', 'Loud music from venue past midnight every weekend', 'Park Ave 30-40 block', 'rejected', 'low', 'Frustrated Resident', 5, now() - interval '7 days'),
    (dt_id, 'traffic_signal', 'Pedestrian crossing signal too fast for elderly', 'City Hall intersection', 'submitted', 'normal', 'Eleanor S.', 16, now() - interval '1 day'),
    (ng_id, 'pothole', 'Deep pothole on Oakwood Ave near school', 'Oakwood Ave & School Rd', 'in_progress', 'urgent', 'Parent Group', 35, now() - interval '3 days'),
    (wv_id, 'graffiti', 'Vandalism at Westview Community Center wall', 'Westview Community Center', 'resolved', 'low', 'Center Staff', 2, now() - interval '12 days');

  -- EMERGENCY INCIDENTS (valid types: fire, medical, police, natural, hazmat, rescue)
  INSERT INTO emergency_incidents (type, location, zone_id, severity, status, responders_count, description, reported_at) VALUES
    ('fire', 'Industrial Park Factory Row Building 7', ip_id, 'major', 'contained', 18, 'Three-alarm fire at chemical processing facility, hazardous materials team on scene', now() - interval '2 hours'),
    ('medical', 'Downtown Broadway Subway Station', dt_id, 'moderate', 'active', 4, 'Medical emergency: cardiac arrest reported on platform 2', now() - interval '20 minutes'),
    ('police', 'Highway 9 Northgate Interchange', ng_id, 'major', 'active', 6, 'Multi-vehicle collision with entrapment, police and EMS on scene for traffic control', now() - interval '35 minutes'),
    ('natural', 'Harbor District Pier 9 Underpass', hd_id, 'moderate', 'active', 3, 'Flash flooding at underpass, water rescue team deployed', now() - interval '50 minutes'),
    ('police', 'Westview Sunset Blvd', wv_id, 'minor', 'resolved', 2, 'Reports of suspicious activity, area cleared', now() - interval '4 hours'),
    ('rescue', 'Riverside Canal St Bridge', rv_id, 'moderate', 'resolved', 5, 'Cat stranded on bridge structure, animal rescue completed', now() - interval '6 hours');

  -- AIR QUALITY STATIONS
  INSERT INTO air_quality_stations (zone_id, location, pm25, pm10, co2_ppm, temperature, humidity, aqi, status) VALUES
    (dt_id, 'City Hall Rooftop', 18.5, 32.0, 425.0, 22.5, 58.0, 62, 'active'),
    (dt_id, 'Central Park East', 14.2, 25.0, 410.0, 21.8, 62.0, 48, 'active'),
    (rv_id, 'Riverside Promenade', 12.0, 20.0, 395.0, 20.5, 68.0, 42, 'active'),
    (ng_id, 'Northgate Tower', 16.8, 28.0, 418.0, 23.0, 55.0, 56, 'active'),
    (ip_id, 'Industrial Park Center', 35.5, 58.0, 480.0, 25.2, 48.0, 98, 'active'),
    (ip_id, 'Factory Row East', 42.0, 68.0, 510.0, 26.0, 45.0, 115, 'maintenance'),
    (wv_id, 'Westview Hills', 10.5, 18.0, 388.0, 19.8, 72.0, 38, 'active'),
    (hd_id, 'Harbor Marina', 15.0, 24.0, 402.0, 18.5, 78.0, 50, 'active');

END $$;
