/*
# XCityManagement — Fix air_quality_stations column name

Fixes the `co2 ppm` column name which had a space causing a syntax error.
*/
ALTER TABLE IF EXISTS air_quality_stations RENAME COLUMN "co2 ppm" TO co2_ppm;
