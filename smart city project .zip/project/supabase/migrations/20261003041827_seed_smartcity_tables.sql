/*
# SmartCity AI — Seed new tables

Seeds city_users, iot_devices, resources, alerts, service_requests, feedback, city_events.
IOT-1030 status changed from 'warning' to 'alert' (valid check constraint value).
*/

DO $$ BEGIN
  DELETE FROM city_events;
  DELETE FROM feedback;
  DELETE FROM service_requests;
  DELETE FROM alerts;
  DELETE FROM resources;
  DELETE FROM iot_devices;
  DELETE FROM city_users;
END $$;

DO $$
DECLARE
  dt_id uuid; rv_id uuid; ng_id uuid; ip_id uuid; wv_id uuid; hd_id uuid;
  admin_id uuid; planner_id uuid; res_id uuid;
BEGIN
  SELECT id INTO dt_id FROM city_zones WHERE district_code = 'DT';
  SELECT id INTO rv_id FROM city_zones WHERE district_code = 'RV';
  SELECT id INTO ng_id FROM city_zones WHERE district_code = 'NG';
  SELECT id INTO ip_id FROM city_zones WHERE district_code = 'IP';
  SELECT id INTO wv_id FROM city_zones WHERE district_code = 'WV';
  SELECT id INTO hd_id FROM city_zones WHERE district_code = 'HD';

  INSERT INTO city_users (email, password, full_name, role, zone_id) VALUES
    ('admin@smartcity.ai', 'smartcity', 'Sarah Chen', 'admin', dt_id),
    ('planner@smartcity.ai', 'smartcity', 'Marcus Rivera', 'planner', ng_id),
    ('resident@smartcity.ai', 'smartcity', 'Emily Johnson', 'resident', wv_id),
    ('admin2@smartcity.ai', 'smartcity', 'David Park', 'admin', ip_id),
    ('resident2@smartcity.ai', 'smartcity', 'Liam OBrien', 'resident', dt_id),
    ('resident3@smartcity.ai', 'smartcity', 'Aisha Patel', 'resident', hd_id);

  SELECT id INTO admin_id FROM city_users WHERE email = 'admin@smartcity.ai';
  SELECT id INTO planner_id FROM city_users WHERE email = 'planner@smartcity.ai';
  SELECT id INTO res_id FROM city_users WHERE email = 'resident@smartcity.ai';

  INSERT INTO iot_devices (device_id, device_type, location, zone_id, status, battery_level, last_reading, last_updated) VALUES
    ('IOT-1001', 'traffic_sensor', 'Main St & 5th Ave', dt_id, 'online', 86, '320 vehicles/h', now() - interval '2 min'),
    ('IOT-1002', 'air_quality_sensor', 'City Hall Rooftop', dt_id, 'online', 72, 'AQI 62, PM2.5 18.5', now() - interval '5 min'),
    ('IOT-1003', 'smart_street_light', 'Broadway Ave 100-200', dt_id, 'online', 91, 'On, 80% brightness', now() - interval '1 min'),
    ('IOT-1004', 'energy_meter', 'Downtown Grid Alpha', dt_id, 'online', 100, '41.5 MW load', now() - interval '30 sec'),
    ('IOT-1005', 'waste_bin_sensor', 'Main St Plaza Bin', dt_id, 'alert', 45, '85% full', now() - interval '10 min'),
    ('IOT-1006', 'traffic_sensor', 'Broadway & 42nd', dt_id, 'online', 78, '510 vehicles/h', now() - interval '2 min'),
    ('IOT-1007', 'water_sensor', 'Downtown Water Main', dt_id, 'online', 95, '4.2 bar pressure', now() - interval '3 min'),
    ('IOT-1008', 'air_quality_sensor', 'Central Park East', dt_id, 'online', 88, 'AQI 48, PM2.5 14.2', now() - interval '5 min'),
    ('IOT-1009', 'traffic_sensor', 'River Road Bridge', rv_id, 'online', 82, '95 vehicles/h', now() - interval '2 min'),
    ('IOT-1010', 'waste_bin_sensor', 'River Walk Entrance', rv_id, 'online', 67, '60% full', now() - interval '8 min'),
    ('IOT-1011', 'energy_meter', 'Riverside Solar Network', rv_id, 'online', 100, '19.2 MW, 68.5% renewable', now() - interval '30 sec'),
    ('IOT-1012', 'smart_street_light', 'River Walk Promenade', rv_id, 'online', 90, 'On, 60% brightness', now() - interval '1 min'),
    ('IOT-1013', 'water_sensor', 'Riverside Treatment Plant', rv_id, 'maintenance', 100, 'Scheduled maintenance', now() - interval '1 hour'),
    ('IOT-1014', 'traffic_sensor', 'Northgate Blvd', ng_id, 'online', 74, '75 vehicles/h', now() - interval '2 min'),
    ('IOT-1015', 'traffic_sensor', 'Highway 9 Interchange', ng_id, 'alert', 38, '480 vehicles/h, severe', now() - interval '1 min'),
    ('IOT-1016', 'air_quality_sensor', 'Northgate Tower', ng_id, 'online', 81, 'AQI 56, PM2.5 16.8', now() - interval '5 min'),
    ('IOT-1017', 'smart_street_light', 'Oakwood Ave 1-50', ng_id, 'offline', 12, 'Offline - battery low', now() - interval '2 hours'),
    ('IOT-1018', 'waste_bin_sensor', 'Highway 9 Rest Stop', ng_id, 'alert', 23, '100% full - overflow', now() - interval '15 min'),
    ('IOT-1019', 'energy_meter', 'Northgate Power Hub', ng_id, 'online', 100, '28.7 MW load', now() - interval '30 sec'),
    ('IOT-1020', 'energy_meter', 'Industrial Main Feed', ip_id, 'online', 100, '72.5 MW load', now() - interval '30 sec'),
    ('IOT-1021', 'air_quality_sensor', 'Industrial Park Center', ip_id, 'alert', 65, 'AQI 98, PM2.5 35.5', now() - interval '5 min'),
    ('IOT-1022', 'water_sensor', 'Industrial Water Line', ip_id, 'online', 92, '3.8 bar pressure', now() - interval '3 min'),
    ('IOT-1023', 'waste_bin_sensor', 'Factory Row Loading Dock', ip_id, 'online', 80, '55% full', now() - interval '10 min'),
    ('IOT-1024', 'traffic_sensor', 'Cargo Terminal Rd', ip_id, 'online', 88, '195 vehicles/h', now() - interval '2 min'),
    ('IOT-1025', 'smart_street_light', 'Factory Row 1-20', ip_id, 'online', 85, 'On, 70% brightness', now() - interval '1 min'),
    ('IOT-1026', 'air_quality_sensor', 'Westview Hills', wv_id, 'online', 94, 'AQI 38, PM2.5 10.5', now() - interval '5 min'),
    ('IOT-1027', 'traffic_sensor', 'Sunset Blvd', wv_id, 'online', 76, '240 vehicles/h', now() - interval '2 min'),
    ('IOT-1028', 'waste_bin_sensor', 'Sunset Blvd Bus Stop', wv_id, 'online', 70, '80% full', now() - interval '8 min'),
    ('IOT-1029', 'smart_street_light', 'Harbor Marina Walk', hd_id, 'online', 89, 'On, 50% brightness', now() - interval '1 min'),
    ('IOT-1030', 'water_sensor', 'Harbor District Main', hd_id, 'alert', 55, '2.1 bar - low pressure', now() - interval '3 min');

  INSERT INTO resources (resource_name, allocated_amount, used_amount, unit, zone_id, date, efficiency, status) VALUES
    ('electricity', 50000, 41500, 'kWh', dt_id, CURRENT_DATE, 83.0, 'warning'),
    ('electricity', 50000, 38200, 'kWh', dt_id, CURRENT_DATE - 1, 76.4, 'optimal'),
    ('electricity', 50000, 39800, 'kWh', dt_id, CURRENT_DATE - 2, 79.6, 'optimal'),
    ('electricity', 50000, 42500, 'kWh', dt_id, CURRENT_DATE - 3, 85.0, 'warning'),
    ('electricity', 50000, 44200, 'kWh', dt_id, CURRENT_DATE - 4, 88.4, 'warning'),
    ('electricity', 50000, 41000, 'kWh', dt_id, CURRENT_DATE - 5, 82.0, 'optimal'),
    ('electricity', 50000, 39500, 'kWh', dt_id, CURRENT_DATE - 6, 79.0, 'optimal'),
    ('water', 800000, 640000, 'L', dt_id, CURRENT_DATE, 80.0, 'optimal'),
    ('water', 800000, 680000, 'L', dt_id, CURRENT_DATE - 1, 85.0, 'optimal'),
    ('water', 800000, 720000, 'L', dt_id, CURRENT_DATE - 2, 90.0, 'warning'),
    ('water', 800000, 610000, 'L', dt_id, CURRENT_DATE - 3, 76.3, 'optimal'),
    ('water', 800000, 590000, 'L', dt_id, CURRENT_DATE - 4, 73.8, 'optimal'),
    ('water', 800000, 650000, 'L', dt_id, CURRENT_DATE - 5, 81.3, 'optimal'),
    ('water', 800000, 670000, 'L', dt_id, CURRENT_DATE - 6, 83.8, 'optimal'),
    ('waste', 12000, 10440, 'kg', dt_id, CURRENT_DATE, 87.0, 'optimal'),
    ('waste', 12000, 9800, 'kg', dt_id, CURRENT_DATE - 1, 81.7, 'optimal'),
    ('waste', 12000, 11200, 'kg', dt_id, CURRENT_DATE - 2, 93.3, 'warning'),
    ('electricity', 28000, 19200, 'kWh', rv_id, CURRENT_DATE, 68.6, 'optimal'),
    ('electricity', 28000, 18500, 'kWh', rv_id, CURRENT_DATE - 1, 66.1, 'optimal'),
    ('electricity', 28000, 20100, 'kWh', rv_id, CURRENT_DATE - 2, 71.8, 'optimal'),
    ('water', 600000, 450000, 'L', rv_id, CURRENT_DATE, 75.0, 'optimal'),
    ('water', 600000, 480000, 'L', rv_id, CURRENT_DATE - 1, 80.0, 'optimal'),
    ('waste', 8000, 6800, 'kg', rv_id, CURRENT_DATE, 85.0, 'optimal'),
    ('electricity', 80000, 72500, 'kWh', ip_id, CURRENT_DATE, 90.6, 'critical'),
    ('electricity', 80000, 68000, 'kWh', ip_id, CURRENT_DATE - 1, 85.0, 'warning'),
    ('electricity', 80000, 69500, 'kWh', ip_id, CURRENT_DATE - 2, 86.9, 'warning'),
    ('water', 1000000, 850000, 'L', ip_id, CURRENT_DATE, 85.0, 'warning'),
    ('water', 1000000, 820000, 'L', ip_id, CURRENT_DATE - 1, 82.0, 'optimal'),
    ('waste', 15000, 13800, 'kg', ip_id, CURRENT_DATE, 92.0, 'warning'),
    ('electricity', 38000, 24300, 'kWh', wv_id, CURRENT_DATE, 63.9, 'optimal'),
    ('electricity', 38000, 22100, 'kWh', wv_id, CURRENT_DATE - 1, 58.2, 'optimal'),
    ('water', 500000, 380000, 'L', wv_id, CURRENT_DATE, 76.0, 'optimal'),
    ('waste', 10000, 8200, 'kg', wv_id, CURRENT_DATE, 82.0, 'optimal'),
    ('electricity', 22000, 17600, 'kWh', hd_id, CURRENT_DATE, 80.0, 'optimal'),
    ('water', 400000, 310000, 'L', hd_id, CURRENT_DATE, 77.5, 'optimal'),
    ('waste', 6000, 4800, 'kg', hd_id, CURRENT_DATE, 80.0, 'optimal');

  INSERT INTO alerts (title, description, alert_type, location, zone_id, status) VALUES
    ('Traffic Sensor Overload', 'IOT-1015 at Highway 9 Interchange reporting severe congestion with 480+ vehicles/h', 'critical', 'Highway 9 Interchange', ng_id, 'active'),
    ('Waste Bin Overflow', 'IOT-1018 at Highway 9 Rest Stop is 100% full and overflowing', 'critical', 'Highway 9 Rest Stop', ng_id, 'active'),
    ('Air Quality Degraded', 'Industrial Park AQI at 98, approaching unhealthy threshold', 'warning', 'Industrial Park Center', ip_id, 'active'),
    ('Low Water Pressure', 'Harbor District main line reporting 2.1 bar, below 3.0 threshold', 'warning', 'Harbor District Main', hd_id, 'active'),
    ('Street Light Offline', 'IOT-1017 on Oakwood Ave offline due to low battery (12%)', 'warning', 'Oakwood Ave 1-50', ng_id, 'active'),
    ('Energy Grid Overload', 'Industrial Main Feed at 90.6% capacity, approaching critical threshold', 'critical', 'Industrial Park', ip_id, 'active'),
    ('Downtown Grid Beta Degraded', 'Grid Beta operating at 88.6% capacity with degraded performance', 'warning', 'Downtown Grid Beta', dt_id, 'active'),
    ('Flooding at Pier 9', 'Flash flooding reported at Pier 9 underpass, avoid the area', 'critical', 'Pier 9 Underpass', hd_id, 'active'),
    ('Water Main Repair', 'Canal St Extension closed for water main repair until 6 PM', 'information', 'Canal St Extension', rv_id, 'read'),
    ('New Transit Hub Approved', 'Northgate Transit Hub modernization project has been approved', 'information', 'Northgate', ng_id, 'read'),
    ('Solar Farm Progress', 'Industrial Solar Farm Phase 1 at 58% completion', 'information', 'Industrial Park', ip_id, 'active'),
    ('Community Library Approved', 'Oakwood Community Library project approved, construction begins 2027', 'information', 'Oakwood', ng_id, 'read');

  INSERT INTO service_requests (request_id, resident_id, resident_name, service_type, location, description, priority, status) VALUES
    ('SC-2026-10482', res_id, 'Emily Johnson', 'street_light', 'Sunset Blvd & Oak St', 'Streetlight has been flickering for 3 days near the bus stop', 'normal', 'in_progress'),
    ('SC-2026-10483', res_id, 'Emily Johnson', 'waste_collection', 'Sunset Blvd 500-600 block', 'Trash collection missed our street for 2 weeks straight', 'high', 'submitted'),
    ('SC-2026-10484', NULL, 'Anonymous', 'road_maintenance', 'Main St & 5th Ave', 'Large pothole near the intersection is damaging tires', 'high', 'in_progress'),
    ('SC-2026-10485', NULL, 'Anonymous', 'water_supply', 'River Road 100-200 block', 'Water pressure very low in the mornings, barely a trickle', 'high', 'in_progress'),
    ('SC-2026-10486', NULL, 'Anonymous', 'electricity', 'Park Ave 30-40 block', 'Power flickering during evening hours, affecting multiple homes', 'urgent', 'submitted'),
    ('SC-2026-10487', NULL, 'Robert Martinez', 'public_transport', 'Highway 9 Interchange', 'Bus schedule is unreliable, buses are 20+ min late consistently', 'normal', 'in_progress'),
    ('SC-2026-10488', NULL, 'Jennifer Lee', 'waste_collection', 'Sunset Blvd 500-600 block', 'Recycling bin was not collected on scheduled day', 'low', 'resolved'),
    ('SC-2026-10489', NULL, 'Tom Brown', 'road_maintenance', 'Cargo Terminal Rd', 'Multiple potholes on cargo terminal road causing vehicle damage', 'normal', 'resolved'),
    ('SC-2026-10490', NULL, 'Eleanor Smith', 'street_light', 'City Hall intersection', 'Pedestrian crossing signal too fast for elderly residents', 'normal', 'in_progress'),
    ('SC-2026-10491', NULL, 'Anonymous', 'emergency_services', 'Pier 9 Boardwalk', 'Three streetlights out near the boardwalk, safety concern at night', 'high', 'submitted');

  INSERT INTO feedback (resident_id, resident_name, service, rating, comment) VALUES
    (res_id, 'Emily Johnson', 'Waste Collection', 5, 'Collection crew was very responsive after I submitted a request. Great service!'),
    (NULL, 'Anonymous', 'Street Light Repair', 4, 'Fixed within 2 days, but communication could be better.'),
    (NULL, 'Robert Martinez', 'Public Transport', 2, 'Buses are consistently late. The schedule needs serious improvement.'),
    (NULL, 'Jennifer Lee', 'Water Supply', 4, 'Water pressure improved after the repair. Thank you for the quick response.'),
    (NULL, 'Anonymous', 'Road Maintenance', 5, 'Pothole on Main St was fixed quickly. Very impressed!'),
    (NULL, 'Tom Brown', 'Waste Collection', 3, 'Collection is usually on time but recycling pickup was missed twice this month.'),
    (NULL, 'Eleanor Smith', 'Street Light Repair', 4, 'Good service overall, but the pedestrian signal timing still needs adjustment.'),
    (NULL, 'Anonymous', 'Emergency Services', 5, 'Response time was excellent when I reported a streetlight outage. Very professional team.');

  INSERT INTO city_events (title, description, category, location, zone_id, start_time, end_time) VALUES
    ('Rush Hour Traffic Advisory', 'Expect heavy congestion on Highway 9 and Broadway between 5-7 PM. Consider alternate routes.', 'traffic', 'Highway 9', ng_id, now() - interval '10 min', now() + interval '3 hours'),
    ('Sunny, 22C', 'Clear skies expected throughout the day. Light wind from the northwest.', 'weather', 'Citywide', NULL, now(), now() + interval '24 hours'),
    ('Flash Flood Warning', 'Flash flooding at Pier 9 underpass. Water rescue team deployed. Avoid the area.', 'emergency', 'Pier 9 Underpass', hd_id, now() - interval '40 min', now() + interval '4 hours'),
    ('Downtown Street Festival', 'Annual Downtown Street Festival on Main St. Road closures from 10 AM to 8 PM.', 'event', 'Main St', dt_id, now() + interval '2 days', now() + interval '2 days 10 hours'),
    ('Bus Route 9 Detour', 'Route 9 buses detouring via Oakwood Ave due to Canal St water main repair.', 'transport', 'Canal St', rv_id, now() - interval '2 hours', now() + interval '6 hours'),
    ('Water Main Repair Notice', 'Canal St Extension closed for emergency water main repair. Expected completion by 6 PM.', 'public_notice', 'Canal St Extension', rv_id, now() - interval '3 hours', now() + interval '3 hours'),
    ('Air Quality Advisory', 'Industrial Park area experiencing elevated PM2.5 levels. Sensitive groups should limit outdoor activity.', 'public_notice', 'Industrial Park', ip_id, now() - interval '1 hour', now() + interval '12 hours'),
    ('Community Town Hall', 'Monthly town hall meeting at Westview Community Center. Topic: New park development project.', 'event', 'Westview Community Center', wv_id, now() + interval '3 days', now() + interval '3 days 2 hours');

END $$;
