/*
# XCityManagement — Add city_planning_projects table

Adds a table for urban planning infrastructure and development projects.

## New Table
- `city_planning_projects` — Tracks city development projects with type, budget, timeline, and status.

## Security
- RLS enabled, public CRUD for anon + authenticated (single-tenant dashboard).
*/

CREATE TABLE IF NOT EXISTS city_planning_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('transport','housing','park','utility','commercial','green_space','education','healthcare')),
  description text,
  budget numeric(14,2) NOT NULL DEFAULT 0,
  spent numeric(14,2) NOT NULL DEFAULT 0,
  progress integer NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  status text NOT NULL DEFAULT 'planning' CHECK (status IN ('planning','approved','in_progress','completed','on_hold','cancelled')),
  start_date date,
  estimated_end date,
  contractor text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_planning_projects_zone ON city_planning_projects(zone_id);
CREATE INDEX IF NOT EXISTS idx_planning_projects_status ON city_planning_projects(status);

ALTER TABLE city_planning_projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cpp_select" ON city_planning_projects;
CREATE POLICY "cpp_select" ON city_planning_projects FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "cpp_insert" ON city_planning_projects;
CREATE POLICY "cpp_insert" ON city_planning_projects FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "cpp_update" ON city_planning_projects;
CREATE POLICY "cpp_update" ON city_planning_projects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "cpp_delete" ON city_planning_projects;
CREATE POLICY "cpp_delete" ON city_planning_projects FOR DELETE TO anon, authenticated USING (true);

-- Seed sample projects
DO $$
DECLARE
  dt_id uuid; rv_id uuid; ng_id uuid; ip_id uuid; wv_id uuid; hd_id uuid;
BEGIN
  SELECT id INTO dt_id FROM city_zones WHERE district_code = 'DT';
  SELECT id INTO rv_id FROM city_zones WHERE district_code = 'RV';
  SELECT id INTO ng_id FROM city_zones WHERE district_code = 'NG';
  SELECT id INTO ip_id FROM city_zones WHERE district_code = 'IP';
  SELECT id INTO wv_id FROM city_zones WHERE district_code = 'WV';
  SELECT id INTO hd_id FROM city_zones WHERE district_code = 'HD';

  INSERT INTO city_planning_projects (zone_id, name, type, description, budget, spent, progress, status, start_date, estimated_end, contractor) VALUES
    (dt_id, 'Downtown Pedestrian Mall', 'transport', 'Convert Main St to pedestrian-only zone with bike lanes and greenery', 12500000, 5200000, 42, 'in_progress', '2026-06-01', '2027-06-01', 'UrbanBuild Corp'),
    (dt_id, 'Central Park Revitalization Phase 2', 'park', 'Upgrade playground, add splash pad, restore historic bandstand', 3800000, 3100000, 85, 'in_progress', '2026-03-15', '2026-11-30', 'GreenSpace LLC'),
    (rv_id, 'Riverside Affordable Housing', 'housing', '240-unit mixed-income housing development with ground-floor retail', 48000000, 8500000, 18, 'in_progress', '2026-08-01', '2028-08-01', 'CommunityBuild Partners'),
    (rv_id, 'River Walk Extension', 'green_space', 'Extend riverside promenade 2.5km with lighting and seating', 6500000, 6500000, 100, 'completed', '2025-09-01', '2026-05-15', 'Riverside Construction'),
    (ng_id, 'Northgate Transit Hub Modernization', 'transport', 'Upgrade bus terminal with real-time displays and covered platforms', 9500000, 1200000, 12, 'in_progress', '2026-07-01', '2027-09-01', 'TransitWorks Inc'),
    (ng_id, 'Oakwood Community Library', 'education', 'New 2-story public library with makerspace and community rooms', 7200000, 0, 0, 'approved', '2027-01-01', '2028-06-01', 'Civic Structures Ltd'),
    (ip_id, 'Industrial Solar Farm Phase 1', 'utility', '5MW rooftop solar installation across industrial warehouses', 15000000, 8800000, 58, 'in_progress', '2026-04-01', '2027-03-01', 'SunPower Industrial'),
    (wv_id, 'Westview Park & Recreation Complex', 'park', 'Multi-sport complex with fields, courts, and community center', 22000000, 4500000, 22, 'in_progress', '2026-05-01', '2028-05-01', 'SportBuild Co'),
    (wv_id, 'Sunset Boulevard Streetscape', 'transport', 'Road diet, protected bike lanes, streetscape improvements', 5500000, 0, 0, 'planning', NULL, NULL, NULL),
    (hd_id, 'Harbor Mixed-Use Development', 'commercial', 'Waterfront retail, office, and residential complex with public plaza', 85000000, 15000000, 15, 'in_progress', '2026-06-15', '2029-06-15', 'HarborPoint Development'),
    (hd_id, 'Pier 9 Flood Barrier System', 'utility', 'Storm surge barriers and improved drainage for harbor district', 18500000, 0, 0, 'approved', '2027-03-01', '2028-12-01', NULL),
    (dt_id, 'Downtown Smart Streetlight Upgrade', 'utility', 'Replace 1,200 streetlights with LED smart fixtures with sensors', 4200000, 3900000, 95, 'in_progress', '2026-02-01', '2026-10-15', 'BrightCity Systems');
END $$;
