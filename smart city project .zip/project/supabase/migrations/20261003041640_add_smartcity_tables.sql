/*
# SmartCity AI — Add new tables for full smart city platform

Adds tables for: city_users (app-level auth), iot_devices, resources, alerts,
service_requests, feedback, city_events.

All single-tenant with anon+authenticated RLS.
*/

-- ============================================================
-- CITY USERS (app-level login, 3 roles)
-- ============================================================
CREATE TABLE IF NOT EXISTS city_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password text NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin','planner','resident')),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- IoT DEVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS iot_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL UNIQUE,
  device_type text NOT NULL CHECK (device_type IN ('traffic_sensor','air_quality_sensor','water_sensor','energy_meter','smart_street_light','waste_bin_sensor')),
  location text NOT NULL,
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'online' CHECK (status IN ('online','offline','maintenance','alert')),
  battery_level integer NOT NULL DEFAULT 100 CHECK (battery_level >= 0 AND battery_level <= 100),
  last_reading text,
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- RESOURCES (electricity, water, waste)
-- ============================================================
CREATE TABLE IF NOT EXISTS resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_name text NOT NULL CHECK (resource_name IN ('electricity','water','waste')),
  allocated_amount numeric(14,2) NOT NULL DEFAULT 0,
  used_amount numeric(14,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'kWh',
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  efficiency numeric(5,2) NOT NULL DEFAULT 100 CHECK (efficiency >= 0 AND efficiency <= 100),
  status text NOT NULL DEFAULT 'optimal' CHECK (status IN ('optimal','warning','critical','maintenance')),
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- ALERTS
-- ============================================================
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  alert_type text NOT NULL CHECK (alert_type IN ('critical','warning','information')),
  location text NOT NULL,
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','read','resolved')),
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- SERVICE REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS service_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id text NOT NULL UNIQUE,
  resident_id uuid REFERENCES city_users(id) ON DELETE SET NULL,
  resident_name text NOT NULL DEFAULT 'Anonymous',
  service_type text NOT NULL CHECK (service_type IN ('water_supply','electricity','waste_collection','road_maintenance','street_light','public_transport','emergency_services')),
  location text NOT NULL,
  description text NOT NULL,
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','in_progress','resolved','rejected')),
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- ============================================================
-- FEEDBACK
-- ============================================================
CREATE TABLE IF NOT EXISTS feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  resident_id uuid REFERENCES city_users(id) ON DELETE SET NULL,
  resident_name text NOT NULL DEFAULT 'Anonymous',
  service text NOT NULL,
  rating integer NOT NULL DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- CITY EVENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS city_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL CHECK (category IN ('traffic','weather','emergency','event','transport','public_notice')),
  location text,
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  start_time timestamptz DEFAULT now(),
  end_time timestamptz
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_iot_devices_zone ON iot_devices(zone_id);
CREATE INDEX IF NOT EXISTS idx_iot_devices_status ON iot_devices(status);
CREATE INDEX IF NOT EXISTS idx_resources_zone ON resources(zone_id);
CREATE INDEX IF NOT EXISTS idx_resources_date ON resources(date);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_service_requests_resident ON service_requests(resident_id);
CREATE INDEX IF NOT EXISTS idx_service_requests_status ON service_requests(status);
CREATE INDEX IF NOT EXISTS idx_feedback_resident ON feedback(resident_id);
CREATE INDEX IF NOT EXISTS idx_city_events_category ON city_events(category);

-- ============================================================
-- RLS
-- ============================================================
ALTER TABLE city_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE iot_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE city_events ENABLE ROW LEVEL SECURITY;

-- city_users
DROP POLICY IF EXISTS "cu_select" ON city_users; CREATE POLICY "cu_select" ON city_users FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "cu_insert" ON city_users; CREATE POLICY "cu_insert" ON city_users FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "cu_update" ON city_users; CREATE POLICY "cu_update" ON city_users FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "cu_delete" ON city_users; CREATE POLICY "cu_delete" ON city_users FOR DELETE TO anon, authenticated USING (true);

-- iot_devices
DROP POLICY IF EXISTS "iot_select" ON iot_devices; CREATE POLICY "iot_select" ON iot_devices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "iot_insert" ON iot_devices; CREATE POLICY "iot_insert" ON iot_devices FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "iot_update" ON iot_devices; CREATE POLICY "iot_update" ON iot_devices FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "iot_delete" ON iot_devices; CREATE POLICY "iot_delete" ON iot_devices FOR DELETE TO anon, authenticated USING (true);

-- resources
DROP POLICY IF EXISTS "res_select" ON resources; CREATE POLICY "res_select" ON resources FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "res_insert" ON resources; CREATE POLICY "res_insert" ON resources FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "res_update" ON resources; CREATE POLICY "res_update" ON resources FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "res_delete" ON resources; CREATE POLICY "res_delete" ON resources FOR DELETE TO anon, authenticated USING (true);

-- alerts
DROP POLICY IF EXISTS "al_select" ON alerts; CREATE POLICY "al_select" ON alerts FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "al_insert" ON alerts; CREATE POLICY "al_insert" ON alerts FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "al_update" ON alerts; CREATE POLICY "al_update" ON alerts FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "al_delete" ON alerts; CREATE POLICY "al_delete" ON alerts FOR DELETE TO anon, authenticated USING (true);

-- service_requests
DROP POLICY IF EXISTS "sr_select" ON service_requests; CREATE POLICY "sr_select" ON service_requests FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "sr_insert" ON service_requests; CREATE POLICY "sr_insert" ON service_requests FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "sr_update" ON service_requests; CREATE POLICY "sr_update" ON service_requests FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "sr_delete" ON service_requests; CREATE POLICY "sr_delete" ON service_requests FOR DELETE TO anon, authenticated USING (true);

-- feedback
DROP POLICY IF EXISTS "fb_select" ON feedback; CREATE POLICY "fb_select" ON feedback FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "fb_insert" ON feedback; CREATE POLICY "fb_insert" ON feedback FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "fb_update" ON feedback; CREATE POLICY "fb_update" ON feedback FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "fb_delete" ON feedback; CREATE POLICY "fb_delete" ON feedback FOR DELETE TO anon, authenticated USING (true);

-- city_events
DROP POLICY IF EXISTS "ce_select" ON city_events; CREATE POLICY "ce_select" ON city_events FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ce_insert" ON city_events; CREATE POLICY "ce_insert" ON city_events FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ce_update" ON city_events; CREATE POLICY "ce_update" ON city_events FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ce_delete" ON city_events; CREATE POLICY "ce_delete" ON city_events FOR DELETE TO anon, authenticated USING (true);
