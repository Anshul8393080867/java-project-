/*
# XCityManagement — Smart City Management Database Schema

Creates the complete database schema for the XCityManagement smart city platform.
This is a single-tenant system (no authentication required) — all data is
intentionally public/shared for the city operations dashboard.

## New Tables

1. `city_zones` — City districts/neighborhoods with population and area data.
2. `traffic_sensors` — Real-time traffic flow sensors monitoring speed, congestion, and vehicle count.
3. `traffic_incidents` — Reported traffic incidents (accidents, roadwork, closures, hazards).
4. `energy_grids` — Power grid zones tracking capacity, load, and renewable percentage.
5. `waste_bins` — Smart waste bins with fill-level monitoring.
6. `waste_routes` — Garbage collection routes and schedules.
7. `citizen_reports` — Citizen-submitted complaints and service requests (311-style).
8. `emergency_incidents` — Active and resolved emergency incidents (fire, medical, police, natural).
9. `air_quality_stations` — Air quality and environmental monitoring stations.

## Security

- RLS enabled on all tables.
- All policies use `TO anon, authenticated` since this is a no-auth public dashboard.
- Full CRUD allowed for all roles (intentionally shared city operations data).

## Notes

1. All tables use `gen_random_uuid()` for primary keys.
2. Timestamps default to `now()`.
3. Foreign keys link sensor/incident data to city zones.
4. Status fields use text with CHECK constraints for valid values.
5. Idempotent — safe to re-run.
*/

-- ============================================================
-- 1. CITY ZONES
-- ============================================================
CREATE TABLE IF NOT EXISTS city_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  district_code text NOT NULL UNIQUE,
  area_km2 numeric(10,2) NOT NULL DEFAULT 0,
  population integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- 2. TRAFFIC SENSORS
-- ============================================================
CREATE TABLE IF NOT EXISTS traffic_sensors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  location_name text NOT NULL,
  latitude numeric(10,7) NOT NULL,
  longitude numeric(10,7) NOT NULL,
  current_speed numeric(6,2) NOT NULL DEFAULT 0,
  avg_speed numeric(6,2) NOT NULL DEFAULT 0,
  congestion_level text NOT NULL DEFAULT 'low' CHECK (congestion_level IN ('low','moderate','high','severe')),
  vehicle_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','maintenance')),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================
-- 3. TRAFFIC INCIDENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS traffic_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  type text NOT NULL CHECK (type IN ('accident','roadwork','closure','hazard','congestion')),
  location text NOT NULL,
  severity text NOT NULL DEFAULT 'minor' CHECK (severity IN ('minor','moderate','major','critical')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','resolved','monitoring')),
  description text,
  reported_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- ============================================================
-- 4. ENERGY GRIDS
-- ============================================================
CREATE TABLE IF NOT EXISTS energy_grids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  name text NOT NULL,
  capacity_kw numeric(12,2) NOT NULL DEFAULT 0,
  current_load_kw numeric(12,2) NOT NULL DEFAULT 0,
  renewable_pct numeric(5,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'operational' CHECK (status IN ('operational','degraded','offline','maintenance')),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================
-- 5. WASTE BINS
-- ============================================================
CREATE TABLE IF NOT EXISTS waste_bins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  location text NOT NULL,
  fill_level integer NOT NULL DEFAULT 0 CHECK (fill_level >= 0 AND fill_level <= 100),
  capacity_liters integer NOT NULL DEFAULT 240,
  type text NOT NULL DEFAULT 'general' CHECK (type IN ('general','recycling','organic','hazardous')),
  status text NOT NULL DEFAULT 'empty' CHECK (status IN ('empty','filling','full','overflowing','collected')),
  last_collected_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

-- ============================================================
-- 6. WASTE ROUTES
-- ============================================================
CREATE TABLE IF NOT EXISTS waste_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_name text NOT NULL,
  vehicle_id text NOT NULL,
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','completed','delayed')),
  scheduled_date date NOT NULL DEFAULT CURRENT_DATE,
  bins_collected integer NOT NULL DEFAULT 0,
  total_bins integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- ============================================================
-- 7. CITIZEN REPORTS
-- ============================================================
CREATE TABLE IF NOT EXISTS citizen_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  category text NOT NULL CHECK (category IN ('pothole','streetlight','graffiti','noise','water','sanitation','traffic_signal','parking','other')),
  description text NOT NULL,
  location text NOT NULL,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','reviewing','in_progress','resolved','rejected')),
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  reporter_name text NOT NULL DEFAULT 'Anonymous',
  upvotes integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- ============================================================
-- 8. EMERGENCY INCIDENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS emergency_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('fire','medical','police','natural','hazmat','rescue')),
  location text NOT NULL,
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  severity text NOT NULL DEFAULT 'moderate' CHECK (severity IN ('minor','moderate','major','critical')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','contained','resolved')),
  responders_count integer NOT NULL DEFAULT 0,
  description text,
  reported_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- ============================================================
-- 9. AIR QUALITY STATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS air_quality_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES city_zones(id) ON DELETE SET NULL,
  location text NOT NULL,
  pm25 numeric(6,2) NOT NULL DEFAULT 0,
  pm10 numeric(6,2) NOT NULL DEFAULT 0,
  co2_ppm numeric(8,2) NOT NULL DEFAULT 0,
  temperature numeric(5,2) NOT NULL DEFAULT 0,
  humidity numeric(5,2) NOT NULL DEFAULT 0,
  aqi integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','maintenance')),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_traffic_sensors_zone ON traffic_sensors(zone_id);
CREATE INDEX IF NOT EXISTS idx_traffic_incidents_zone ON traffic_incidents(zone_id);
CREATE INDEX IF NOT EXISTS idx_traffic_incidents_status ON traffic_incidents(status);
CREATE INDEX IF NOT EXISTS idx_energy_grids_zone ON energy_grids(zone_id);
CREATE INDEX IF NOT EXISTS idx_waste_bins_zone ON waste_bins(zone_id);
CREATE INDEX IF NOT EXISTS idx_waste_routes_zone ON waste_routes(zone_id);
CREATE INDEX IF NOT EXISTS idx_waste_routes_status ON waste_routes(status);
CREATE INDEX IF NOT EXISTS idx_citizen_reports_zone ON citizen_reports(zone_id);
CREATE INDEX IF NOT EXISTS idx_citizen_reports_status ON citizen_reports(status);
CREATE INDEX IF NOT EXISTS idx_emergency_incidents_status ON emergency_incidents(status);
CREATE INDEX IF NOT EXISTS idx_air_quality_zone ON air_quality_stations(zone_id);

-- ============================================================
-- RLS — Enable on all tables, public CRUD for anon + authenticated
-- ============================================================

ALTER TABLE city_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE traffic_sensors ENABLE ROW LEVEL SECURITY;
ALTER TABLE traffic_incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE energy_grids ENABLE ROW LEVEL SECURITY;
ALTER TABLE waste_bins ENABLE ROW LEVEL SECURITY;
ALTER TABLE waste_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE citizen_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE air_quality_stations ENABLE ROW LEVEL SECURITY;

-- city_zones policies
DROP POLICY IF EXISTS "cz_select" ON city_zones;
CREATE POLICY "cz_select" ON city_zones FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "cz_insert" ON city_zones;
CREATE POLICY "cz_insert" ON city_zones FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "cz_update" ON city_zones;
CREATE POLICY "cz_update" ON city_zones FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "cz_delete" ON city_zones;
CREATE POLICY "cz_delete" ON city_zones FOR DELETE TO anon, authenticated USING (true);

-- traffic_sensors policies
DROP POLICY IF EXISTS "ts_select" ON traffic_sensors;
CREATE POLICY "ts_select" ON traffic_sensors FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ts_insert" ON traffic_sensors;
CREATE POLICY "ts_insert" ON traffic_sensors FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ts_update" ON traffic_sensors;
CREATE POLICY "ts_update" ON traffic_sensors FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ts_delete" ON traffic_sensors;
CREATE POLICY "ts_delete" ON traffic_sensors FOR DELETE TO anon, authenticated USING (true);

-- traffic_incidents policies
DROP POLICY IF EXISTS "ti_select" ON traffic_incidents;
CREATE POLICY "ti_select" ON traffic_incidents FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ti_insert" ON traffic_incidents;
CREATE POLICY "ti_insert" ON traffic_incidents FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ti_update" ON traffic_incidents;
CREATE POLICY "ti_update" ON traffic_incidents FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ti_delete" ON traffic_incidents;
CREATE POLICY "ti_delete" ON traffic_incidents FOR DELETE TO anon, authenticated USING (true);

-- energy_grids policies
DROP POLICY IF EXISTS "eg_select" ON energy_grids;
CREATE POLICY "eg_select" ON energy_grids FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "eg_insert" ON energy_grids;
CREATE POLICY "eg_insert" ON energy_grids FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "eg_update" ON energy_grids;
CREATE POLICY "eg_update" ON energy_grids FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "eg_delete" ON energy_grids;
CREATE POLICY "eg_delete" ON energy_grids FOR DELETE TO anon, authenticated USING (true);

-- waste_bins policies
DROP POLICY IF EXISTS "wb_select" ON waste_bins;
CREATE POLICY "wb_select" ON waste_bins FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "wb_insert" ON waste_bins;
CREATE POLICY "wb_insert" ON waste_bins FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "wb_update" ON waste_bins;
CREATE POLICY "wb_update" ON waste_bins FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "wb_delete" ON waste_bins;
CREATE POLICY "wb_delete" ON waste_bins FOR DELETE TO anon, authenticated USING (true);

-- waste_routes policies
DROP POLICY IF EXISTS "wr_select" ON waste_routes;
CREATE POLICY "wr_select" ON waste_routes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "wr_insert" ON waste_routes;
CREATE POLICY "wr_insert" ON waste_routes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "wr_update" ON waste_routes;
CREATE POLICY "wr_update" ON waste_routes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "wr_delete" ON waste_routes;
CREATE POLICY "wr_delete" ON waste_routes FOR DELETE TO anon, authenticated USING (true);

-- citizen_reports policies
DROP POLICY IF EXISTS "cr_select" ON citizen_reports;
CREATE POLICY "cr_select" ON citizen_reports FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "cr_insert" ON citizen_reports;
CREATE POLICY "cr_insert" ON citizen_reports FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "cr_update" ON citizen_reports;
CREATE POLICY "cr_update" ON citizen_reports FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "cr_delete" ON citizen_reports;
CREATE POLICY "cr_delete" ON citizen_reports FOR DELETE TO anon, authenticated USING (true);

-- emergency_incidents policies
DROP POLICY IF EXISTS "ei_select" ON emergency_incidents;
CREATE POLICY "ei_select" ON emergency_incidents FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ei_insert" ON emergency_incidents;
CREATE POLICY "ei_insert" ON emergency_incidents FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ei_update" ON emergency_incidents;
CREATE POLICY "ei_update" ON emergency_incidents FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ei_delete" ON emergency_incidents;
CREATE POLICY "ei_delete" ON emergency_incidents FOR DELETE TO anon, authenticated USING (true);

-- air_quality_stations policies
DROP POLICY IF EXISTS "aqs_select" ON air_quality_stations;
CREATE POLICY "aqs_select" ON air_quality_stations FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "aqs_insert" ON air_quality_stations;
CREATE POLICY "aqs_insert" ON air_quality_stations FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "aqs_update" ON air_quality_stations;
CREATE POLICY "aqs_update" ON air_quality_stations FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "aqs_delete" ON air_quality_stations;
CREATE POLICY "aqs_delete" ON air_quality_stations FOR DELETE TO anon, authenticated USING (true);
