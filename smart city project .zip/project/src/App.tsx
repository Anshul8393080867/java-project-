import { useState } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { Dashboard } from '@/views/Dashboard';
import { TrafficView } from '@/views/TrafficView';
import { EnergyView } from '@/views/EnergyView';
import { WasteView } from '@/views/WasteView';
import { CitizenView } from '@/views/CitizenView';
import { EmergencyView } from '@/views/EmergencyView';
import { AirView } from '@/views/AirView';
import { PlannerView } from '@/views/PlannerView';
import { ResidentView } from '@/views/ResidentView';
import { cn } from '@/lib/utils';
import type { ViewKey } from '@/types';

function App() {
  const [view, setView] = useState<ViewKey>('dashboard');
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar current={view} onNavigate={setView} collapsed={collapsed} />
      <div className={cn('transition-all duration-300', collapsed ? 'ml-20' : 'ml-64')}>
        <Header view={view} onToggleSidebar={() => setCollapsed(!collapsed)} />
        <main className="p-6">
          {view === 'dashboard' && <Dashboard onNavigate={setView} />}
          {view === 'traffic' && <TrafficView />}
          {view === 'energy' && <EnergyView />}
          {view === 'waste' && <WasteView />}
          {view === 'citizen' && <CitizenView />}
          {view === 'emergency' && <EmergencyView />}
          {view === 'air' && <AirView />}
          {view === 'planner' && <PlannerView />}
          {view === 'resident' && <ResidentView />}
        </main>
      </div>
    </div>
  );
}

export default App;
