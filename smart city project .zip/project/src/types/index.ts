export interface CityZone {
  id: string;
  name: string;
  district_code: string;
  area_km2: number;
  population: number;
  created_at: string;
}

export interface TrafficSensor {
  id: string;
  zone_id: string | null;
  location_name: string;
  latitude: number;
  longitude: number;
  current_speed: number;
  avg_speed: number;
  congestion_level: 'low' | 'moderate' | 'high' | 'severe';
  vehicle_count: number;
  status: 'active' | 'inactive' | 'maintenance';
  updated_at: string;
  zone?: CityZone;
}

export interface TrafficIncident {
  id: string;
  zone_id: string | null;
  type: 'accident' | 'roadwork' | 'closure' | 'hazard' | 'congestion';
  location: string;
  severity: 'minor' | 'moderate' | 'major' | 'critical';
  status: 'active' | 'resolved' | 'monitoring';
  description: string | null;
  reported_at: string;
  resolved_at: string | null;
  zone?: CityZone;
}

export interface EnergyGrid {
  id: string;
  zone_id: string | null;
  name: string;
  capacity_kw: number;
  current_load_kw: number;
  renewable_pct: number;
  status: 'operational' | 'degraded' | 'offline' | 'maintenance';
  updated_at: string;
  zone?: CityZone;
}

export interface WasteBin {
  id: string;
  zone_id: string | null;
  location: string;
  fill_level: number;
  capacity_liters: number;
  type: 'general' | 'recycling' | 'organic' | 'hazardous';
  status: 'empty' | 'filling' | 'full' | 'overflowing' | 'collected';
  last_collected_at: string | null;
  updated_at: string;
  zone?: CityZone;
}

export interface WasteRoute {
  id: string;
  driver_name: string;
  vehicle_id: string;
  zone_id: string | null;
  status: 'scheduled' | 'in_progress' | 'completed' | 'delayed';
  scheduled_date: string;
  bins_collected: number;
  total_bins: number;
  created_at: string;
  completed_at: string | null;
  zone?: CityZone;
}

export interface CitizenReport {
  id: string;
  zone_id: string | null;
  category: 'pothole' | 'streetlight' | 'graffiti' | 'noise' | 'water' | 'sanitation' | 'traffic_signal' | 'parking' | 'other';
  description: string;
  location: string;
  status: 'submitted' | 'reviewing' | 'in_progress' | 'resolved' | 'rejected';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  reporter_name: string;
  upvotes: number;
  created_at: string;
  resolved_at: string | null;
  zone?: CityZone;
}

export interface EmergencyIncident {
  id: string;
  type: 'fire' | 'medical' | 'police' | 'natural' | 'hazmat' | 'rescue';
  location: string;
  zone_id: string | null;
  severity: 'minor' | 'moderate' | 'major' | 'critical';
  status: 'active' | 'contained' | 'resolved';
  responders_count: number;
  description: string | null;
  reported_at: string;
  resolved_at: string | null;
  zone?: CityZone;
}

export interface AirQualityStation {
  id: string;
  zone_id: string | null;
  location: string;
  pm25: number;
  pm10: number;
  co2_ppm: number;
  temperature: number;
  humidity: number;
  aqi: number;
  status: 'active' | 'inactive' | 'maintenance';
  updated_at: string;
  zone?: CityZone;
}

export interface PlanningProject {
  id: string;
  zone_id: string | null;
  name: string;
  type: 'transport' | 'housing' | 'park' | 'utility' | 'commercial' | 'green_space' | 'education' | 'healthcare';
  description: string | null;
  budget: number;
  spent: number;
  progress: number;
  status: 'planning' | 'approved' | 'in_progress' | 'completed' | 'on_hold' | 'cancelled';
  start_date: string | null;
  estimated_end: string | null;
  contractor: string | null;
  created_at: string;
  updated_at: string;
  zone?: CityZone;
}

export interface CityUser {
  id: string;
  email: string;
  password: string;
  full_name: string;
  role: 'admin' | 'planner' | 'resident';
  zone_id: string | null;
  created_at: string;
  zone?: CityZone;
}

export interface IoTDevice {
  id: string;
  device_id: string;
  device_type: 'traffic_sensor' | 'air_quality_sensor' | 'water_sensor' | 'energy_meter' | 'smart_street_light' | 'waste_bin_sensor';
  location: string;
  zone_id: string | null;
  status: 'online' | 'offline' | 'maintenance' | 'alert';
  battery_level: number;
  last_reading: string | null;
  last_updated: string;
  created_at: string;
  zone?: CityZone;
}

export interface Resource {
  id: string;
  resource_name: 'electricity' | 'water' | 'waste';
  allocated_amount: number;
  used_amount: number;
  unit: string;
  zone_id: string | null;
  date: string;
  efficiency: number;
  status: 'optimal' | 'warning' | 'critical' | 'maintenance';
  created_at: string;
  zone?: CityZone;
}

export interface Alert {
  id: string;
  title: string;
  description: string;
  alert_type: 'critical' | 'warning' | 'information';
  location: string;
  zone_id: string | null;
  status: 'active' | 'read' | 'resolved';
  created_at: string;
  zone?: CityZone;
}

export interface ServiceRequest {
  id: string;
  request_id: string;
  resident_id: string | null;
  resident_name: string;
  service_type: 'water_supply' | 'electricity' | 'waste_collection' | 'road_maintenance' | 'street_light' | 'public_transport' | 'emergency_services';
  location: string;
  description: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'submitted' | 'in_progress' | 'resolved' | 'rejected';
  created_at: string;
  resolved_at: string | null;
}

export interface Feedback {
  id: string;
  resident_id: string | null;
  resident_name: string;
  service: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

export interface CityEvent {
  id: string;
  title: string;
  description: string;
  category: 'traffic' | 'weather' | 'emergency' | 'event' | 'transport' | 'public_notice';
  location: string | null;
  zone_id: string | null;
  start_time: string;
  end_time: string | null;
  zone?: CityZone;
}

export interface AIInsight {
  id: string;
  category: 'traffic' | 'energy' | 'waste' | 'environment' | 'public_safety';
  prediction: string;
  confidence: number;
  dataSource: string;
  timestamp: string;
  recommendation: string;
}

export type ViewKey =
  | 'dashboard'
  | 'traffic'
  | 'energy'
  | 'waste'
  | 'citizen'
  | 'emergency'
  | 'air'
  | 'planner'
  | 'resident'
  | 'iot'
  | 'resources'
  | 'alerts'
  | 'service_requests'
  | 'feedback'
  | 'ai_analytics'
  | 'realtime'
  | 'reports';
