import type { AIInsight, TrafficSensor, EnergyGrid, WasteBin, AirQualityStation, Resource, Alert } from '@/types';

export function generateAIInsights(data: {
  sensors: TrafficSensor[];
  grids: EnergyGrid[];
  bins: WasteBin[];
  airStations: AirQualityStation[];
  resources: Resource[];
  alerts: Alert[];
}): AIInsight[] {
  const insights: AIInsight[] = [];
  const now = new Date().toISOString();

  // Traffic prediction
  const severeSensors = data.sensors.filter(s => s.congestion_level === 'severe' || s.congestion_level === 'high');
  if (severeSensors.length > 0) {
    const pctIncrease = Math.round(15 + Math.random() * 10);
    insights.push({
      id: 'ai-1',
      category: 'traffic',
      prediction: `Traffic congestion may increase by ${pctIncrease}% between 5 PM and 7 PM. Peak volume expected on ${severeSensors[0].location_name}.`,
      confidence: 87,
      dataSource: 'Traffic Sensor Network (IOT-1001 through IOT-1027)',
      timestamp: now,
      recommendation: 'Consider adjusting traffic signal timings on major corridors and promoting public transport during peak hours.',
    });
  }

  // Energy forecast
  const totalLoad = data.grids.reduce((s, g) => s + Number(g.current_load_kw), 0);
  const totalCap = data.grids.reduce((s, g) => s + Number(g.capacity_kw), 0);
  const loadPct = totalCap > 0 ? (totalLoad / totalCap) * 100 : 0;
  if (loadPct > 60) {
    const peakForecast = Math.round(totalLoad / 1000 * 1.15);
    insights.push({
      id: 'ai-2',
      category: 'energy',
      prediction: `Energy demand may reach ${peakForecast} MW during evening peak hours (6-9 PM). Current load at ${loadPct.toFixed(1)}% of total capacity.`,
      confidence: 92,
      dataSource: 'Energy Grid Monitoring System',
      timestamp: now,
      recommendation: 'Initiate demand response protocols and increase renewable energy contribution from solar and wind sources.',
    });
  }

  // Waste prediction
  const highFillBins = data.bins.filter(b => b.fill_level > 70);
  if (highFillBins.length > 0) {
    const targetBin = highFillBins[0];
    const hoursToFull = Math.round(6 + Math.random() * 12);
    insights.push({
      id: 'ai-3',
      category: 'waste',
      prediction: `Zone ${targetBin.zone?.name || 'Unknown'} may reach ${Math.min(targetBin.fill_level + 15, 100)}% waste capacity within ${hoursToFull} hours. ${highFillBins.length} bins currently above 70% fill.`,
      confidence: 81,
      dataSource: 'Waste Bin IoT Sensors',
      timestamp: now,
      recommendation: 'Prioritize collection routes for high-fill bins and schedule additional collection trucks for affected zones.',
    });
  }

  // Environmental analysis
  const poorAir = data.airStations.filter(a => a.aqi > 80);
  if (poorAir.length > 0) {
    insights.push({
      id: 'ai-4',
      category: 'environment',
      prediction: `${poorAir[0].zone?.name || 'Industrial Park'} has experienced increased pollution (AQI ${poorAir[0].aqi}) during peak traffic hours. PM2.5 levels at ${poorAir[0].pm25} µg/m³.`,
      confidence: 85,
      dataSource: 'Air Quality Monitoring Network',
      timestamp: now,
      recommendation: 'Increasing public transport frequency and implementing congestion pricing may help reduce traffic-related pollution in affected zones.',
    });
  }

  // Public safety
  const criticalAlerts = data.alerts.filter(a => a.alert_type === 'critical' && a.status === 'active');
  if (criticalAlerts.length > 0) {
    insights.push({
      id: 'ai-5',
      category: 'public_safety',
      prediction: `${criticalAlerts.length} critical alerts active. Predicted response time: ${Math.round(4 + Math.random() * 6)} minutes based on current responder availability.`,
      confidence: 78,
      dataSource: 'Emergency Response System + Alert Center',
      timestamp: now,
      recommendation: 'Ensure all response units are deployed and maintain communication with affected zones. Monitor situation for escalation.',
    });
  }

  // Resource efficiency
  const lowEfficiency = data.resources.filter(r => Number(r.efficiency) < 80);
  if (lowEfficiency.length > 0) {
    const zone = lowEfficiency[0].zone?.name || 'Unknown Zone';
    const resource = lowEfficiency[0].resource_name;
    const reduction = Math.round((100 - Number(lowEfficiency[0].efficiency)) * 0.5);
    insights.push({
      id: 'ai-6',
      category: 'energy',
      prediction: `Based on current consumption patterns, ${zone} may reduce ${resource} usage by approximately ${reduction}% during peak hours.`,
      confidence: 83,
      dataSource: 'Resource Management Database',
      timestamp: now,
      recommendation: `Implement smart scheduling for ${resource} consumption in ${zone} and encourage off-peak usage through citizen awareness campaigns.`,
    });
  }

  return insights;
}

export function getResourceRecommendation(resource: { resource_name: string; zone?: { name: string }; efficiency: number; used_amount: number; allocated_amount: number }): string {
  const eff = Number(resource.efficiency);
  const pct = resource.allocated_amount > 0 ? (Number(resource.used_amount) / Number(resource.allocated_amount)) * 100 : 0;
  const zoneName = resource.zone?.name || 'this zone';

  if (eff < 70) {
    return `Based on current consumption patterns, ${zoneName} may reduce ${resource.resource_name} usage by approximately ${Math.round((100 - eff) * 0.5)}% during peak hours by implementing smart scheduling.`;
  }
  if (pct > 85) {
    return `${zoneName} is using ${pct.toFixed(0)}% of allocated ${resource.resource_name}. Consider increasing allocation or implementing conservation measures to avoid shortages.`;
  }
  return `${zoneName} ${resource.resource_name} consumption is within optimal range. Current efficiency at ${eff.toFixed(0)}% is healthy. Continue current usage patterns.`;
}
