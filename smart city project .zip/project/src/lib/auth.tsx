import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import type { CityUser } from '@/types';

interface AuthContextType {
  user: CityUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CityUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = sessionStorage.getItem('smartcity_user');
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        sessionStorage.removeItem('smartcity_user');
      }
    }
    setLoading(false);
  }, []);

  async function login(email: string, password: string) {
    const { data, error } = await supabase
      .from('city_users')
      .select('*, zone:city_zones(*)')
      .eq('email', email)
      .eq('password', password)
      .maybeSingle();

    if (error) return { success: false, error: 'Database error. Please try again.' };
    if (!data) return { success: false, error: 'Invalid email or password.' };

    setUser(data);
    sessionStorage.setItem('smartcity_user', JSON.stringify(data));
    return { success: true };
  }

  function logout() {
    setUser(null);
    sessionStorage.removeItem('smartcity_user');
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
