export function cn(...classes: (string | false | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months / 12)}y ago`;
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function formatKW(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)} MW`;
  return `${Math.round(n)} kW`;
}

export function getAqiCategory(aqi: number): { label: string; color: string; textColor: string } {
  if (aqi <= 50) return { label: 'Good', color: 'bg-emerald-500', textColor: 'text-emerald-600' };
  if (aqi <= 100) return { label: 'Moderate', color: 'bg-yellow-500', textColor: 'text-yellow-600' };
  if (aqi <= 150) return { label: 'Unhealthy (Sensitive)', color: 'bg-orange-500', textColor: 'text-orange-600' };
  if (aqi <= 200) return { label: 'Unhealthy', color: 'bg-red-500', textColor: 'text-red-600' };
  if (aqi <= 300) return { label: 'Very Unhealthy', color: 'bg-purple-600', textColor: 'text-purple-600' };
  return { label: 'Hazardous', color: 'bg-rose-900', textColor: 'text-rose-700' };
}

export function getCongestionColor(level: string): { bg: string; text: string; dot: string } {
  switch (level) {
    case 'low': return { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' };
    case 'moderate': return { bg: 'bg-yellow-50', text: 'text-yellow-700', dot: 'bg-yellow-500' };
    case 'high': return { bg: 'bg-orange-50', text: 'text-orange-700', dot: 'bg-orange-500' };
    case 'severe': return { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500' };
    default: return { bg: 'bg-gray-100', text: 'text-gray-700', dot: 'bg-gray-400' };
  }
}

export function getSeverityColor(severity: string): { bg: string; text: string; border: string } {
  switch (severity) {
    case 'minor': return { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' };
    case 'moderate': return { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200' };
    case 'major': return { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' };
    case 'critical': return { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' };
    default: return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' };
  }
}

export function getStatusColor(status: string): { bg: string; text: string } {
  const map: Record<string, { bg: string; text: string }> = {
    active: { bg: 'bg-red-50', text: 'text-red-700' },
    contained: { bg: 'bg-orange-50', text: 'text-orange-700' },
    resolved: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
    operational: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
    degraded: { bg: 'bg-yellow-50', text: 'text-yellow-700' },
    offline: { bg: 'bg-red-50', text: 'text-red-700' },
    maintenance: { bg: 'bg-gray-100', text: 'text-gray-600' },
    submitted: { bg: 'bg-blue-50', text: 'text-blue-700' },
    reviewing: { bg: 'bg-purple-50', text: 'text-purple-700' },
    in_progress: { bg: 'bg-yellow-50', text: 'text-yellow-700' },
    rejected: { bg: 'bg-red-50', text: 'text-red-700' },
    scheduled: { bg: 'bg-blue-50', text: 'text-blue-700' },
    completed: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
    delayed: { bg: 'bg-orange-50', text: 'text-orange-700' },
    empty: { bg: 'bg-gray-100', text: 'text-gray-600' },
    filling: { bg: 'bg-yellow-50', text: 'text-yellow-700' },
    full: { bg: 'bg-orange-50', text: 'text-orange-700' },
    overflowing: { bg: 'bg-red-50', text: 'text-red-700' },
    collected: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
    monitoring: { bg: 'bg-purple-50', text: 'text-purple-700' },
  };
  return map[status] || { bg: 'bg-gray-100', text: 'text-gray-600' };
}

export function getPriorityColor(priority: string): { bg: string; text: string } {
  switch (priority) {
    case 'low': return { bg: 'bg-gray-100', text: 'text-gray-600' };
    case 'normal': return { bg: 'bg-blue-50', text: 'text-blue-700' };
    case 'high': return { bg: 'bg-orange-50', text: 'text-orange-700' };
    case 'urgent': return { bg: 'bg-red-50', text: 'text-red-700' };
    default: return { bg: 'bg-gray-100', text: 'text-gray-600' };
  }
}
