import { useEffect, useState } from 'react';
import { Wind, Thermometer, Droplets, Cloud, Activity, Gauge } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, getAqiCategory, getStatusColor } from '@/lib/utils';
import type { AirQualityStation, CityZone } from '@/types';

export function AirView() {
  const [stations, setStations] = useState<AirQualityStation[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    const [a, z] = await Promise.all([
      supabase.from('air_quality_stations').select('*, zone:city_zones(*)'),
      supabase.from('city_zones').select('*'),
    ]);
    setStations(a.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const activeStations = stations.filter(s => s.status === 'active');
  const avgAqi = activeStations.length > 0 ? Math.round(activeStations.reduce((s, a) => s + a.aqi, 0) / activeStations.length) : 0;
  const avgPm25 = activeStations.length > 0 ? (activeStations.reduce((s, a) => s + Number(a.pm25), 0) / activeStations.length).toFixed(1) : '0';
  const avgTemp = activeStations.length > 0 ? (activeStations.reduce((s, a) => s + Number(a.temperature), 0) / activeStations.length).toFixed(1) : '0';
  const avgHumidity = activeStations.length > 0 ? (activeStations.reduce((s, a) => s + Number(a.humidity), 0) / activeStations.length).toFixed(0) : '0';
  const worstAqi = Math.max(...activeStations.map(s => s.aqi), 0);
  const bestAqi = Math.min(...activeStations.map(s => s.aqi), 0);
  const aqiCategory = getAqiCategory(avgAqi);

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      {/* Top stats with big AQI display */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-1">
          <div className="p-5 text-center">
            <div className={cn('mx-auto flex h-20 w-20 items-center justify-center rounded-full text-white', aqiCategory.color)}>
              <span className="text-3xl font-bold">{avgAqi}</span>
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-900">Average AQI</p>
            <p className={cn('text-sm font-medium', aqiCategory.textColor)}>{aqiCategory.label}</p>
          </div>
        </Card>

        <StatCard label="Active Stations" value={activeStations.length} icon={<Wind size={22} />} accent="bg-cyan-500" />
        <StatCard label="Avg PM2.5" value={`${avgPm25} µg/m³`} icon={<Activity size={22} />} accent="bg-teal-500" />
        <StatCard label="Avg Temperature" value={`${avgTemp}°C`} icon={<Thermometer size={22} />} accent="bg-orange-500" />
      </div>

      {/* AQI range bar */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Gauge size={16} className="text-cyan-500" /> Air Quality Index Scale</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="flex h-8 rounded-lg overflow-hidden">
            <div className="flex-1 bg-emerald-500 flex items-center justify-center text-xs font-bold text-white">0-50 Good</div>
            <div className="flex-1 bg-yellow-500 flex items-center justify-center text-xs font-bold text-white">51-100 Moderate</div>
            <div className="flex-1 bg-orange-500 flex items-center justify-center text-xs font-bold text-white">101-150 Sensitive</div>
            <div className="flex-1 bg-red-500 flex items-center justify-center text-xs font-bold text-white">151-200 Unhealthy</div>
            <div className="flex-1 bg-purple-600 flex items-center justify-center text-xs font-bold text-white">201-300 Very Bad</div>
            <div className="flex-1 bg-rose-900 flex items-center justify-center text-xs font-bold text-white">301+ Hazard</div>
          </div>
          <div className="mt-3 flex items-center justify-between text-sm">
            <span className="text-slate-500">Best: <span className="font-bold text-emerald-600">{bestAqi}</span></span>
            <span className="text-slate-500">Worst: <span className="font-bold text-red-600">{worstAqi}</span></span>
          </div>
        </CardBody>
      </Card>

      {/* Station cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {stations.map((s) => {
          const cat = getAqiCategory(s.aqi);
          const st = getStatusColor(s.status);
          return (
            <Card key={s.id}>
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-slate-900">{s.location}</h4>
                    <p className="text-xs text-slate-500">{s.zone?.name || 'Unzoned'}</p>
                  </div>
                  <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{s.status}</span>
                </div>

                {/* AQI display */}
                <div className="flex items-center gap-4 mb-4">
                  <div className={cn('flex h-16 w-16 items-center justify-center rounded-xl text-white', cat.color)}>
                    <span className="text-2xl font-bold">{s.aqi}</span>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">AQI</p>
                    <p className={cn('text-sm font-bold', cat.textColor)}>{cat.label}</p>
                  </div>
                </div>

                {/* Metrics grid */}
                <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-100">
                  <Metric icon={<Wind size={14} className="text-cyan-500" />} label="PM2.5" value={Number(s.pm25).toFixed(1)} unit="µg/m³" />
                  <Metric icon={<Cloud size={14} className="text-slate-500" />} label="PM10" value={Number(s.pm10).toFixed(1)} unit="µg/m³" />
                  <Metric icon={<Activity size={14} className="text-purple-500" />} label="CO₂" value={Number(s.co2_ppm).toFixed(0)} unit="ppm" />
                  <Metric icon={<Thermometer size={14} className="text-orange-500" />} label="Temp" value={Number(s.temperature).toFixed(1)} unit="°C" />
                  <Metric icon={<Droplets size={14} className="text-blue-500" />} label="Humidity" value={Number(s.humidity).toFixed(0)} unit="%" />
                  <Metric icon={<Gauge size={14} className="text-emerald-500" />} label="Status" value={s.status} unit="" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Zone comparison */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Wind size={16} className="text-cyan-500" /> Air Quality by Zone</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="space-y-3">
            {zones.map((zone) => {
              const zoneStations = stations.filter(s => s.zone_id === zone.id);
              if (zoneStations.length === 0) return null;
              const avgZoneAqi = Math.round(zoneStations.reduce((s, a) => s + a.aqi, 0) / zoneStations.length);
              const cat = getAqiCategory(avgZoneAqi);
              return (
                <div key={zone.id} className="flex items-center gap-4">
                  <span className="text-sm font-medium text-slate-700 w-32 truncate">{zone.name}</span>
                  <div className="flex-1 flex items-center gap-3">
                    <div className="flex-1 h-7 rounded-full bg-slate-100 overflow-hidden relative">
                      <div
                        className={cn('h-full rounded-full flex items-center justify-end pr-2', cat.color)}
                        style={{ width: `${Math.min((avgZoneAqi / 300) * 100, 100)}%` }}
                      >
                        <span className="text-xs font-bold text-white">AQI {avgZoneAqi}</span>
                      </div>
                    </div>
                    <span className={cn('text-xs font-semibold w-32', cat.textColor)}>{cat.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

function Metric({ icon, label, value, unit }: { icon: React.ReactNode; label: string; value: string; unit: string }) {
  return (
    <div>
      <div className="flex items-center gap-1 text-xs text-slate-500 mb-0.5">{icon} {label}</div>
      <p className="text-sm font-semibold text-slate-900">{value}<span className="text-xs font-normal text-slate-400 ml-0.5">{unit}</span></p>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
