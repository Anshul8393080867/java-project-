import { useEffect, useState } from 'react';
import {
  Cpu, Zap, Droplets, AlertTriangle, Car, Trash2, TrendingUp, TrendingDown,
  Activity, ArrowUpRight, ArrowDownRight,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { LineChart, BarChart, DoughnutChart, AreaChart } from '@/components/Charts';
import { cn, formatKW, formatNumber, getCongestionColor, getStatusColor, formatTimeAgo } from '@/lib/utils';
import type {
  IoTDevice, Resource, TrafficSensor, Alert, WasteBin, EnergyGrid, AirQualityStation, CityZone,
} from '@/types';
import type { ChartData } from 'chart.js';

interface DashboardProps {
  onNavigate: (view: any) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const [loading, setLoading] = useState(true);
  const [devices, setDevices] = useState<IoTDevice[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [sensors, setSensors] = useState<TrafficSensor[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [bins, setBins] = useState<WasteBin[]>([]);
  const [grids, setGrids] = useState<EnergyGrid[]>([]);
  const [airStations, setAirStations] = useState<AirQualityStation[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);

  useEffect(() => { load(); }, []);

  async function load() {
    const [d, r, s, a, b, g, aq, z] = await Promise.all([
      supabase.from('iot_devices').select('*, zone:city_zones(*)'),
      supabase.from('resources').select('*, zone:city_zones(*)').order('date', { ascending: true }),
      supabase.from('traffic_sensors').select('*, zone:city_zones(*)'),
      supabase.from('alerts').select('*, zone:city_zones(*)').order('created_at', { ascending: false }),
      supabase.from('waste_bins').select('*'),
      supabase.from('energy_grids').select('*'),
      supabase.from('air_quality_stations').select('*'),
      supabase.from('city_zones').select('*'),
    ]);
    setDevices(d.data || []);
    setResources(r.data || []);
    setSensors(s.data || []);
    setAlerts(a.data || []);
    setBins(b.data || []);
    setGrids(g.data || []);
    setAirStations(aq.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  // KPIs
  const onlineDevices = devices.filter(d => d.status === 'online').length;
  const totalLoad = grids.reduce((s, g) => s + Number(g.current_load_kw), 0);
  const todayWater = resources.filter(r => r.resource_name === 'water' && r.date === new Date().toISOString().split('T')[0]);
  const waterUsage = todayWater.reduce((s, r) => s + Number(r.used_amount), 0);
  const activeAlerts = alerts.filter(a => a.status === 'active');
  const avgCongestion = sensors.length > 0 ? sensors.reduce((s, x) => {
    const v = x.congestion_level === 'low' ? 1 : x.congestion_level === 'moderate' ? 2 : x.congestion_level === 'high' ? 3 : 4;
    return s + v;
  }, 0) / sensors.length : 0;
  const trafficStatus = avgCongestion < 1.5 ? 'Low' : avgCongestion < 2.5 ? 'Moderate' : avgCongestion < 3.5 ? 'Heavy' : 'Severe';
  const wasteCollectedPct = 87;
  const avgAqi = airStations.length > 0 ? Math.round(airStations.reduce((s, a) => s + a.aqi, 0) / airStations.length) : 0;

  // Charts
  const dtElectricity = resources.filter(r => r.resource_name === 'electricity' && r.zone?.district_code === 'DT').sort((a, b) => a.date.localeCompare(b.date));
  const energyChartData: ChartData<'line'> = {
    labels: dtElectricity.map(r => new Date(r.date).toLocaleDateString('en', { weekday: 'short' })),
    datasets: [{
      label: 'Energy (kWh)',
      data: dtElectricity.map(r => Number(r.used_amount)),
      borderColor: '#f59e0b',
      backgroundColor: 'rgba(245, 158, 11, 0.1)',
      tension: 0.4,
      borderWidth: 2,
      pointRadius: 4,
      pointBackgroundColor: '#f59e0b',
    }],
  };

  const waterByZone = zones.map(z => {
    const wr = resources.filter(r => r.resource_name === 'water' && r.zone_id === z.id && r.date === new Date().toISOString().split('T')[0]);
    return wr.length > 0 ? Number(wr[0].used_amount) : 0;
  });
  const waterChartData: ChartData<'bar'> = {
    labels: zones.map(z => z.name),
    datasets: [{
      label: 'Water (L)',
      data: waterByZone,
      backgroundColor: ['#3b82f6', '#06b6d4', '#0ea5e9', '#14b8a6', '#0891b2', '#22d3ee'],
      borderRadius: 6,
    }],
  };

  const wasteByType = {
    general: bins.filter(b => b.type === 'general').length,
    recycling: bins.filter(b => b.type === 'recycling').length,
    organic: bins.filter(b => b.type === 'organic').length,
    hazardous: bins.filter(b => b.type === 'hazardous').length,
  };
  const wasteChartData: ChartData<'doughnut'> = {
    labels: ['General', 'Recycling', 'Organic', 'Hazardous'],
    datasets: [{
      data: [wasteByType.general, wasteByType.recycling, wasteByType.organic, wasteByType.hazardous],
      backgroundColor: ['#64748b', '#3b82f6', '#10b981', '#ef4444'],
      borderWidth: 0,
    }],
  };

  const aqiData: ChartData<'line'> = {
    labels: ['12AM', '3AM', '6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
    datasets: [{
      label: 'AQI',
      data: [42, 38, 45, 58, 72, 85, 98, 75],
      borderColor: '#10b981',
      backgroundColor: 'rgba(16, 185, 129, 0.1)',
      tension: 0.4,
      borderWidth: 2,
      fill: true,
      pointRadius: 3,
      pointBackgroundColor: '#10b981',
    }],
  };

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          label="IoT Devices"
          value={formatNumber(devices.length)}
          icon={<Cpu size={22} />}
          accent="bg-indigo-500"
          trend={{ value: `${onlineDevices} online`, positive: true }}
        />
        <StatCard
          label="Energy"
          value={formatKW(totalLoad)}
          icon={<Zap size={22} />}
          accent="bg-amber-500"
          trend={{ value: '72.4 MW peak', positive: false }}
        />
        <StatCard
          label="Water Usage"
          value={`${(waterUsage / 1_000_000).toFixed(2)}M L`}
          icon={<Droplets size={22} />}
          accent="bg-blue-500"
          trend={{ value: 'Normal flow', positive: true }}
        />
        <StatCard
          label="Active Alerts"
          value={activeAlerts.length}
          icon={<AlertTriangle size={22} />}
          accent="bg-red-500"
          trend={{ value: `${activeAlerts.filter(a => a.alert_type === 'critical').length} critical`, positive: false }}
          onClick={() => onNavigate('alerts')}
        />
        <StatCard
          label="Traffic"
          value={trafficStatus}
          icon={<Car size={22} />}
          accent={trafficStatus === 'Low' ? 'bg-emerald-500' : trafficStatus === 'Moderate' ? 'bg-yellow-500' : 'bg-red-500'}
        />
        <StatCard
          label="Waste Collection"
          value={`${wasteCollectedPct}%`}
          icon={<Trash2 size={22} />}
          accent="bg-emerald-500"
          trend={{ value: 'On schedule', positive: true }}
          onClick={() => onNavigate('waste')}
        />
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Zap size={16} className="text-amber-500" /> Energy Consumption — Downtown (7 days)</span></CardTitle>
          </CardHeader>
          <CardBody>
            <LineChart data={energyChartData} />
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Droplets size={16} className="text-blue-500" /> Water Usage by Zone</span></CardTitle>
          </CardHeader>
          <CardBody>
            <BarChart data={waterChartData} />
          </CardBody>
        </Card>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Trash2 size={16} className="text-emerald-500" /> Waste Management</span></CardTitle>
          </CardHeader>
          <CardBody>
            <DoughnutChart data={wasteChartData} />
          </CardBody>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Activity size={16} className="text-emerald-500" /> Air Quality Index (24h trend)</span></CardTitle>
          </CardHeader>
          <CardBody>
            <AreaChart data={aqiData} />
          </CardBody>
        </Card>
      </div>

      {/* Active alerts + Quick stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><AlertTriangle size={16} className="text-red-500" /> Active Alerts</span></CardTitle>
            <button onClick={() => onNavigate('alerts')} className="text-xs text-blue-600 hover:underline">View all</button>
          </CardHeader>
          <CardBody className="space-y-2 max-h-72 overflow-y-auto">
            {activeAlerts.slice(0, 6).map((a) => (
              <div key={a.id} className={cn(
                'rounded-lg border p-3 flex items-start gap-3',
                a.alert_type === 'critical' ? 'border-red-200 bg-red-50' : a.alert_type === 'warning' ? 'border-orange-200 bg-orange-50' : 'border-blue-200 bg-blue-50'
              )}>
                <span className={cn(
                  'h-2.5 w-2.5 rounded-full mt-1.5 shrink-0',
                  a.alert_type === 'critical' ? 'bg-red-500' : a.alert_type === 'warning' ? 'bg-orange-500' : 'bg-blue-500'
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900">{a.title}</p>
                  <p className="text-xs text-slate-600 truncate">{a.description}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{a.location} · {formatTimeAgo(a.created_at)}</p>
                </div>
              </div>
            ))}
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Cpu size={16} className="text-indigo-500" /> IoT Device Status</span></CardTitle>
            <button onClick={() => onNavigate('iot')} className="text-xs text-blue-600 hover:underline">Manage</button>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-2 gap-4">
              <DeviceStatusCard label="Online" count={devices.filter(d => d.status === 'online').length} total={devices.length} color="bg-emerald-500" />
              <DeviceStatusCard label="Alert" count={devices.filter(d => d.status === 'alert').length} total={devices.length} color="bg-red-500" />
              <DeviceStatusCard label="Maintenance" count={devices.filter(d => d.status === 'maintenance').length} total={devices.length} color="bg-yellow-500" />
              <DeviceStatusCard label="Offline" count={devices.filter(d => d.status === 'offline').length} total={devices.length} color="bg-slate-400" />
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100">
              <p className="text-xs font-medium text-slate-500 mb-2">Device Types</p>
              <div className="flex flex-wrap gap-2">
                {['traffic_sensor', 'air_quality_sensor', 'water_sensor', 'energy_meter', 'smart_street_light', 'waste_bin_sensor'].map(type => {
                  const count = devices.filter(d => d.device_type === type).length;
                  return (
                    <span key={type} className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
                      {type.replace(/_/g, ' ')}: {count}
                    </span>
                  );
                })}
              </div>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

function DeviceStatusCard({ label, count, total, color }: { label: string; count: number; total: number; color: string }) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="rounded-xl border border-slate-200 p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-slate-600">{label}</span>
        <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg text-white text-xs font-bold', color)}>{count}</span>
      </div>
      <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
        <div className={cn('h-full rounded-full', color)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
