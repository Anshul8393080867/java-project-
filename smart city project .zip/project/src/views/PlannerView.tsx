import { useEffect, useState } from 'react';
import {
  Building2, HardHat, DollarSign, TrendingUp, Plus, Filter,
  Home, TreePine, TramFront, Zap, Store, GraduationCap, HeartPulse,
  Calendar, ClipboardList, CheckCircle2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, getStatusColor, formatNumber } from '@/lib/utils';
import type { PlanningProject, CityZone, CitizenReport, TrafficSensor, WasteBin, AirQualityStation } from '@/types';

const typeIcons: Record<string, React.ReactNode> = {
  transport: <TramFront size={16} />,
  housing: <Home size={16} />,
  park: <TreePine size={16} />,
  utility: <Zap size={16} />,
  commercial: <Store size={16} />,
  green_space: <TreePine size={16} />,
  education: <GraduationCap size={16} />,
  healthcare: <HeartPulse size={16} />,
};

const typeColors: Record<string, string> = {
  transport: 'bg-blue-500', housing: 'bg-amber-500', park: 'bg-emerald-500',
  utility: 'bg-yellow-500', commercial: 'bg-purple-500', green_space: 'bg-teal-500',
  education: 'bg-indigo-500', healthcare: 'bg-pink-500',
};

const typeLabels: Record<string, string> = {
  transport: 'Transport', housing: 'Housing', park: 'Park',
  utility: 'Utility', commercial: 'Commercial', green_space: 'Green Space',
  education: 'Education', healthcare: 'Healthcare',
};

export function PlannerView() {
  const [projects, setProjects] = useState<PlanningProject[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [reports, setReports] = useState<CitizenReport[]>([]);
  const [sensors, setSensors] = useState<TrafficSensor[]>([]);
  const [bins, setBins] = useState<WasteBin[]>([]);
  const [airStations, setAirStations] = useState<AirQualityStation[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [p, z, r, s, b, a] = await Promise.all([
      supabase.from('city_planning_projects').select('*, zone:city_zones(*)').order('updated_at', { ascending: false }),
      supabase.from('city_zones').select('*'),
      supabase.from('citizen_reports').select('*, zone:city_zones(*)').order('created_at', { ascending: false }),
      supabase.from('traffic_sensors').select('*, zone:city_zones(*)'),
      supabase.from('waste_bins').select('*, zone:city_zones(*)'),
      supabase.from('air_quality_stations').select('*, zone:city_zones(*)'),
    ]);
    setProjects(p.data || []);
    setZones(z.data || []);
    setReports(r.data || []);
    setSensors(s.data || []);
    setBins(b.data || []);
    setAirStations(a.data || []);
    setLoading(false);
  }

  const filteredProjects = filter === 'all' ? projects : projects.filter(p => p.status === filter);
  const inProgress = projects.filter(p => p.status === 'in_progress');
  const completed = projects.filter(p => p.status === 'completed');
  const totalBudget = projects.reduce((s, p) => s + Number(p.budget), 0);
  const totalSpent = projects.reduce((s, p) => s + Number(p.spent), 0);

  async function updateProjectStatus(id: string, status: string) {
    await supabase.from('city_planning_projects').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    load();
  }

  async function addProject(data: any) {
    await supabase.from('city_planning_projects').insert({
      name: data.name,
      type: data.type,
      zone_id: data.zone_id || null,
      description: data.description,
      budget: Number(data.budget) || 0,
      spent: 0,
      progress: 0,
      status: data.status,
      start_date: data.start_date || null,
      estimated_end: data.estimated_end || null,
      contractor: data.contractor || null,
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Projects" value={projects.length} icon={<ClipboardList size={22} />} accent="bg-indigo-500" />
        <StatCard label="In Progress" value={inProgress.length} icon={<HardHat size={22} />} accent="bg-amber-500" />
        <StatCard label="Total Budget" value={`$${(totalBudget / 1_000_000).toFixed(1)}M`} icon={<DollarSign size={22} />} accent="bg-emerald-500" />
        <StatCard label="Spent" value={`$${(totalSpent / 1_000_000).toFixed(1)}M`} icon={<TrendingUp size={22} />} accent="bg-orange-500" />
      </div>

      {/* Budget overview */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><DollarSign size={16} className="text-emerald-500" /> Capital Budget Overview</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="flex items-end justify-between mb-2">
            <span className="text-3xl font-bold text-slate-900">${(totalSpent / 1_000_000).toFixed(1)}M</span>
            <span className="text-sm text-slate-500">of ${((totalBudget) / 1_000_000).toFixed(1)}M allocated</span>
          </div>
          <div className="h-4 rounded-full bg-slate-100 overflow-hidden">
            <div
              className={cn('h-full rounded-full transition-all', totalBudget > 0 && totalSpent / totalBudget > 0.85 ? 'bg-orange-500' : 'bg-emerald-500')}
              style={{ width: `${totalBudget > 0 ? Math.min((totalSpent / totalBudget) * 100, 100) : 0}%` }}
            />
          </div>
          <div className="flex justify-between mt-2 text-xs text-slate-500">
            <span>Spent: ${(totalSpent / 1_000_000).toFixed(1)}M</span>
            <span>Remaining: ${((totalBudget - totalSpent) / 1_000_000).toFixed(1)}M</span>
          </div>
        </CardBody>
      </Card>

      {/* Project pipeline */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Building2 size={16} className="text-indigo-500" /> Development Projects</span>
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Filter size={14} className="text-slate-400" />
              <select value={filter} onChange={e => setFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
                <option value="all">All Status</option>
                <option value="planning">Planning</option>
                <option value="approved">Approved</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="on_hold">On Hold</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700 transition-colors">
              <Plus size={14} /> New Project
            </button>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filteredProjects.map((p) => {
            const st = getStatusColor(p.status);
            const budgetPct = p.budget > 0 ? (Number(p.spent) / Number(p.budget)) * 100 : 0;
            return (
              <div key={p.id} className="rounded-xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <span className={cn('flex h-10 w-10 items-center justify-center rounded-lg text-white shrink-0', typeColors[p.type])}>
                      {typeIcons[p.type]}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900">{p.name}</span>
                        <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{p.status.replace('_', ' ')}</span>
                        <span className="text-xs text-slate-400">{typeLabels[p.type]}</span>
                      </div>
                      {p.description && <p className="text-sm text-slate-600 mt-0.5">{p.description}</p>}
                      <p className="text-xs text-slate-400 mt-1">
                        {p.zone?.name || 'Citywide'} · {p.contractor ? `Contractor: ${p.contractor}` : 'No contractor assigned'}
                        {p.start_date && ` · Started: ${p.start_date}`}
                        {p.estimated_end && ` · Est. end: ${p.estimated_end}`}
                      </p>

                      {/* Progress bar */}
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-slate-500">Progress</span>
                          <span className="font-bold text-slate-900">{p.progress}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className={cn('h-full rounded-full transition-all', p.status === 'completed' ? 'bg-emerald-500' : p.status === 'on_hold' ? 'bg-orange-400' : 'bg-indigo-500')}
                            style={{ width: `${p.progress}%` }}
                          />
                        </div>
                      </div>

                      {/* Budget bar */}
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-slate-500">Budget Used</span>
                          <span className="font-semibold text-slate-700">${(Number(p.spent) / 1_000_000).toFixed(1)}M / ${(Number(p.budget) / 1_000_000).toFixed(1)}M</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className={cn('h-full rounded-full', budgetPct > 85 ? 'bg-orange-500' : 'bg-emerald-400')}
                            style={{ width: `${Math.min(budgetPct, 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {p.status !== 'completed' && p.status !== 'cancelled' && (
                    <select
                      value={p.status}
                      onChange={(e) => updateProjectStatus(p.id, e.target.value)}
                      className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none shrink-0"
                    >
                      <option value="planning">Planning</option>
                      <option value="approved">Approved</option>
                      <option value="in_progress">In Progress</option>
                      <option value="on_hold">On Hold</option>
                      <option value="completed">Complete</option>
                      <option value="cancelled">Cancel</option>
                    </select>
                  )}
                </div>
              </div>
            );
          })}
          {filteredProjects.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No projects found</p>}
        </CardBody>
      </Card>

      {/* Zone development matrix */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><TreePine size={16} className="text-emerald-500" /> Zone Development Matrix</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-2 px-3 font-semibold text-slate-700">Zone</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Population</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Projects</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Budget</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Open Reports</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Traffic Issues</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Waste Alerts</th>
                  <th className="text-center py-2 px-3 font-semibold text-slate-700">Avg AQI</th>
                </tr>
              </thead>
              <tbody>
                {zones.map((zone) => {
                  const zoneProjects = projects.filter(p => p.zone_id === zone.id);
                  const zoneBudget = zoneProjects.reduce((s, p) => s + Number(p.budget), 0);
                  const zoneOpenReports = reports.filter(r => r.zone_id === zone.id && r.status !== 'resolved' && r.status !== 'rejected').length;
                  const zoneTrafficIssues = sensors.filter(s => s.zone_id === zone.id && (s.congestion_level === 'high' || s.congestion_level === 'severe')).length;
                  const zoneWasteAlerts = bins.filter(b => b.zone_id === zone.id && (b.status === 'overflowing' || b.status === 'full')).length;
                  const zoneAq = airStations.filter(a => a.zone_id === zone.id);
                  const avgAqi = zoneAq.length > 0 ? Math.round(zoneAq.reduce((s, a) => s + a.aqi, 0) / zoneAq.length) : '-';

                  return (
                    <tr key={zone.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-medium text-slate-900">{zone.name}</td>
                      <td className="text-center py-2.5 px-3 text-slate-600">{formatNumber(zone.population)}</td>
                      <td className="text-center py-2.5 px-3">
                        <span className="font-semibold text-slate-900">{zoneProjects.length}</span>
                        <span className="text-xs text-slate-400 ml-1">({zoneProjects.filter(p => p.status === 'in_progress').length} active)</span>
                      </td>
                      <td className="text-center py-2.5 px-3 font-semibold text-slate-700">${(zoneBudget / 1_000_000).toFixed(1)}M</td>
                      <td className="text-center py-2.5 px-3">
                        {zoneOpenReports > 0 ? <span className="font-semibold text-orange-600">{zoneOpenReports}</span> : <span className="text-slate-300">0</span>}
                      </td>
                      <td className="text-center py-2.5 px-3">
                        {zoneTrafficIssues > 0 ? <span className="font-semibold text-red-600">{zoneTrafficIssues}</span> : <span className="text-slate-300">0</span>}
                      </td>
                      <td className="text-center py-2.5 px-3">
                        {zoneWasteAlerts > 0 ? <span className="font-semibold text-orange-600">{zoneWasteAlerts}</span> : <span className="text-slate-300">0</span>}
                      </td>
                      <td className="text-center py-2.5 px-3">
                        {typeof avgAqi === 'number' ? (
                          <span className={cn('inline-flex items-center justify-center rounded-lg px-2 py-0.5 text-xs font-bold text-white',
                            avgAqi <= 50 ? 'bg-emerald-500' : avgAqi <= 100 ? 'bg-yellow-500' : avgAqi <= 150 ? 'bg-orange-500' : 'bg-red-500')}>
                            {avgAqi}
                          </span>
                        ) : <span className="text-slate-300">-</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Completed projects summary */}
      {completed.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>
              <span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-emerald-500" /> Recently Completed</span>
            </CardTitle>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {completed.map((p) => (
                <div key={p.id} className="rounded-xl border border-emerald-100 bg-emerald-50/50 p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg text-white', typeColors[p.type])}>
                      {typeIcons[p.type]}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{p.name}</p>
                      <p className="text-xs text-slate-500">{p.zone?.name || 'Citywide'}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 mt-2">
                    Budget: ${(Number(p.budget) / 1_000_000).toFixed(1)}M · Completed {p.estimated_end || 'N/A'}
                  </p>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {showAdd && <AddProjectModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addProject} />}
    </div>
  );
}

function AddProjectModal({ zones, onClose, onAdd }: { zones: CityZone[]; onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({
    name: '', type: 'transport', zone_id: '', description: '',
    budget: '', status: 'planning', start_date: '', estimated_end: '', contractor: '',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100 sticky top-0 bg-white">
          <h3 className="font-semibold text-slate-900">Create New Planning Project</h3>
        </div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Project Name</label>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Downtown Plaza Renovation" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Type</label>
              <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="input">
                {Object.entries(typeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label>
              <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
                <option value="">Citywide</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Project description..." className="input min-h-[80px]" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Budget ($)</label>
              <input type="number" value={form.budget} onChange={e => setForm({ ...form, budget: e.target.value })} placeholder="0" className="input" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="input">
                <option value="planning">Planning</option>
                <option value="approved">Approved</option>
                <option value="in_progress">In Progress</option>
                <option value="on_hold">On Hold</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Start Date</label>
              <input type="date" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} className="input" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Estimated End</label>
              <input type="date" value={form.estimated_end} onChange={e => setForm({ ...form, estimated_end: e.target.value })} className="input" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Contractor</label>
            <input value={form.contractor} onChange={e => setForm({ ...form, contractor: e.target.value })} placeholder="Contractor name (optional)" className="input" />
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100 sticky bottom-0 bg-white">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button
            onClick={() => form.name && onAdd(form)}
            disabled={!form.name}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Create Project
          </button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
