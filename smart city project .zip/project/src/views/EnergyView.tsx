import { useEffect, useState } from 'react';
import { Zap, Battery, Leaf, TrendingDown, Gauge } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatKW, getStatusColor } from '@/lib/utils';
import type { EnergyGrid, CityZone } from '@/types';

export function EnergyView() {
  const [grids, setGrids] = useState<EnergyGrid[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    const [g, z] = await Promise.all([
      supabase.from('energy_grids').select('*, zone:city_zones(*)'),
      supabase.from('city_zones').select('*'),
    ]);
    setGrids(g.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const totalCap = grids.reduce((s, g) => s + Number(g.capacity_kw), 0);
  const totalLoad = grids.reduce((s, g) => s + Number(g.current_load_kw), 0);
  const avgRenewable = grids.length > 0 ? grids.reduce((s, g) => s + Number(g.renewable_pct), 0) / grids.length : 0;
  const operationalCount = grids.filter(g => g.status === 'operational').length;
  const loadPct = totalCap > 0 ? (totalLoad / totalCap) * 100 : 0;

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Capacity" value={formatKW(totalCap)} icon={<Gauge size={22} />} accent="bg-yellow-500" />
        <StatCard label="Current Load" value={formatKW(totalLoad)} icon={<Zap size={22} />} accent="bg-orange-500" />
        <StatCard label="Avg Renewable" value={`${avgRenewable.toFixed(1)}%`} icon={<Leaf size={22} />} accent="bg-emerald-500" />
        <StatCard label="Grids Online" value={`${operationalCount}/${grids.length}`} icon={<Battery size={22} />} accent="bg-blue-500" />
      </div>

      {/* Load overview bar */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><TrendingDown size={16} className="text-orange-500" /> Citywide Grid Load</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="flex items-end justify-between mb-2">
            <span className="text-3xl font-bold text-slate-900">{loadPct.toFixed(1)}%</span>
            <span className="text-sm text-slate-500">{formatKW(totalLoad)} of {formatKW(totalCap)}</span>
          </div>
          <div className="h-4 rounded-full bg-slate-100 overflow-hidden">
            <div
              className={cn(
                'h-full rounded-full transition-all duration-500',
                loadPct < 60 ? 'bg-emerald-500' : loadPct < 85 ? 'bg-yellow-500' : 'bg-red-500',
              )}
              style={{ width: `${Math.min(loadPct, 100)}%` }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs text-slate-400">
            <span>0%</span><span>50%</span><span>100%</span>
          </div>
        </CardBody>
      </Card>

      {/* Grid cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {grids.map((g) => {
          const loadPct = g.capacity_kw > 0 ? (Number(g.current_load_kw) / Number(g.capacity_kw)) * 100 : 0;
          const st = getStatusColor(g.status);
          return (
            <Card key={g.id}>
              <div className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold text-slate-900">{g.name}</h4>
                    <p className="text-xs text-slate-500">{g.zone?.name || 'Unzoned'}</p>
                  </div>
                  <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{g.status}</span>
                </div>

                <div className="mt-4 space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-slate-500">Load</span>
                      <span className="font-semibold text-slate-900">{loadPct.toFixed(0)}%</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={cn('h-full rounded-full transition-all', loadPct < 60 ? 'bg-emerald-500' : loadPct < 85 ? 'bg-yellow-500' : 'bg-red-500')}
                        style={{ width: `${Math.min(loadPct, 100)}%` }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                    <div>
                      <p className="text-xs text-slate-500">Capacity</p>
                      <p className="text-sm font-semibold text-slate-900">{formatKW(Number(g.capacity_kw))}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Current</p>
                      <p className="text-sm font-semibold text-slate-900">{formatKW(Number(g.current_load_kw))}</p>
                    </div>
                    <div className="col-span-2">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs text-slate-500">Renewable Energy</p>
                        <p className="text-sm font-semibold text-emerald-600">{Number(g.renewable_pct).toFixed(1)}%</p>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500" style={{ width: `${Math.min(Number(g.renewable_pct), 100)}%` }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Renewable energy summary by zone */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Leaf size={16} className="text-emerald-500" /> Renewable Energy by Zone</span>
          </CardTitle>
        </CardHeader>
        <CardBody>
          <div className="space-y-3">
            {zones.map((zone) => {
              const zoneGrids = grids.filter(g => g.zone_id === zone.id);
              if (zoneGrids.length === 0) return null;
              const avgRen = zoneGrids.reduce((s, g) => s + Number(g.renewable_pct), 0) / zoneGrids.length;
              return (
                <div key={zone.id} className="flex items-center gap-4">
                  <span className="text-sm font-medium text-slate-700 w-32 truncate">{zone.name}</span>
                  <div className="flex-1 h-6 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 flex items-center justify-end pr-2"
                      style={{ width: `${Math.min(avgRen, 100)}%` }}
                    >
                      {avgRen > 15 && <span className="text-xs font-bold text-white">{avgRen.toFixed(0)}%</span>}
                    </div>
                  </div>
                  {avgRen <= 15 && <span className="text-xs font-semibold text-slate-600">{avgRen.toFixed(0)}%</span>}
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
