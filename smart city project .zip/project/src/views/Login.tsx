import { useState } from 'react';
import { Building2, Mail, Lock, Users, Shield, Ruler, Eye, EyeOff, ArrowRight, AlertCircle } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { cn } from '@/lib/utils';

export function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('admin');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);

  const roles = [
    { value: 'admin', label: 'City Administrator', icon: <Shield size={18} />, desc: 'Full system access' },
    { value: 'planner', label: 'Urban Planner', icon: <Ruler size={18} />, desc: 'Planning & projects' },
    { value: 'resident', label: 'Resident', icon: <Users size={18} />, desc: 'Citizen services' },
  ];

  const demoAccounts = [
    { role: 'admin', email: 'admin@smartcity.ai' },
    { role: 'planner', email: 'planner@smartcity.ai' },
    { role: 'resident', email: 'resident@smartcity.ai' },
  ];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const result = await login(email, password);
    if (!result.success) {
      setError(result.error || 'Login failed');
    }
    setLoading(false);
  }

  function fillDemo(r: string, em: string) {
    setRole(r);
    setEmail(em);
    setPassword('smartcity');
  }

  if (forgotMode) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
        <BackgroundPattern />
        <div className="relative w-full max-w-md">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-sm p-8 shadow-2xl">
            <div className="flex flex-col items-center mb-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 text-white mb-3">
                <Building2 size={28} />
              </div>
              <h1 className="text-2xl font-bold text-white">Reset Password</h1>
              <p className="text-slate-400 text-sm mt-1">Enter your email to receive reset instructions</p>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
              <button className="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 py-2.5 text-sm font-semibold text-white hover:from-cyan-400 hover:to-blue-500 transition-all">
                Send Reset Link
              </button>
              <button onClick={() => setForgotMode(false)} className="w-full text-center text-sm text-slate-400 hover:text-cyan-400">
                Back to Login
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <BackgroundPattern />

      <div className="relative w-full max-w-md">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-sm p-8 shadow-2xl">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 text-white mb-3 shadow-lg shadow-cyan-500/20">
              <Building2 size={32} />
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">SmartCity AI</h1>
            <p className="text-cyan-400 text-sm font-medium mt-1">Smarter Cities. Better Living.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@smartcity.ai"
                  required
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  required
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 pl-10 pr-10 py-2.5 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Role selector */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-2">Role</label>
              <div className="grid grid-cols-3 gap-2">
                {roles.map((r) => (
                  <button
                    key={r.value}
                    type="button"
                    onClick={() => setRole(r.value)}
                    className={cn(
                      'flex flex-col items-center gap-1.5 rounded-lg border p-3 transition-all',
                      role === r.value
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                        : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600',
                    )}
                  >
                    {r.icon}
                    <span className="text-xs font-medium">{r.label.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">{roles.find(r => r.value === role)?.desc}</p>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-lg border border-red-800 bg-red-900/30 px-3 py-2 text-sm text-red-400">
                <AlertCircle size={16} /> {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 py-2.5 text-sm font-semibold text-white hover:from-cyan-400 hover:to-blue-500 transition-all disabled:opacity-50"
            >
              {loading ? 'Signing in...' : <>Login <ArrowRight size={16} /></>}
            </button>

            <button
              type="button"
              onClick={() => setForgotMode(true)}
              className="w-full text-center text-sm text-slate-400 hover:text-cyan-400 transition-colors"
            >
              Forgot Password?
            </button>
          </form>

          {/* Demo accounts */}
          <div className="mt-6 pt-6 border-t border-slate-800">
            <p className="text-xs text-slate-500 mb-3 text-center">Demo Accounts (password: smartcity)</p>
            <div className="space-y-2">
              {demoAccounts.map((d) => (
                <button
                  key={d.role}
                  onClick={() => fillDemo(d.role, d.email)}
                  className="w-full flex items-center justify-between rounded-lg border border-slate-700 bg-slate-800/50 px-3 py-2 text-xs text-slate-400 hover:border-cyan-700 hover:bg-slate-800 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    {roles.find(r => r.value === d.role)?.icon}
                    {d.email}
                  </span>
                  <span className="text-slate-500 capitalize">{d.role}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BackgroundPattern() {
  return (
    <>
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950" />
      <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-cyan-500/10 blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl" />
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
        }}
      />
    </>
  );
}
