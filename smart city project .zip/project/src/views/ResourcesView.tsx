import { useEffect, useState } from 'react';
import { Zap, Droplets, Trash2, Plus, Filter, TrendingUp, Brain, Lightbulb } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { LineChart, BarChart, DoughnutChart } from '@/components/Charts';
import { cn, getStatusColor, getResourceRecommendation } from '@/lib/utils';
import { getResourceRecommendation as getRec } from '@/lib/aiEngine';
import type { Resource, CityZone } from '@/types';
import type { ChartData } from 'chart.js';

const resourceLabels: Record<string, string> = { electricity: 'Electricity', water: 'Water', waste: 'Waste' };
const resourceIcons: Record<string, React.ReactNode> = {
  electricity: <Zap size={18} />, water: <Droplets size={18} />, waste: <Trash2 size={18} />,
};
const resourceColors: Record<string, string> = {
  electricity: 'bg-amber-500', water: 'bg-blue-500', waste: 'bg-emerald-500',
};

export function ResourcesView() {
  const [resources, setResources] = useState<Resource[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [r, z] = await Promise.all([
      supabase.from('resources').select('*, zone:city_zones(*)').order('date', { ascending: false }),
      supabase.from('city_zones').select('*'),
    ]);
    setResources(r.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const filtered = filter === 'all' ? resources : resources.filter(r => r.resource_name === filter);
  const todayResources = resources.filter(r => r.date === new Date().toISOString().split('T')[0]);

  // Charts
  const dtElec = resources.filter(r => r.resource_name === 'electricity' && r.zone?.district_code === 'DT').sort((a, b) => a.date.localeCompare(b.date));
  const energyChart: ChartData<'line'> = {
    labels: dtElec.map(r => new Date(r.date).toLocaleDateString('en', { weekday: 'short' })),
    datasets: [{
      label: 'Energy (kWh)', data: dtElec.map(r => Number(r.used_amount)),
      borderColor: '#f59e0b', backgroundColor: 'rgba(245,158,11,0.1)', tension: 0.4, borderWidth: 2, fill: true, pointRadius: 4, pointBackgroundColor: '#f59e0b',
    }],
  };

  const dtWater = resources.filter(r => r.resource_name === 'water' && r.zone?.district_code === 'DT').sort((a, b) => a.date.localeCompare(b.date));
  const waterChart: ChartData<'bar'> = {
    labels: dtWater.map(r => new Date(r.date).toLocaleDateString('en', { weekday: 'short' })),
    datasets: [{
      label: 'Water (L)', data: dtWater.map(r => Number(r.used_amount)),
      backgroundColor: '#3b82f6', borderRadius: 6,
    }],
  };

  const todayWaste = todayResources.filter(r => r.resource_name === 'waste');
  const wasteChart: ChartData<'doughnut'> = {
    labels: todayWaste.map(r => r.zone?.name || 'Unknown'),
    datasets: [{
      data: todayWaste.map(r => Number(r.used_amount)),
      backgroundColor: ['#10b981', '#06b6d4', '#0ea5e9', '#14b8a6', '#0891b2', '#22d3ee'],
      borderWidth: 0,
    }],
  };

  // AI recommendation
  const lowEff = todayResources.filter(r => Number(r.efficiency) < 85).sort((a, b) => Number(a.efficiency) - Number(b.efficiency));
  const aiRec = lowEff.length > 0 ? getRec(lowEff[0]) : 'All resources are operating within optimal efficiency ranges. No action needed at this time.';

  async function addResource(data: any) {
    await supabase.from('resources').insert({
      resource_name: data.resource_name,
      allocated_amount: Number(data.allocated_amount) || 0,
      used_amount: Number(data.used_amount) || 0,
      unit: data.resource_name === 'water' ? 'L' : data.resource_name === 'waste' ? 'kg' : 'kWh',
      zone_id: data.zone_id || null,
      date: data.date || new Date().toISOString().split('T')[0],
      efficiency: Number(data.efficiency) || 100,
      status: data.status,
    });
    setShowAdd(false);
    load();
  }

  async function deleteResource(id: string) {
    await supabase.from('resources').delete().eq('id', id);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Electricity Today" value={`${(todayResources.filter(r => r.resource_name === 'electricity').reduce((s, r) => s + Number(r.used_amount), 0) / 1000).toFixed(1)} MW`} icon={<Zap size={22} />} accent="bg-amber-500" />
        <StatCard label="Water Today" value={`${(todayResources.filter(r => r.resource_name === 'water').reduce((s, r) => s + Number(r.used_amount), 0) / 1_000_000).toFixed(2)}M L`} icon={<Droplets size={22} />} accent="bg-blue-500" />
        <StatCard label="Waste Today" value={`${(todayResources.filter(r => r.resource_name === 'waste').reduce((s, r) => s + Number(r.used_amount), 0) / 1000).toFixed(1)}T`} icon={<Trash2 size={22} />} accent="bg-emerald-500" />
        <StatCard label="Avg Efficiency" value={`${Math.round(todayResources.reduce((s, r) => s + Number(r.efficiency), 0) / (todayResources.length || 1))}%`} icon={<TrendingUp size={22} />} accent="bg-indigo-500" />
      </div>

      {/* AI Recommendation */}
      <Card className="border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
        <CardBody>
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white shrink-0">
              <Brain size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                AI Recommendation <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700">Smart Analytics</span>
              </h3>
              <p className="text-sm text-slate-700 mt-1">{aiRec}</p>
              <p className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Lightbulb size={12} /> Powered by pattern analysis on 7-day consumption data</p>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle><span className="flex items-center gap-2"><Zap size={16} className="text-amber-500" /> Energy Consumption — Downtown (7 days)</span></CardTitle></CardHeader>
          <CardBody><LineChart data={energyChart} /></CardBody>
        </Card>
        <Card>
          <CardHeader><CardTitle><span className="flex items-center gap-2"><Droplets size={16} className="text-blue-500" /> Water Usage — Downtown (7 days)</span></CardTitle></CardHeader>
          <CardBody><BarChart data={waterChart} /></CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle><span className="flex items-center gap-2"><Trash2 size={16} className="text-emerald-500" /> Waste Distribution by Zone (Today)</span></CardTitle></CardHeader>
        <CardBody><DoughnutChart data={wasteChart} /></CardBody>
      </Card>

      {/* Resource table */}
      <Card>
        <CardHeader>
          <CardTitle>Resource Records</CardTitle>
          <div className="flex items-center gap-2">
            <select value={filter} onChange={e => setFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Resources</option>
              <option value="electricity">Electricity</option>
              <option value="water">Water</option>
              <option value="waste">Waste</option>
            </select>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700">
              <Plus size={14} /> Add Resource
            </button>
          </div>
        </CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Resource</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Zone</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">Allocated</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">Used</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Efficiency</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Date</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 20).map((r) => {
                  const sc = getStatusColor(r.status);
                  const pct = r.allocated_amount > 0 ? (Number(r.used_amount) / Number(r.allocated_amount)) * 100 : 0;
                  return (
                    <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4">
                        <span className="flex items-center gap-2 font-medium text-slate-900">
                          <span className={cn('flex h-7 w-7 items-center justify-center rounded text-white text-xs', resourceColors[r.resource_name])}>
                            {resourceIcons[r.resource_name]}
                          </span>
                          {resourceLabels[r.resource_name]}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 text-xs">{r.zone?.name || 'Citywide'}</td>
                      <td className="py-3 px-4 text-right text-slate-700">{Number(r.allocated_amount).toLocaleString()} {r.unit}</td>
                      <td className="py-3 px-4 text-right text-slate-700 font-medium">{Number(r.used_amount).toLocaleString()} {r.unit}</td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <div className="w-14 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                            <div className={cn('h-full rounded-full', Number(r.efficiency) < 70 ? 'bg-red-500' : Number(r.efficiency) < 85 ? 'bg-yellow-500' : 'bg-emerald-500')} style={{ width: `${r.efficiency}%` }} />
                          </div>
                          <span className="text-xs font-medium text-slate-600">{Number(r.efficiency).toFixed(0)}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center"><span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', sc.bg, sc.text)}>{r.status}</span></td>
                      <td className="py-3 px-4 text-xs text-slate-500">{r.date}</td>
                      <td className="py-3 px-4 text-center">
                        <button onClick={() => deleteResource(r.id)} className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"><Trash2 size={14} /></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {showAdd && <AddResourceModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addResource} />}
    </div>
  );
}

function AddResourceModal({ zones, onClose, onAdd }: { zones: CityZone[]; onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({ resource_name: 'electricity', allocated_amount: '', used_amount: '', zone_id: '', date: new Date().toISOString().split('T')[0], efficiency: '100', status: 'optimal' });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100"><h3 className="font-semibold text-slate-900">Add Resource Data</h3></div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Resource Type</label>
            <select value={form.resource_name} onChange={e => setForm({ ...form, resource_name: e.target.value })} className="input">
              <option value="electricity">Electricity</option><option value="water">Water</option><option value="waste">Waste</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Allocated Amount</label><input type="number" value={form.allocated_amount} onChange={e => setForm({ ...form, allocated_amount: e.target.value })} className="input" /></div>
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Used Amount</label><input type="number" value={form.used_amount} onChange={e => setForm({ ...form, used_amount: e.target.value })} className="input" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label><select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input"><option value="">Citywide</option>{zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}</select></div>
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Date</label><input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="input" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Efficiency (%)</label><input type="number" min="0" max="100" value={form.efficiency} onChange={e => setForm({ ...form, efficiency: e.target.value })} className="input" /></div>
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Status</label><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="input"><option value="optimal">Optimal</option><option value="warning">Warning</option><option value="critical">Critical</option><option value="maintenance">Maintenance</option></select></div>
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button onClick={() => form.allocated_amount && onAdd(form)} disabled={!form.allocated_amount} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50">Add Resource</button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return <div className="flex items-center justify-center h-96"><div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" /></div>;
}
