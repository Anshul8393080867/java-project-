import { useEffect, useState } from 'react';
import { Trash2, Truck, AlertCircle, CheckCircle2, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, getStatusColor, formatTimeAgo } from '@/lib/utils';
import type { WasteBin, WasteRoute, CityZone } from '@/types';

export function WasteView() {
  const [bins, setBins] = useState<WasteBin[]>([]);
  const [routes, setRoutes] = useState<WasteRoute[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [binFilter, setBinFilter] = useState('all');

  useEffect(() => { load(); }, []);

  async function load() {
    const [b, r, z] = await Promise.all([
      supabase.from('waste_bins').select('*, zone:city_zones(*)').order('fill_level', { ascending: false }),
      supabase.from('waste_routes').select('*, zone:city_zones(*)').order('scheduled_date', { ascending: false }),
      supabase.from('city_zones').select('*'),
    ]);
    setBins(b.data || []);
    setRoutes(r.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const overflowCount = bins.filter(b => b.status === 'overflowing').length;
  const fullCount = bins.filter(b => b.status === 'full').length;
  const avgFill = bins.length > 0 ? Math.round(bins.reduce((s, b) => s + b.fill_level, 0) / bins.length) : 0;
  const activeRoutes = routes.filter(r => r.status === 'in_progress').length;

  const filteredBins = binFilter === 'all' ? bins :
    binFilter === 'needs_collection' ? bins.filter(b => b.status === 'overflowing' || b.status === 'full') :
    bins.filter(b => b.type === binFilter);

  const binTypeIcon = (type: string) => {
    const colors: Record<string, string> = {
      general: 'bg-slate-500', recycling: 'bg-blue-500', organic: 'bg-emerald-500', hazardous: 'bg-red-500',
    };
    return colors[type] || 'bg-slate-400';
  };

  async function collectBin(id: string) {
    await supabase.from('waste_bins').update({
      fill_level: 0,
      status: 'collected',
      last_collected_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }).eq('id', id);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Bins" value={bins.length} icon={<Trash2 size={22} />} accent="bg-emerald-500" />
        <StatCard label="Overflowing" value={overflowCount} icon={<AlertCircle size={22} />} accent="bg-red-500" />
        <StatCard label="Avg Fill Level" value={`${avgFill}%`} icon={<Truck size={22} />} accent="bg-yellow-500" />
        <StatCard label="Active Routes" value={activeRoutes} icon={<MapPin size={22} />} accent="bg-blue-500" />
      </div>

      {/* Bin map / grid */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Trash2 size={16} className="text-emerald-500" /> Smart Waste Bins</span>
          </CardTitle>
          <select
            value={binFilter}
            onChange={(e) => setBinFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none"
          >
            <option value="all">All Bins</option>
            <option value="needs_collection">Needs Collection</option>
            <option value="general">General</option>
            <option value="recycling">Recycling</option>
            <option value="organic">Organic</option>
            <option value="hazardous">Hazardous</option>
          </select>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredBins.map((b) => {
              const st = getStatusColor(b.status);
              const fillColor = b.fill_level > 80 ? 'bg-red-500' : b.fill_level > 50 ? 'bg-yellow-500' : 'bg-emerald-500';
              return (
                <div key={b.id} className="rounded-xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={cn('h-3 w-3 rounded-full', binTypeIcon(b.type))} />
                      <div>
                        <p className="text-sm font-semibold text-slate-900 truncate max-w-[140px]">{b.location}</p>
                        <p className="text-xs text-slate-500">{b.zone?.name || 'Unzoned'}</p>
                      </div>
                    </div>
                    <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', st.bg, st.text)}>{b.status}</span>
                  </div>

                  <div className="mt-2">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-500">Fill Level</span>
                      <span className="font-bold text-slate-900">{b.fill_level}%</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className={cn('h-full rounded-full transition-all', fillColor)} style={{ width: `${b.fill_level}%` }} />
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                    <span>{b.type} · {b.capacity_liters}L</span>
                    {b.last_collected_at && <span>{formatTimeAgo(b.last_collected_at)}</span>}
                  </div>

                  {(b.status === 'overflowing' || b.status === 'full') && (
                    <button
                      onClick={() => collectBin(b.id)}
                      className="mt-3 w-full rounded-lg bg-emerald-600 py-1.5 text-xs font-medium text-white hover:bg-emerald-700 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle2 size={14} /> Mark Collected
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {/* Collection routes */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Truck size={16} className="text-blue-500" /> Collection Routes</span>
          </CardTitle>
        </CardHeader>
        <CardBody className="space-y-3">
          {routes.map((r) => {
            const st = getStatusColor(r.status);
            const progress = r.total_bins > 0 ? (r.bins_collected / r.total_bins) * 100 : 0;
            return (
              <div key={r.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-900">{r.driver_name}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{r.status.replace('_', ' ')}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {r.vehicle_id} · {r.zone?.name || 'Unzoned'} · {r.scheduled_date}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-slate-900">{r.bins_collected}/{r.total_bins} bins</p>
                  </div>
                </div>
                <div className="mt-2 h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className={cn('h-full rounded-full transition-all', r.status === 'completed' ? 'bg-emerald-500' : r.status === 'delayed' ? 'bg-orange-500' : 'bg-blue-500')}
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            );
          })}
        </CardBody>
      </Card>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
