import { useEffect, useState } from 'react';
import { AlertTriangle, Info, AlertCircle, CheckCircle, Search, Filter, Bell } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo } from '@/lib/utils';
import type { Alert } from '@/types';

const typeConfig: Record<string, { bg: string; text: string; border: string; icon: React.ReactNode; label: string }> = {
  critical: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', icon: <AlertTriangle size={16} />, label: 'Critical' },
  warning: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', icon: <AlertCircle size={16} />, label: 'Warning' },
  information: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', icon: <Info size={16} />, label: 'Information' },
};

const statusConfig: Record<string, { bg: string; text: string }> = {
  active: { bg: 'bg-red-50', text: 'text-red-700' },
  read: { bg: 'bg-slate-100', text: 'text-slate-600' },
  resolved: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
};

export function AlertsView() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => { load(); }, []);

  async function load() {
    const { data } = await supabase.from('alerts').select('*, zone:city_zones(*)').order('created_at', { ascending: false });
    setAlerts(data || []);
    setLoading(false);
  }

  const filtered = alerts.filter(a => {
    if (search && !a.title.toLowerCase().includes(search.toLowerCase()) && !a.description.toLowerCase().includes(search.toLowerCase()) && !a.location.toLowerCase().includes(search.toLowerCase())) return false;
    if (typeFilter !== 'all' && a.alert_type !== typeFilter) return false;
    if (statusFilter !== 'all' && a.status !== statusFilter) return false;
    return true;
  });

  async function updateStatus(id: string, status: string) {
    await supabase.from('alerts').update({ status }).eq('id', id);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Critical" value={alerts.filter(a => a.alert_type === 'critical' && a.status === 'active').length} icon={<AlertTriangle size={22} />} accent="bg-red-500" />
        <StatCard label="Warnings" value={alerts.filter(a => a.alert_type === 'warning' && a.status === 'active').length} icon={<AlertCircle size={22} />} accent="bg-orange-500" />
        <StatCard label="Information" value={alerts.filter(a => a.alert_type === 'information').length} icon={<Info size={22} />} accent="bg-blue-500" />
        <StatCard label="Resolved" value={alerts.filter(a => a.status === 'resolved').length} icon={<CheckCircle size={22} />} accent="bg-emerald-500" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle><span className="flex items-center gap-2"><Bell size={16} className="text-red-500" /> Alert Center</span></CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search alerts..." className="text-xs border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-slate-700 bg-white outline-none w-44" />
            </div>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Types</option><option value="critical">Critical</option><option value="warning">Warning</option><option value="information">Information</option>
            </select>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Status</option><option value="active">Active</option><option value="read">Read</option><option value="resolved">Resolved</option>
            </select>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filtered.map((a) => {
            const tc = typeConfig[a.alert_type];
            const sc = statusConfig[a.status];
            return (
              <div key={a.id} className={cn('rounded-xl border p-4', tc.border)}>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <span className={cn('flex h-10 w-10 items-center justify-center rounded-lg shrink-0', tc.bg, tc.text)}>{tc.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900">{a.title}</span>
                        <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', tc.bg, tc.text)}>{tc.label}</span>
                        <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', sc.bg, sc.text)}>{a.status}</span>
                      </div>
                      <p className="text-sm text-slate-600 mt-1">{a.description}</p>
                      <p className="text-xs text-slate-400 mt-1">{a.location} · {a.zone?.name || 'Citywide'} · {formatTimeAgo(a.created_at)}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    {a.status === 'active' && <button onClick={() => updateStatus(a.id, 'read')} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Mark Read</button>}
                    {a.status !== 'resolved' && <button onClick={() => updateStatus(a.id, 'resolved')} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700">Resolve</button>}
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No alerts found</p>}
        </CardBody>
      </Card>
    </div>
  );
}

function LoadingState() {
  return <div className="flex items-center justify-center h-96"><div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" /></div>;
}
