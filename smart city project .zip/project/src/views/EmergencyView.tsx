import { useEffect, useState } from 'react';
import { Siren, Flame, HeartPulse, Shield, CloudRain, Biohazard, LifeBuoy, Users, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo, getSeverityColor, getStatusColor } from '@/lib/utils';
import type { EmergencyIncident, CityZone } from '@/types';

const typeIcons: Record<string, React.ReactNode> = {
  fire: <Flame size={18} />,
  medical: <HeartPulse size={18} />,
  police: <Shield size={18} />,
  natural: <CloudRain size={18} />,
  hazmat: <Biohazard size={18} />,
  rescue: <LifeBuoy size={18} />,
};

const typeColors: Record<string, string> = {
  fire: 'bg-red-500', medical: 'bg-pink-500', police: 'bg-blue-500',
  natural: 'bg-cyan-500', hazmat: 'bg-orange-500', rescue: 'bg-emerald-500',
};

export function EmergencyView() {
  const [incidents, setIncidents] = useState<EmergencyIncident[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [ei, z] = await Promise.all([
      supabase.from('emergency_incidents').select('*, zone:city_zones(*)').order('reported_at', { ascending: false }),
      supabase.from('city_zones').select('*'),
    ]);
    setIncidents(ei.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const filtered = filter === 'all' ? incidents : incidents.filter(i => i.status === filter);
  const activeCount = incidents.filter(i => i.status === 'active').length;
  const containedCount = incidents.filter(i => i.status === 'contained').length;
  const resolvedCount = incidents.filter(i => i.status === 'resolved').length;
  const totalResponders = incidents.filter(i => i.status !== 'resolved').reduce((s, i) => s + i.responders_count, 0);

  async function updateStatus(id: string, status: string) {
    const updates: any = { status };
    if (status === 'resolved') updates.resolved_at = new Date().toISOString();
    await supabase.from('emergency_incidents').update(updates).eq('id', id);
    load();
  }

  async function addIncident(data: any) {
    await supabase.from('emergency_incidents').insert({
      type: data.type, location: data.location, zone_id: data.zone_id || null,
      severity: data.severity, status: 'active', responders_count: Number(data.responders_count) || 0,
      description: data.description,
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active" value={activeCount} icon={<Siren size={22} />} accent="bg-red-500" />
        <StatCard label="Contained" value={containedCount} icon={<Shield size={22} />} accent="bg-orange-500" />
        <StatCard label="Resolved" value={resolvedCount} icon={<LifeBuoy size={22} />} accent="bg-emerald-500" />
        <StatCard label="Responders Deployed" value={totalResponders} icon={<Users size={22} />} accent="bg-blue-500" />
      </div>

      {/* Active emergencies - prominent display */}
      {filter === 'all' && activeCount > 0 && (
        <div className="rounded-xl border-2 border-red-200 bg-red-50/50 p-4">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-500 text-white animate-pulse">
              <Siren size={18} />
            </span>
            <h3 className="font-bold text-red-900">Active Emergencies</h3>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {incidents.filter(i => i.status === 'active').map((i) => {
              const sc = getSeverityColor(i.severity);
              return (
                <div key={i.id} className={cn('rounded-xl border-2 bg-white p-4', sc.border)}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className={cn('flex h-10 w-10 items-center justify-center rounded-lg text-white', typeColors[i.type])}>
                        {typeIcons[i.type]}
                      </span>
                      <div>
                        <p className="font-bold text-slate-900 capitalize">{i.type} Emergency</p>
                        <p className="text-xs text-slate-500">{i.location}</p>
                      </div>
                    </div>
                    <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-bold uppercase', sc.bg, sc.text)}>{i.severity}</span>
                  </div>
                  {i.description && <p className="mt-2 text-sm text-slate-600">{i.description}</p>}
                  <div className="mt-3 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs text-slate-500">
                      <Users size={14} /> {i.responders_count} responders · {formatTimeAgo(i.reported_at)}
                    </span>
                    <button
                      onClick={() => updateStatus(i.id, 'contained')}
                      className="rounded-lg bg-orange-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-orange-700 transition-colors"
                    >
                      Mark Contained
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* All incidents */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Siren size={16} className="text-red-500" /> All Emergency Incidents</span>
          </CardTitle>
          <div className="flex items-center gap-2">
            <select value={filter} onChange={e => setFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="contained">Contained</option>
              <option value="resolved">Resolved</option>
            </select>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700 transition-colors">
              <Plus size={14} /> New Incident
            </button>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filtered.map((i) => {
            const sc = getSeverityColor(i.severity);
            const st = getStatusColor(i.status);
            return (
              <div key={i.id} className={cn('rounded-xl border p-4', sc.border)}>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <span className={cn('flex h-10 w-10 items-center justify-center rounded-lg text-white shrink-0', typeColors[i.type])}>
                      {typeIcons[i.type]}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900 capitalize">{i.type}</span>
                        <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{i.status}</span>
                        <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium uppercase', sc.bg, sc.text)}>{i.severity}</span>
                      </div>
                      <p className="mt-1 text-sm font-medium text-slate-800">{i.location}</p>
                      {i.description && <p className="text-sm text-slate-600 mt-0.5">{i.description}</p>}
                      <p className="text-xs text-slate-400 mt-1">
                        {i.zone?.name || 'Unzoned'} · {i.responders_count} responders · {formatTimeAgo(i.reported_at)}
                        {i.resolved_at && ` · Resolved ${formatTimeAgo(i.resolved_at)}`}
                      </p>
                    </div>
                  </div>
                  {i.status !== 'resolved' && (
                    <button
                      onClick={() => updateStatus(i.id, 'resolved')}
                      className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700 transition-colors shrink-0"
                    >
                      Resolve
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No incidents found</p>}
        </CardBody>
      </Card>

      {showAdd && <AddEmergencyModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addIncident} />}
    </div>
  );
}

function AddEmergencyModal({ zones, onClose, onAdd }: { zones: CityZone[]; onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({
    type: 'fire', location: '', zone_id: '', severity: 'moderate', responders_count: '1', description: '',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Report New Emergency</h3>
        </div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Type</label>
            <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="input">
              <option value="fire">Fire</option>
              <option value="medical">Medical</option>
              <option value="police">Police</option>
              <option value="natural">Natural Disaster</option>
              <option value="hazmat">Hazmat</option>
              <option value="rescue">Rescue</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Location</label>
            <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. 123 Main St" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label>
              <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
                <option value="">Unzoned</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Severity</label>
              <select value={form.severity} onChange={e => setForm({ ...form, severity: e.target.value })} className="input">
                <option value="minor">Minor</option>
                <option value="moderate">Moderate</option>
                <option value="major">Major</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Responders</label>
            <input type="number" min="0" value={form.responders_count} onChange={e => setForm({ ...form, responders_count: e.target.value })} className="input" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Brief description..." className="input min-h-[80px]" />
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button
            onClick={() => form.location && onAdd(form)}
            disabled={!form.location}
            className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Report Emergency
          </button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
