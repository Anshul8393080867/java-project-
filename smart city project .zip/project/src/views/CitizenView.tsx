import { useEffect, useState } from 'react';
import { MessageSquareWarning, TrendingUp, Clock, CheckCircle2, Plus, Filter, ThumbsUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo, getStatusColor, getPriorityColor } from '@/lib/utils';
import type { CitizenReport, CityZone } from '@/types';

const categoryLabels: Record<string, string> = {
  pothole: 'Pothole', streetlight: 'Streetlight', graffiti: 'Graffiti', noise: 'Noise',
  water: 'Water Issue', sanitation: 'Sanitation', traffic_signal: 'Traffic Signal', parking: 'Parking', other: 'Other',
};

export function CitizenView() {
  const [reports, setReports] = useState<CitizenReport[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [r, z] = await Promise.all([
      supabase.from('citizen_reports').select('*, zone:city_zones(*)').order('created_at', { ascending: false }),
      supabase.from('city_zones').select('*'),
    ]);
    setReports(r.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const filtered = reports.filter(r => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (categoryFilter !== 'all' && r.category !== categoryFilter) return false;
    return true;
  });

  const openCount = reports.filter(r => r.status !== 'resolved' && r.status !== 'rejected').length;
  const resolvedCount = reports.filter(r => r.status === 'resolved').length;
  const urgentCount = reports.filter(r => r.priority === 'urgent' && r.status !== 'resolved' && r.status !== 'rejected').length;
  const totalUpvotes = reports.reduce((s, r) => s + r.upvotes, 0);

  async function updateStatus(id: string, status: string) {
    const updates: any = { status };
    if (status === 'resolved') updates.resolved_at = new Date().toISOString();
    await supabase.from('citizen_reports').update(updates).eq('id', id);
    load();
  }

  async function upvote(id: string, current: number) {
    await supabase.from('citizen_reports').update({ upvotes: current + 1 }).eq('id', id);
    load();
  }

  async function addReport(data: any) {
    await supabase.from('citizen_reports').insert({
      category: data.category,
      description: data.description,
      location: data.location,
      zone_id: data.zone_id || null,
      priority: data.priority,
      reporter_name: data.reporter_name || 'Anonymous',
      status: 'submitted',
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Open Reports" value={openCount} icon={<MessageSquareWarning size={22} />} accent="bg-purple-500" />
        <StatCard label="Resolved" value={resolvedCount} icon={<CheckCircle2 size={22} />} accent="bg-emerald-500" />
        <StatCard label="Urgent" value={urgentCount} icon={<Clock size={22} />} accent="bg-red-500" />
        <StatCard label="Total Upvotes" value={totalUpvotes} icon={<TrendingUp size={22} />} accent="bg-blue-500" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><MessageSquareWarning size={16} className="text-purple-500" /> Citizen Reports</span>
          </CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Status</option>
              <option value="submitted">Submitted</option>
              <option value="reviewing">Reviewing</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="rejected">Rejected</option>
            </select>
            <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Categories</option>
              {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-purple-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-purple-700 transition-colors">
              <Plus size={14} /> New Report
            </button>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filtered.map((r) => {
            const st = getStatusColor(r.status);
            const pc = getPriorityColor(r.priority);
            return (
              <div key={r.id} className="rounded-xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-sm font-bold text-slate-900">{categoryLabels[r.category] || r.category}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{r.status.replace('_', ' ')}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium uppercase', pc.bg, pc.text)}>{r.priority}</span>
                    </div>
                    <p className="text-sm text-slate-700">{r.description}</p>
                    <p className="text-xs text-slate-400 mt-1">
                      {r.location} · {r.zone?.name || 'Unzoned'} · By {r.reporter_name} · {formatTimeAgo(r.created_at)}
                      {r.resolved_at && ` · Resolved ${formatTimeAgo(r.resolved_at)}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => upvote(r.id, r.upvotes)}
                      className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      <ThumbsUp size={14} /> {r.upvotes}
                    </button>
                    {r.status !== 'resolved' && r.status !== 'rejected' && (
                      <select
                        value={r.status}
                        onChange={(e) => updateStatus(r.id, e.target.value)}
                        className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none"
                      >
                        <option value="submitted">Submitted</option>
                        <option value="reviewing">Reviewing</option>
                        <option value="in_progress">In Progress</option>
                        <option value="resolved">Resolve</option>
                        <option value="rejected">Reject</option>
                      </select>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No reports found</p>}
        </CardBody>
      </Card>

      {/* Category breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Reports by Category</CardTitle>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {Object.entries(categoryLabels).map(([key, label]) => {
              const count = reports.filter(r => r.category === key).length;
              const openCountCat = reports.filter(r => r.category === key && r.status !== 'resolved' && r.status !== 'rejected').length;
              return (
                <div key={key} className="rounded-xl border border-slate-200 p-3 text-center">
                  <p className="text-2xl font-bold text-slate-900">{count}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{label}</p>
                  {openCountCat > 0 && <p className="text-xs text-orange-600 font-medium mt-1">{openCountCat} open</p>}
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {showAdd && <AddReportModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addReport} />}
    </div>
  );
}

function AddReportModal({ zones, onClose, onAdd }: { zones: CityZone[]; onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({
    category: 'pothole', description: '', location: '', zone_id: '', priority: 'normal', reporter_name: '',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Submit New Report</h3>
        </div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Category</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="input">
              {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the issue..." className="input min-h-[80px]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Location</label>
            <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Main St & 5th Ave" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label>
              <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
                <option value="">Unzoned</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Priority</label>
              <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="input">
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Your Name (optional)</label>
            <input value={form.reporter_name} onChange={e => setForm({ ...form, reporter_name: e.target.value })} placeholder="Anonymous" className="input" />
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button
            onClick={() => form.description && form.location && onAdd(form)}
            disabled={!form.description || !form.location}
            className="rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Submit Report
          </button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
