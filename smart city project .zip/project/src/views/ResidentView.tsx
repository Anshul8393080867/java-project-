import { useEffect, useState } from 'react';
import {
  MapPin, Wind, Car, Trash2, Siren, MessageSquareWarning, Building2,
  ThumbsUp, Plus, AlertTriangle, CheckCircle2, Cloud, Thermometer,
  HardHat, Calendar,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { cn, formatTimeAgo, getAqiCategory, getCongestionColor, getStatusColor, getSeverityColor, formatNumber } from '@/lib/utils';
import type {
  CityZone, TrafficSensor, TrafficIncident, WasteBin, AirQualityStation,
  CitizenReport, EmergencyIncident, PlanningProject,
} from '@/types';

export function ResidentView() {
  const [zones, setZones] = useState<CityZone[]>([]);
  const [selectedZone, setSelectedZone] = useState<string>('');
  const [sensors, setSensors] = useState<TrafficSensor[]>([]);
  const [incidents, setIncidents] = useState<TrafficIncident[]>([]);
  const [bins, setBins] = useState<WasteBin[]>([]);
  const [airStations, setAirStations] = useState<AirQualityStation[]>([]);
  const [reports, setReports] = useState<CitizenReport[]>([]);
  const [emergencies, setEmergencies] = useState<EmergencyIncident[]>([]);
  const [projects, setProjects] = useState<PlanningProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [z, s, ti, wb, aq, cr, ei, pp] = await Promise.all([
      supabase.from('city_zones').select('*'),
      supabase.from('traffic_sensors').select('*, zone:city_zones(*)'),
      supabase.from('traffic_incidents').select('*, zone:city_zones(*)').order('reported_at', { ascending: false }),
      supabase.from('waste_bins').select('*, zone:city_zones(*)'),
      supabase.from('air_quality_stations').select('*, zone:city_zones(*)'),
      supabase.from('citizen_reports').select('*, zone:city_zones(*)').order('created_at', { ascending: false }),
      supabase.from('emergency_incidents').select('*, zone:city_zones(*)').order('reported_at', { ascending: false }),
      supabase.from('city_planning_projects').select('*, zone:city_zones(*)'),
    ]);
    setZones(z.data || []);
    setSensors(s.data || []);
    setIncidents(ti.data || []);
    setBins(wb.data || []);
    setAirStations(aq.data || []);
    setReports(cr.data || []);
    setEmergencies(ei.data || []);
    setProjects(pp.data || []);
    setLoading(false);
  }

  // Filter by zone
  const zoneSensors = selectedZone ? sensors.filter(s => s.zone_id === selectedZone) : sensors;
  const zoneIncidents = selectedZone ? incidents.filter(i => i.zone_id === selectedZone) : incidents;
  const zoneBins = selectedZone ? bins.filter(b => b.zone_id === selectedZone) : bins;
  const zoneAir = selectedZone ? airStations.filter(a => a.zone_id === selectedZone) : airStations;
  const zoneReports = selectedZone ? reports.filter(r => r.zone_id === selectedZone) : reports;
  const zoneEmergencies = selectedZone ? emergencies.filter(e => e.zone_id === selectedZone) : emergencies;
  const zoneProjects = selectedZone ? projects.filter(p => p.zone_id === selectedZone) : projects;

  const activeIncidents = zoneIncidents.filter(i => i.status === 'active');
  const activeEmergencies = zoneEmergencies.filter(e => e.status === 'active' || e.status === 'contained');
  const overflowingBins = zoneBins.filter(b => b.status === 'overflowing' || b.status === 'full');
  const avgAqi = zoneAir.length > 0 ? Math.round(zoneAir.reduce((s, a) => s + a.aqi, 0) / zoneAir.length) : 0;
  const aqiCat = getAqiCategory(avgAqi);
  const openReports = zoneReports.filter(r => r.status !== 'resolved' && r.status !== 'rejected');
  const nearbyProjects = zoneProjects.filter(p => p.status === 'in_progress' || p.status === 'approved');

  async function upvote(id: string, current: number) {
    await supabase.from('citizen_reports').update({ upvotes: current + 1 }).eq('id', id);
    load();
  }

  async function addReport(data: any) {
    await supabase.from('citizen_reports').insert({
      category: data.category,
      description: data.description,
      location: data.location,
      zone_id: selectedZone || null,
      priority: data.priority,
      reporter_name: data.reporter_name || 'Anonymous',
      status: 'submitted',
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      {/* Zone selector */}
      <Card>
        <CardBody>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                <MapPin size={18} className="text-cyan-500" /> Select Your Neighborhood
              </h3>
              <p className="text-sm text-slate-500 mt-0.5">See what's happening near you</p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={selectedZone}
                onChange={(e) => setSelectedZone(e.target.value)}
                className="text-sm border border-slate-200 rounded-lg px-3 py-2 text-slate-700 bg-white outline-none min-w-[200px]"
              >
                <option value="">All City Zones</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
              <button
                onClick={() => setShowAdd(true)}
                className="flex items-center gap-1.5 rounded-lg bg-purple-600 px-3 py-2 text-sm font-medium text-white hover:bg-purple-700 transition-colors whitespace-nowrap"
              >
                <Plus size={16} /> Report Issue
              </button>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Quick stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <MiniStat icon={<Wind size={18} />} label="Air Quality" value={avgAqi || 'N/A'} sub={avgAqi > 0 ? aqiCat.label : ''} color={aqiCat.color} textColor={aqiCat.textColor} />
        <MiniStat icon={<AlertTriangle size={18} />} label="Traffic" value={activeIncidents.length} sub="active" color="bg-orange-500" />
        <MiniStat icon={<Trash2 size={18} />} label="Bins Full" value={overflowingBins.length} sub="need collection" color="bg-emerald-500" />
        <MiniStat icon={<Siren size={18} />} label="Emergencies" value={activeEmergencies.length} sub="active" color="bg-red-500" />
        <MiniStat icon={<MessageSquareWarning size={18} />} label="Open Reports" value={openReports.length} sub="in your area" color="bg-purple-500" />
        <MiniStat icon={<HardHat size={18} />} label="Projects" value={nearbyProjects.length} sub="nearby" color="bg-indigo-500" />
      </div>

      {/* Emergency alert banner */}
      {activeEmergencies.length > 0 && (
        <div className="rounded-xl border-2 border-red-200 bg-red-50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-500 text-white animate-pulse">
              <Siren size={18} />
            </span>
            <h3 className="font-bold text-red-900">Active Emergencies in Your Area</h3>
          </div>
          <div className="space-y-2">
            {activeEmergencies.map((e) => {
              const sc = getSeverityColor(e.severity);
              return (
                <div key={e.id} className="flex items-center gap-3 rounded-lg bg-white p-3 border border-red-100">
                  <span className="text-sm font-bold capitalize text-red-700">{e.type}</span>
                  <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', sc.bg, sc.text)}>{e.severity}</span>
                  <span className="text-sm text-slate-700 flex-1 truncate">{e.location}</span>
                  <span className="text-xs text-slate-400 shrink-0">{formatTimeAgo(e.reported_at)}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Air quality card */}
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Wind size={16} className="text-cyan-500" /> Air Quality Near You</span></CardTitle>
          </CardHeader>
          <CardBody>
            {zoneAir.length > 0 ? (
              <div className="space-y-3">
                {zoneAir.map((a) => {
                  const cat = getAqiCategory(a.aqi);
                  return (
                    <div key={a.id} className="flex items-center gap-4 rounded-lg border border-slate-100 p-3">
                      <div className={cn('flex h-14 w-14 items-center justify-center rounded-xl text-white shrink-0', cat.color)}>
                        <span className="text-xl font-bold">{a.aqi}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-slate-900">{a.location}</p>
                        <p className={cn('text-xs font-medium', cat.textColor)}>{cat.label}</p>
                      </div>
                      <div className="flex gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1"><Thermometer size={12} /> {Number(a.temperature).toFixed(0)}°C</span>
                        <span className="flex items-center gap-1"><Cloud size={12} /> {Number(a.humidity).toFixed(0)}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <EmptyState text="No air quality stations in this area" />
            )}
          </CardBody>
        </Card>

        {/* Traffic card */}
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Car size={16} className="text-orange-500" /> Traffic Near You</span></CardTitle>
          </CardHeader>
          <CardBody>
            {zoneSensors.length > 0 ? (
              <div className="space-y-2">
                {zoneSensors.slice(0, 5).map((s) => {
                  const cc = getCongestionColor(s.congestion_level);
                  return (
                    <div key={s.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{s.location_name}</p>
                        <p className="text-xs text-slate-500">{s.current_speed} km/h · {s.vehicle_count} vehicles</p>
                      </div>
                      <span className={cn('flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium shrink-0', cc.bg, cc.text)}>
                        <span className={cn('h-2 w-2 rounded-full', cc.dot)} />
                        {s.congestion_level}
                      </span>
                    </div>
                  );
                })}
                {activeIncidents.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-100">
                    <p className="text-xs font-semibold text-slate-700 mb-2">Active Incidents</p>
                    {activeIncidents.slice(0, 3).map(i => (
                      <div key={i.id} className="flex items-center gap-2 text-xs text-slate-600 py-1">
                        <AlertTriangle size={12} className="text-orange-500 shrink-0" />
                        <span className="truncate">{i.location}</span>
                        <span className="text-slate-400 shrink-0">{formatTimeAgo(i.reported_at)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <EmptyState text="No traffic sensors in this area" />
            )}
          </CardBody>
        </Card>

        {/* Waste collection */}
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Trash2 size={16} className="text-emerald-500" /> Waste Bins Near You</span></CardTitle>
          </CardHeader>
          <CardBody>
            {zoneBins.length > 0 ? (
              <div className="space-y-2">
                {zoneBins.slice(0, 6).map((b) => {
                  const st = getStatusColor(b.status);
                  const fillColor = b.fill_level > 80 ? 'bg-red-500' : b.fill_level > 50 ? 'bg-yellow-500' : 'bg-emerald-500';
                  return (
                    <div key={b.id} className="flex items-center gap-3 rounded-lg border border-slate-100 p-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{b.location}</p>
                        <div className="mt-1 h-1.5 rounded-full bg-slate-100 overflow-hidden w-32">
                          <div className={cn('h-full rounded-full', fillColor)} style={{ width: `${b.fill_level}%` }} />
                        </div>
                      </div>
                      <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium shrink-0', st.bg, st.text)}>{b.status}</span>
                    </div>
                  );
                })}
                {overflowingBins.length > 0 && (
                  <p className="text-xs text-orange-600 font-medium pt-2">{overflowingBins.length} bins need collection</p>
                )}
              </div>
            ) : (
              <EmptyState text="No waste bins in this area" />
            )}
          </CardBody>
        </Card>

        {/* Community reports */}
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><MessageSquareWarning size={16} className="text-purple-500" /> Community Reports</span></CardTitle>
            <button onClick={() => setShowAdd(true)} className="text-xs text-purple-600 hover:underline">Report issue</button>
          </CardHeader>
          <CardBody>
            {zoneReports.length > 0 ? (
              <div className="space-y-2">
                {zoneReports.slice(0, 6).map((r) => {
                  const st = getStatusColor(r.status);
                  return (
                    <div key={r.id} className="rounded-lg border border-slate-100 p-3 hover:border-slate-200 transition-colors">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-700 capitalize">{r.category.replace('_', ' ')}</span>
                            <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', st.bg, st.text)}>{r.status.replace('_', ' ')}</span>
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5 truncate">{r.description}</p>
                          <p className="text-xs text-slate-400 mt-0.5">{r.location} · {formatTimeAgo(r.created_at)}</p>
                        </div>
                        <button
                          onClick={() => upvote(r.id, r.upvotes)}
                          className="flex items-center gap-1 text-xs text-slate-500 hover:text-purple-600 shrink-0"
                        >
                          <ThumbsUp size={12} /> {r.upvotes}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <EmptyState text="No community reports in this area" />
            )}
          </CardBody>
        </Card>
      </div>

      {/* Upcoming projects in your zone */}
      {nearbyProjects.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle><span className="flex items-center gap-2"><Building2 size={16} className="text-indigo-500" /> Upcoming & Ongoing Projects Near You</span></CardTitle>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {nearbyProjects.map((p) => (
                <div key={p.id} className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-slate-900">{p.name}</span>
                    <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', getStatusColor(p.status).bg, getStatusColor(p.status).text)}>
                      {p.status.replace('_', ' ')}
                    </span>
                  </div>
                  {p.description && <p className="text-xs text-slate-600 mb-2">{p.description}</p>}
                  <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full rounded-full bg-indigo-500" style={{ width: `${p.progress}%` }} />
                  </div>
                  <div className="flex items-center justify-between mt-2 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {p.estimated_end || 'TBD'}</span>
                    <span>{p.progress}% done</span>
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {/* Zone info footer */}
      {selectedZone && (() => {
        const zone = zones.find(z => z.id === selectedZone);
        if (!zone) return null;
        return (
          <Card>
            <CardBody>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-slate-900">{zone.name}</h3>
                  <p className="text-sm text-slate-500">
                    District {zone.district_code} · {formatNumber(zone.population)} residents · {Number(zone.area_km2).toFixed(1)} km²
                  </p>
                </div>
                <div className="flex gap-4 text-sm">
                  <div className="text-center">
                    <p className="font-bold text-slate-900">{zoneSensors.length}</p>
                    <p className="text-xs text-slate-500">Sensors</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-slate-900">{zoneBins.length}</p>
                    <p className="text-xs text-slate-500">Bins</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-slate-900">{zoneAir.length}</p>
                    <p className="text-xs text-slate-500">Air Stations</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-slate-900">{zoneProjects.length}</p>
                    <p className="text-xs text-slate-500">Projects</p>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
        );
      })()}

      {showAdd && <AddReportModal zones={zones} selectedZone={selectedZone} onClose={() => setShowAdd(false)} onAdd={addReport} />}
    </div>
  );
}

function MiniStat({ icon, label, value, sub, color, textColor }: {
  icon: React.ReactNode; label: string; value: string | number; sub: string;
  color: string; textColor?: string;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3">
      <div className="flex items-center gap-2 mb-1">
        <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg text-white', color)}>{icon}</span>
        <span className="text-xs font-medium text-slate-500">{label}</span>
      </div>
      <p className="text-xl font-bold text-slate-900">{value}</p>
      <p className={cn('text-xs', textColor || 'text-slate-400')}>{sub}</p>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <CheckCircle2 size={32} className="text-slate-300 mb-2" />
      <p className="text-sm text-slate-400">{text}</p>
    </div>
  );
}

const reportCategories: Record<string, string> = {
  pothole: 'Pothole', streetlight: 'Streetlight', graffiti: 'Graffiti', noise: 'Noise',
  water: 'Water Issue', sanitation: 'Sanitation', traffic_signal: 'Traffic Signal', parking: 'Parking', other: 'Other',
};

function AddReportModal({ zones, selectedZone, onClose, onAdd }: {
  zones: CityZone[]; selectedZone: string; onClose: () => void; onAdd: (d: any) => void;
}) {
  const [form, setForm] = useState({
    category: 'pothole', description: '', location: '', zone_id: selectedZone, priority: 'normal', reporter_name: '',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Report an Issue in Your Neighborhood</h3>
        </div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Category</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="input">
              {Object.entries(reportCategories).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">What's the issue?</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the problem..." className="input min-h-[80px]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Location</label>
            <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. 123 Main St" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label>
              <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
                <option value="">All City</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Priority</label>
              <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="input">
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Your Name (optional)</label>
            <input value={form.reporter_name} onChange={e => setForm({ ...form, reporter_name: e.target.value })} placeholder="Anonymous" className="input" />
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button
            onClick={() => form.description && form.location && onAdd(form)}
            disabled={!form.description || !form.location}
            className="rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Submit Report
          </button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
