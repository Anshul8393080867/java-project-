import { useEffect, useState } from 'react';
import { Car, AlertTriangle, Gauge, TrendingUp, Plus, Filter } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo, getCongestionColor, getSeverityColor, getStatusColor } from '@/lib/utils';
import type { TrafficSensor, TrafficIncident, CityZone } from '@/types';

export function TrafficView() {
  const [sensors, setSensors] = useState<TrafficSensor[]>([]);
  const [incidents, setIncidents] = useState<TrafficIncident[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [s, ti, z] = await Promise.all([
      supabase.from('traffic_sensors').select('*, zone:city_zones(*)').order('vehicle_count', { ascending: false }),
      supabase.from('traffic_incidents').select('*, zone:city_zones(*)').order('reported_at', { ascending: false }),
      supabase.from('city_zones').select('*'),
    ]);
    setSensors(s.data || []);
    setIncidents(ti.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const filteredIncidents = filter === 'all' ? incidents : incidents.filter(i => i.status === filter);
  const activeCount = incidents.filter(i => i.status === 'active').length;
  const severeCount = sensors.filter(s => s.congestion_level === 'severe').length;
  const totalVehicles = sensors.reduce((s, x) => s + x.vehicle_count, 0);

  async function updateIncidentStatus(id: string, status: string) {
    const updates: any = { status };
    if (status === 'resolved') updates.resolved_at = new Date().toISOString();
    await supabase.from('traffic_incidents').update(updates).eq('id', id);
    load();
  }

  async function addIncident(data: { type: string; location: string; severity: string; zone_id: string; description: string }) {
    await supabase.from('traffic_incidents').insert({
      type: data.type,
      location: data.location,
      severity: data.severity,
      zone_id: data.zone_id || null,
      description: data.description,
      status: 'active',
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active Sensors" value={sensors.filter(s => s.status === 'active').length} icon={<Car size={22} />} accent="bg-blue-500" />
        <StatCard label="Active Incidents" value={activeCount} icon={<AlertTriangle size={22} />} accent="bg-orange-500" />
        <StatCard label="Severe Congestion" value={severeCount} icon={<Gauge size={22} />} accent="bg-red-500" />
        <StatCard label="Total Vehicles" value={totalVehicles.toLocaleString()} icon={<TrendingUp size={22} />} accent="bg-emerald-500" />
      </div>

      {/* Traffic sensors live grid */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><Car size={16} className="text-blue-500" /> Live Traffic Sensors</span>
          </CardTitle>
          <span className="text-xs text-slate-500">{sensors.length} sensors</span>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sensors.map((s) => {
              const cc = getCongestionColor(s.congestion_level);
              const speedRatio = s.avg_speed > 0 ? (s.current_speed / s.avg_speed) * 100 : 0;
              return (
                <div key={s.id} className="rounded-xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-slate-900 text-sm">{s.location_name}</h4>
                      <p className="text-xs text-slate-500">{s.zone?.name || 'Unzoned'}</p>
                    </div>
                    <span className={cn('flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium', cc.bg, cc.text)}>
                      <span className={cn('h-2 w-2 rounded-full', cc.dot)} />
                      {s.congestion_level}
                    </span>
                  </div>
                  <div className="mt-3 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500">Current Speed</span>
                      <span className="font-semibold text-slate-900">{s.current_speed} km/h</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={cn('h-full rounded-full transition-all', cc.dot)}
                        style={{ width: `${Math.min(speedRatio, 100)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span>Avg: {s.avg_speed} km/h</span>
                      <span>{s.vehicle_count} vehicles</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {/* Incidents */}
      <Card>
        <CardHeader>
          <CardTitle>
            <span className="flex items-center gap-2"><AlertTriangle size={16} className="text-orange-500" /> Traffic Incidents</span>
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Filter size={14} className="text-slate-400" />
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none"
              >
                <option value="all">All</option>
                <option value="active">Active</option>
                <option value="monitoring">Monitoring</option>
                <option value="resolved">Resolved</option>
              </select>
            </div>
            <button
              onClick={() => setShowAdd(true)}
              className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700 transition-colors"
            >
              <Plus size={14} /> New Incident
            </button>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filteredIncidents.map((i) => {
            const sc = getSeverityColor(i.severity);
            const st = getStatusColor(i.status);
            return (
              <div key={i.id} className={cn('rounded-xl border p-4', sc.border)}>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn('text-sm font-bold uppercase tracking-wide', sc.text)}>{i.type}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', st.bg, st.text)}>{i.status}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', sc.bg, sc.text)}>{i.severity}</span>
                    </div>
                    <p className="mt-1.5 text-sm font-semibold text-slate-900">{i.location}</p>
                    {i.description && <p className="text-sm text-slate-600 mt-0.5">{i.description}</p>}
                    <p className="text-xs text-slate-400 mt-1">
                      {i.zone?.name || 'Unzoned'} · Reported {formatTimeAgo(i.reported_at)}
                      {i.resolved_at && ` · Resolved ${formatTimeAgo(i.resolved_at)}`}
                    </p>
                  </div>
                  {i.status !== 'resolved' && (
                    <div className="flex gap-2 shrink-0">
                      {i.status === 'active' && (
                        <button onClick={() => updateIncidentStatus(i.id, 'monitoring')} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                          Monitor
                        </button>
                      )}
                      <button onClick={() => updateIncidentStatus(i.id, 'resolved')} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700 transition-colors">
                        Resolve
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {filteredIncidents.length === 0 && (
            <p className="text-center text-sm text-slate-400 py-8">No incidents found</p>
          )}
        </CardBody>
      </Card>

      {showAdd && <AddIncidentModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addIncident} />}
    </div>
  );
}

function AddIncidentModal({ zones, onClose, onAdd }: {
  zones: CityZone[];
  onClose: () => void;
  onAdd: (data: any) => void;
}) {
  const [form, setForm] = useState({ type: 'accident', location: '', severity: 'minor', zone_id: '', description: '' });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Report New Traffic Incident</h3>
        </div>
        <div className="px-6 py-4 space-y-4">
          <Field label="Type">
            <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="input">
              <option value="accident">Accident</option>
              <option value="roadwork">Roadwork</option>
              <option value="closure">Closure</option>
              <option value="hazard">Hazard</option>
              <option value="congestion">Congestion</option>
            </select>
          </Field>
          <Field label="Location">
            <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Main St & 5th Ave" className="input" />
          </Field>
          <Field label="Zone">
            <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
              <option value="">Unzoned</option>
              {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
            </select>
          </Field>
          <Field label="Severity">
            <select value={form.severity} onChange={e => setForm({ ...form, severity: e.target.value })} className="input">
              <option value="minor">Minor</option>
              <option value="moderate">Moderate</option>
              <option value="major">Major</option>
              <option value="critical">Critical</option>
            </select>
          </Field>
          <Field label="Description">
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Brief description..." className="input min-h-[80px]" />
          </Field>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button
            onClick={() => form.location && onAdd(form)}
            disabled={!form.location}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Report Incident
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-600 mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center h-96">
      <div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" />
    </div>
  );
}
