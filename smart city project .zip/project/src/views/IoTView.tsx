import { useEffect, useState } from 'react';
import { Cpu, Plus, Search, Filter, Trash2, Edit, Battery, Wifi, WifiOff, Wrench, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo } from '@/lib/utils';
import type { IoTDevice, CityZone } from '@/types';

const deviceTypeLabels: Record<string, string> = {
  traffic_sensor: 'Traffic Sensor', air_quality_sensor: 'Air Quality Sensor', water_sensor: 'Water Sensor',
  energy_meter: 'Energy Meter', smart_street_light: 'Smart Street Light', waste_bin_sensor: 'Waste Bin Sensor',
};

const statusConfig: Record<string, { bg: string; text: string; icon: React.ReactNode }> = {
  online: { bg: 'bg-emerald-50', text: 'text-emerald-700', icon: <Wifi size={12} /> },
  offline: { bg: 'bg-slate-100', text: 'text-slate-600', icon: <WifiOff size={12} /> },
  maintenance: { bg: 'bg-yellow-50', text: 'text-yellow-700', icon: <Wrench size={12} /> },
  alert: { bg: 'bg-red-50', text: 'text-red-700', icon: <AlertTriangle size={12} /> },
};

export function IoTView() {
  const [devices, setDevices] = useState<IoTDevice[]>([]);
  const [zones, setZones] = useState<CityZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const [d, z] = await Promise.all([
      supabase.from('iot_devices').select('*, zone:city_zones(*)').order('device_id'),
      supabase.from('city_zones').select('*'),
    ]);
    setDevices(d.data || []);
    setZones(z.data || []);
    setLoading(false);
  }

  const filtered = devices.filter(d => {
    if (search && !d.device_id.toLowerCase().includes(search.toLowerCase()) && !d.location.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusFilter !== 'all' && d.status !== statusFilter) return false;
    if (typeFilter !== 'all' && d.device_type !== typeFilter) return false;
    return true;
  });

  async function addDevice(data: any) {
    const deviceId = `IOT-${1000 + devices.length + Math.floor(Math.random() * 900)}`;
    await supabase.from('iot_devices').insert({
      device_id: deviceId,
      device_type: data.device_type,
      location: data.location,
      zone_id: data.zone_id || null,
      status: data.status,
      battery_level: Number(data.battery_level) || 100,
      last_reading: data.last_reading || 'Initializing...',
    });
    setShowAdd(false);
    load();
  }

  async function deleteDevice(id: string) {
    await supabase.from('iot_devices').delete().eq('id', id);
    load();
  }

  async function updateStatus(id: string, status: string) {
    await supabase.from('iot_devices').update({ status, last_updated: new Date().toISOString() }).eq('id', id);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Devices" value={devices.length} icon={<Cpu size={22} />} accent="bg-indigo-500" />
        <StatCard label="Online" value={devices.filter(d => d.status === 'online').length} icon={<Wifi size={22} />} accent="bg-emerald-500" />
        <StatCard label="In Alert" value={devices.filter(d => d.status === 'alert').length} icon={<AlertTriangle size={22} />} accent="bg-red-500" />
        <StatCard label="Low Battery" value={devices.filter(d => d.battery_level < 30).length} icon={<Battery size={22} />} accent="bg-orange-500" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle><span className="flex items-center gap-2"><Cpu size={16} className="text-indigo-500" /> IoT Device Management</span></CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search device or location..."
                className="text-xs border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-slate-700 bg-white outline-none w-48"
              />
            </div>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Status</option>
              <option value="online">Online</option>
              <option value="offline">Offline</option>
              <option value="maintenance">Maintenance</option>
              <option value="alert">Alert</option>
            </select>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Types</option>
              {Object.entries(deviceTypeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700">
              <Plus size={14} /> Add Device
            </button>
          </div>
        </CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Device ID</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Type</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Location</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Zone</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Status</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Battery</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Last Reading</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((d) => {
                  const sc = statusConfig[d.status];
                  return (
                    <tr key={d.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900">{d.device_id}</td>
                      <td className="py-3 px-4 text-slate-700">{deviceTypeLabels[d.device_type]}</td>
                      <td className="py-3 px-4 text-slate-700">{d.location}</td>
                      <td className="py-3 px-4 text-slate-500 text-xs">{d.zone?.name || '-'}</td>
                      <td className="py-3 px-4 text-center">
                        <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium', sc.bg, sc.text)}>
                          {sc.icon} {d.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <div className="w-16 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                            <div className={cn('h-full rounded-full', d.battery_level < 20 ? 'bg-red-500' : d.battery_level < 50 ? 'bg-yellow-500' : 'bg-emerald-500')} style={{ width: `${d.battery_level}%` }} />
                          </div>
                          <span className="text-xs font-medium text-slate-600">{d.battery_level}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-500 max-w-[180px] truncate">{d.last_reading}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-1">
                          <select
                            value={d.status}
                            onChange={(e) => updateStatus(d.id, e.target.value)}
                            className="text-xs border border-slate-200 rounded px-1.5 py-1 text-slate-600 bg-white outline-none"
                          >
                            <option value="online">Online</option>
                            <option value="offline">Offline</option>
                            <option value="maintenance">Maintenance</option>
                            <option value="alert">Alert</option>
                          </select>
                          <button onClick={() => deleteDevice(d.id)} className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No devices found</p>}
        </CardBody>
      </Card>

      {showAdd && <AddDeviceModal zones={zones} onClose={() => setShowAdd(false)} onAdd={addDevice} />}
    </div>
  );
}

function AddDeviceModal({ zones, onClose, onAdd }: { zones: CityZone[]; onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({ device_type: 'traffic_sensor', location: '', zone_id: '', status: 'online', battery_level: '100', last_reading: '' });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100"><h3 className="font-semibold text-slate-900">Register New IoT Device</h3></div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Device Type</label>
            <select value={form.device_type} onChange={e => setForm({ ...form, device_type: e.target.value })} className="input">
              {Object.entries(deviceTypeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Location</label>
            <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Main St & 5th Ave" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Zone</label>
              <select value={form.zone_id} onChange={e => setForm({ ...form, zone_id: e.target.value })} className="input">
                <option value="">Unzoned</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="input">
                <option value="online">Online</option>
                <option value="offline">Offline</option>
                <option value="maintenance">Maintenance</option>
                <option value="alert">Alert</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Battery Level</label>
              <input type="number" min="0" max="100" value={form.battery_level} onChange={e => setForm({ ...form, battery_level: e.target.value })} className="input" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Initial Reading</label>
              <input value={form.last_reading} onChange={e => setForm({ ...form, last_reading: e.target.value })} placeholder="e.g. 320 vehicles/h" className="input" />
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button onClick={() => form.location && onAdd(form)} disabled={!form.location} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50">Register Device</button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return <div className="flex items-center justify-center h-96"><div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" /></div>;
}
