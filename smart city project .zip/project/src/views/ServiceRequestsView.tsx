import { useEffect, useState } from 'react';
import { Plus, Search, Filter, FileText, CheckCircle2, Clock, XCircle, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardHeader, CardTitle, CardBody } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { cn, formatTimeAgo, getStatusColor, getPriorityColor } from '@/lib/utils';
import type { ServiceRequest } from '@/types';

const serviceLabels: Record<string, string> = {
  water_supply: 'Water Supply', electricity: 'Electricity', waste_collection: 'Waste Collection',
  road_maintenance: 'Road Maintenance', street_light: 'Street Light', public_transport: 'Public Transport', emergency_services: 'Emergency Services',
};

const serviceIcons: Record<string, string> = {
  water_supply: 'bg-blue-500', electricity: 'bg-amber-500', waste_collection: 'bg-emerald-500',
  road_maintenance: 'bg-orange-500', street_light: 'bg-yellow-500', public_transport: 'bg-purple-500', emergency_services: 'bg-red-500',
};

export function ServiceRequestsView() {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    const { data } = await supabase.from('service_requests').select('*').order('created_at', { ascending: false });
    setRequests(data || []);
    setLoading(false);
  }

  const filtered = requests.filter(r => {
    if (search && !r.request_id.toLowerCase().includes(search.toLowerCase()) && !r.description.toLowerCase().includes(search.toLowerCase()) && !r.location.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    return true;
  });

  async function updateStatus(id: string, status: string) {
    const updates: any = { status };
    if (status === 'resolved') updates.resolved_at = new Date().toISOString();
    await supabase.from('service_requests').update(updates).eq('id', id);
    load();
  }

  async function addRequest(data: any) {
    const reqId = `SC-2026-${10000 + Math.floor(Math.random() * 9999)}`;
    await supabase.from('service_requests').insert({
      request_id: reqId,
      resident_name: data.resident_name || 'Anonymous',
      service_type: data.service_type,
      location: data.location,
      description: data.description,
      priority: data.priority,
      status: 'submitted',
    });
    setShowAdd(false);
    load();
  }

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Submitted" value={requests.filter(r => r.status === 'submitted').length} icon={<Send size={22} />} accent="bg-blue-500" />
        <StatCard label="In Progress" value={requests.filter(r => r.status === 'in_progress').length} icon={<Clock size={22} />} accent="bg-yellow-500" />
        <StatCard label="Resolved" value={requests.filter(r => r.status === 'resolved').length} icon={<CheckCircle2 size={22} />} accent="bg-emerald-500" />
        <StatCard label="Rejected" value={requests.filter(r => r.status === 'rejected').length} icon={<XCircle size={22} />} accent="bg-red-500" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle><span className="flex items-center gap-2"><FileText size={16} className="text-purple-500" /> Service Requests</span></CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by ID, location..." className="text-xs border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-slate-700 bg-white outline-none w-44" />
            </div>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none">
              <option value="all">All Status</option><option value="submitted">Submitted</option><option value="in_progress">In Progress</option><option value="resolved">Resolved</option><option value="rejected">Rejected</option>
            </select>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-purple-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-purple-700">
              <Plus size={14} /> New Request
            </button>
          </div>
        </CardHeader>
        <CardBody className="space-y-3">
          {filtered.map((r) => {
            const sc = getStatusColor(r.status);
            const pc = getPriorityColor(r.priority);
            return (
              <div key={r.id} className="rounded-xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">{r.request_id}</span>
                      <span className={cn('flex items-center gap-1.5 text-sm font-semibold text-slate-900')}>
                        <span className={cn('h-2 w-2 rounded-full', serviceIcons[r.service_type])} />
                        {serviceLabels[r.service_type]}
                      </span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium', sc.bg, sc.text)}>{r.status.replace('_', ' ')}</span>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-medium uppercase', pc.bg, pc.text)}>{r.priority}</span>
                    </div>
                    <p className="text-sm text-slate-700">{r.description}</p>
                    <p className="text-xs text-slate-400 mt-1">
                      {r.location} · By {r.resident_name} · {formatTimeAgo(r.created_at)}
                      {r.resolved_at && ` · Resolved ${formatTimeAgo(r.resolved_at)}`}
                    </p>
                  </div>
                  {r.status !== 'resolved' && r.status !== 'rejected' && (
                    <select value={r.status} onChange={(e) => updateStatus(r.id, e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 bg-white outline-none shrink-0">
                      <option value="submitted">Submitted</option><option value="in_progress">In Progress</option><option value="resolved">Resolve</option><option value="rejected">Reject</option>
                    </select>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No service requests found</p>}
        </CardBody>
      </Card>

      {showAdd && <AddRequestModal onClose={() => setShowAdd(false)} onAdd={addRequest} />}
    </div>
  );
}

function AddRequestModal({ onClose, onAdd }: { onClose: () => void; onAdd: (d: any) => void }) {
  const [form, setForm] = useState({ service_type: 'water_supply', location: '', description: '', priority: 'normal', resident_name: '' });
  const [submitted, setSubmitted] = useState<string | null>(null);

  function handleSubmit() {
    if (!form.location || !form.description) return;
    const reqId = `SC-2026-${10000 + Math.floor(Math.random() * 9999)}`;
    onAdd({ ...form, request_id: reqId });
    setSubmitted(reqId);
  }

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
        <div className="w-full max-w-md rounded-2xl bg-white shadow-xl p-8 text-center" onClick={e => e.stopPropagation()}>
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 mb-4">
            <CheckCircle2 size={32} className="text-emerald-600" />
          </div>
          <h3 className="font-bold text-slate-900 text-lg">Request Submitted!</h3>
          <p className="text-sm text-slate-600 mt-2">Your service request has been successfully submitted.</p>
          <p className="mt-3 inline-block rounded-lg bg-slate-100 px-4 py-2 font-mono text-sm font-bold text-slate-900">{submitted}</p>
          <p className="text-xs text-slate-500 mt-2">Save this ID to track your request status.</p>
          <button onClick={onClose} className="mt-4 w-full rounded-lg bg-purple-600 py-2.5 text-sm font-medium text-white hover:bg-purple-700">Done</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-slate-100"><h3 className="font-semibold text-slate-900">Submit Service Request</h3></div>
        <div className="px-6 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Service Type</label>
            <select value={form.service_type} onChange={e => setForm({ ...form, service_type: e.target.value })} className="input">
              {Object.entries(serviceLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Location</label><input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. 123 Main St" className="input" /></div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Description</label><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the issue..." className="input min-h-[80px]" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Priority</label><select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="input"><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
            <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Your Name</label><input value={form.resident_name} onChange={e => setForm({ ...form, resident_name: e.target.value })} placeholder="Anonymous" className="input" /></div>
          </div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1.5">Image Upload (optional)</label><div className="border-2 border-dashed border-slate-200 rounded-lg p-4 text-center text-xs text-slate-400">Drag and drop or click to upload</div></div>
        </div>
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={!form.location || !form.description} className="rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 disabled:opacity-50">Submit Request</button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return <div className="flex items-center justify-center h-96"><div className="h-12 w-12 rounded-full border-4 border-slate-200 border-t-cyan-500 animate-spin" /></div>;
}
