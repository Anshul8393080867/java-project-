import { useEffect, useState } from 'react';
import { Menu, Search, Bell, Clock } from 'lucide-react';
import type { ViewKey } from '@/types';

const viewTitles: Record<ViewKey, { title: string; subtitle: string }> = {
  dashboard: { title: 'City Dashboard', subtitle: 'Real-time overview of all city systems' },
  traffic: { title: 'Traffic Management', subtitle: 'Monitor flow, congestion, and incidents' },
  energy: { title: 'Energy Grid', subtitle: 'Power consumption and renewable sources' },
  waste: { title: 'Waste Management', subtitle: 'Smart bins and collection routes' },
  citizen: { title: 'Citizen Reports', subtitle: 'Community complaints and service requests' },
  emergency: { title: 'Emergency Response', subtitle: 'Active and resolved emergency incidents' },
  air: { title: 'Air Quality', subtitle: 'Environmental monitoring stations' },
  planner: { title: 'Urban Planner', subtitle: 'Development projects and zone planning' },
  resident: { title: 'Resident Portal', subtitle: 'Your neighborhood at a glance' },
};

interface HeaderProps {
  view: ViewKey;
  onToggleSidebar: () => void;
}

export function Header({ view, onToggleSidebar }: HeaderProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const info = viewTitles[view];

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/80 backdrop-blur-sm">
      <div className="flex items-center justify-between px-6 py-3.5">
        <div className="flex items-center gap-4">
          <button
            onClick={onToggleSidebar}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 transition-colors"
          >
            <Menu size={20} />
          </button>
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">{info.title}</h2>
            <p className="text-sm text-slate-500">{info.subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2">
            <Search size={16} className="text-slate-400" />
            <input
              type="text"
              placeholder="Search..."
              className="bg-transparent text-sm text-slate-700 placeholder-slate-400 outline-none w-40"
            />
          </div>

          <div className="hidden lg:flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2">
            <Clock size={16} className="text-slate-400" />
            <span className="text-sm font-medium text-slate-700 tabular-nums">
              {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>

          <button className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 transition-colors">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
