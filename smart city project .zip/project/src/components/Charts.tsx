import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { ChartJS } from '@/lib/chartSetup';
import type { ChartData, ChartOptions } from 'chart.js';

const commonOptions: ChartOptions<'line'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
  },
  scales: {
    x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
    y: { grid: { color: '#f1f5f9' }, ticks: { color: '#64748b', font: { size: 11 } } },
  },
};

interface ChartProps {
  data: ChartData<'line'>;
  height?: number;
}

export function LineChart({ data, height = 250 }: ChartProps) {
  return (
    <div style={{ height }}>
      <Line data={data} options={commonOptions} />
    </div>
  );
}

export function AreaChart({ data, height = 250 }: ChartProps) {
  const areaData: ChartData<'line'> = {
    ...data,
    datasets: data.datasets.map((d) => ({
      ...d,
      fill: true,
      backgroundColor: (d.backgroundColor as string) || 'rgba(59, 130, 246, 0.1)',
    })),
  };
  return (
    <div style={{ height }}>
      <Line data={areaData} options={commonOptions} />
    </div>
  );
}

interface BarChartProps {
  data: ChartData<'bar'>;
  height?: number;
}

export function BarChart({ data, height = 250 }: BarChartProps) {
  const barOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
      y: { grid: { color: '#f1f5f9' }, ticks: { color: '#64748b', font: { size: 11 } } },
    },
  };
  return (
    <div style={{ height }}>
      <Bar data={data} options={barOptions} />
    </div>
  );
}

interface DoughnutChartProps {
  data: ChartData<'doughnut'>;
  height?: number;
}

export function DoughnutChart({ data, height = 250 }: DoughnutChartProps) {
  const options: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom', labels: { color: '#64748b', font: { size: 11 }, padding: 15 } },
    },
  };
  return (
    <div style={{ height }}>
      <Doughnut data={data} options={options} />
    </div>
  );
}

export { ChartJS };
