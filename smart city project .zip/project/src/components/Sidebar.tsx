import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Car,
  Zap,
  Trash2,
  MessageSquareWarning,
  Siren,
  Wind,
  Building2,
  Ruler,
  Users,
} from 'lucide-react';
import type { ViewKey } from '@/types';

const navItems: { key: ViewKey; label: string; icon: React.ReactNode; description: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} />, description: 'City overview' },
  { key: 'traffic', label: 'Traffic', icon: <Car size={20} />, description: 'Flow & incidents' },
  { key: 'energy', label: 'Energy', icon: <Zap size={20} />, description: 'Grid monitoring' },
  { key: 'waste', label: 'Waste', icon: <Trash2 size={20} />, description: 'Collection & bins' },
  { key: 'citizen', label: 'Citizen Reports', icon: <MessageSquareWarning size={20} />, description: '311 requests' },
  { key: 'emergency', label: 'Emergency', icon: <Siren size={20} />, description: 'Active incidents' },
  { key: 'air', label: 'Air Quality', icon: <Wind size={20} />, description: 'Environment' },
  { key: 'planner', label: 'Urban Planner', icon: <Ruler size={20} />, description: 'Dev projects' },
  { key: 'resident', label: 'Resident', icon: <Users size={20} />, description: 'Neighborhood view' },
];

interface SidebarProps {
  current: ViewKey;
  onNavigate: (view: ViewKey) => void;
  collapsed: boolean;
}

export function Sidebar({ current, onNavigate, collapsed }: SidebarProps) {
  return (
    <aside
      className={cn(
        'fixed left-0 top-0 z-30 flex h-screen flex-col border-r border-slate-200 bg-slate-900 transition-all duration-300',
        collapsed ? 'w-20' : 'w-64',
      )}
    >
      <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-800">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 text-white shrink-0">
          <Building2 size={24} />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-white font-bold text-lg leading-tight whitespace-nowrap">XCity</h1>
            <p className="text-slate-400 text-xs whitespace-nowrap">Management System</p>
          </div>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const active = current === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              title={collapsed ? item.label : undefined}
              className={cn(
                'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
                active
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/10 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800',
              )}
            >
              <span className="shrink-0">{item.icon}</span>
              {!collapsed && (
                <span className="flex-1 text-left">
                  <span className="block">{item.label}</span>
                  <span className="block text-xs font-normal text-slate-500">{item.description}</span>
                </span>
              )}
              {active && !collapsed && <span className="h-2 w-2 rounded-full bg-cyan-400 shrink-0" />}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-slate-800 px-5 py-4">
        {!collapsed ? (
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-700 text-sm font-semibold text-white shrink-0">
              OC
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium text-white truncate">Ops Center</p>
              <p className="text-xs text-slate-500 truncate">Administrator</p>
            </div>
            <span className="h-2 w-2 rounded-full bg-emerald-400 shrink-0" />
          </div>
        ) : (
          <div className="flex justify-center">
            <div className="h-2 w-2 rounded-full bg-emerald-400" />
          </div>
        )}
      </div>
    </aside>
  );
}
